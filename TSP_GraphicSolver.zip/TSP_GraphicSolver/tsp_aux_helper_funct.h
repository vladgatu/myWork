#ifndef TSP_AUX_HELPER_FUNCT_H
#define TSP_AUX_HELPER_FUNCT_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "tsp_bool.h"
#include <QDebug>

void helper_fill_vect_with_prime_numbers(int *vect, int size)
{
    int num = 2;
    int i = 0;

    for(i = 0; i < size; i++)
    {
        int count = 0;
        int j = 2;
        bool_t found = false_t;

        do
        {
            count = 0;
            if(num > 2)
            {
                for(j = 2; j <= sqrt(num); j++)
                { if(num % j == 0) count++; }

                if(count > 0) num++;
                else
                {
                    found = true_t;
                    vect[i] = num;
                    num++;
                }
            }
            else
            {
                found = true_t;
                vect[i] = num;
                num++;
            }
        }
        while(found != true_t);
    }

//    qDebug() << "\n\n---[ Prime Vect Numbers ]---";
//    for(i = 0; i < size; i++)
//    {
//        qDebug() << "vect[" << i << "] = " << vect[i];
//    }

//    exit(0);
}

#endif // TSP_AUX_HELPER_FUNCT_H
