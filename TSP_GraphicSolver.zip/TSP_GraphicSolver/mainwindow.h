#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QPainter>
#include <QPicture.h>
#include "structures.h"

namespace Ui
{
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void setFirstNode(cutting_order_t *node);

private slots:
    void handleBtnLoadFileAndShow();
    void handleBtnPreprocessKNNAndShow();
    void handleBtnOptimizeWith2OPT();

private:
    QPushButton *btnLoadFile;
    QPushButton *btnPreprocessKNN;
    QPushButton *btnOptimize2OPT;
    QLabel lblPic;
    QPicture pic;
    cutting_order_t *fnode;
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
