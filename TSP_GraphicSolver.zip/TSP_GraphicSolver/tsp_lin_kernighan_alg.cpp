#include "tsp_lin_kernighan_alg.h"

/* init solver with nodes from file */
void tsp_lk_init_with_file_f(const char *name_of_file, tsp_solver_t *solver)
{
    FILE *fd = fopen(name_of_file, "r");
    char buff[12];
    memset(&buff, 0, sizeof(buff));

    solver->first = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    solver->first->next = NULL;

    tsp_node_t *node = solver->first;

    bool_t firstNode = true_t;

    while(fgets(buff, sizeof(buff),fd))
    {
        int nr = 0;
        if(firstNode == false_t)
        {
            tsp_node_t *nod = (cutting_order_t*)malloc(sizeof(cutting_order_t));

            for(int i = 0; i < 6; i++)
            {
                if(buff[i] != '\n' && buff[i] != EOF)
                {
                    if(buff[i] != ' ') nr = nr * 10 + (buff[i] - '0');
                    else
                    {
                        nod->point_col.x = nr;
                        nr = 0;
                    }
                }
                else
                {
                    nod->point_col.y = nr;
                    node->next = nod;
                    node = node->next;
                    node->next = NULL;
                    break;
                }
            }
        }
        else if(firstNode == true_t)
        {
            for(int i = 0; i < 6; i++)
            {
                if(buff[i] != '\n' && buff[i] != EOF)
                {
                    if(buff[i] != ' ') nr = nr * 10 + (buff[i] - '0');
                    else
                    {
                        node->point_col.x = nr;
                        nr = 0;
                    }
                }
                else { node->point_col.y = nr; break; }
            }
            firstNode = false_t;
        }
        memset(&buff, 0, sizeof(buff));
    }

    solver->last = node;
    solver->initial_path_len = tsp_lk_compute_path_len_f(solver);
    solver->number_of_nodes = tsp_lk_get_number_of_nodes_f(solver);

    fclose(fd);
}

/* init solver with random points */
void tsp_lk_init_with_random_f(tsp_solver_t *solver, const int nr_of_gen_nodes, const int minDist, const int maxDist)
{
    int count = 0;
    int ok_first = 0;
    tsp_node_t *old_node;
    tsp_node_t *first_node;

    solver->first = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    solver->first->next = NULL;
    tsp_node_t *node = solver->first;

    while(count < nr_of_gen_nodes)
    {
        int xr = rand() %6000;
        int yr = rand() %500;
        if(!ok_first)
        {
            node->point_col.x = xr;
            node->point_col.y = yr;
            old_node = node;
            first_node = node;
            ok_first = 1;
            count++;
        }
        else
        {
            tsp_node_t *nod = (tsp_node_t*)malloc(sizeof(tsp_node_t));
            nod->next = NULL;
            nod->point_col.x = xr;
            nod->point_col.y = yr;

            int dist = (int)tsp_dist_2_nodes_f(nod, old_node);

            if(dist >= minDist && dist <= maxDist)
            {
                int ok = 0;
                for(tsp_node_t *nd = first_node; nd != NULL; nd = nd->next)
                {
                    int dist2 = (int)tsp_lk_compute_dist_between_two_nodes_f(nod, nd);
                    if(dist2 < minDist/3 || dist2 > 600)
                    { ok = 1; break; }
                }

                if(ok == 0)
                {
                    old_node = nod;
                    node->next = nod;
                    node = node->next;
                    count++;
                }
            }
        }
    }
}

/* init solver with random points and add first & last nodes */
void tsp_lk_init_with_random_and_ss_nodes_f(tsp_solver_t *solver, const int nr_of_gen_nodes, const int minDist, const int maxDist)
{
    tsp_lk_init_with_random_f(solver, nr_of_gen_nodes, minDist, maxDist);
    tsp_lk_add_first_node_rand_f(solver);
    tsp_lk_add_last_node_rand_f(solver);
}

/* add node at end */
void tsp_lk_append_node_f(tsp_solver_t *solver, tsp_node_t *last_node)
{
    tsp_node_t *node = solver->first;
    for(cutting_order_t *nd = node; nd != NULL; nd = nd->next)
    {
        if(nd->next == NULL)
        { nd->next = last_node; break; }
    }
    solver->last = last_node;
}

/* add node at beginning */
void tsp_lk_put_first_node_f(tsp_solver_t *solver, tsp_node_t *first_node)
{
    first_node->next = solver->first;
    solver->first = first_node;
}

/* add first node when init with random points */
void tsp_lk_add_first_node_rand_f(tsp_solver_t *solver)
{
    int max_y = tsp_lk_get_max_y_f(solver);
    int min_x = tsp_lk_get_min_x_f(solver);
    tsp_node_t *node = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    node->next = NULL;
    node->point_col.x = min_x;
    node->point_col.y = max_y;
    tsp_lk_put_first_node_f(solver, node);
}

/* add last node when init with random points */
void tsp_lk_add_last_node_rand_f(tsp_solver_t *solver)
{
    int max_x = tsp_lk_get_max_x_f(solver);
    int min_y = tsp_lk_get_min_y_f(solver);
    tsp_node_t *node = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    node->next = NULL;
    node->point_col.x = max_x;
    node->point_col.y = min_y;
    tsp_lk_append_node_f(solver, node);
}

/* get min X of all points */
int tsp_lk_get_min_x_f(tsp_solver_t *solver)
{
    if(solver->first == NULL) return -1;
    int min = solver->first->point_col.x;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        if(min > nd->point_col.x) min = nd->point_col.x;
    return min;
}

/* get max X of all points */
int tsp_lk_get_max_x_f(tsp_solver_t *solver)
{
    if(solver->first == NULL) return -1;
    int max = solver->first->point_col.x;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        if(max < nd->point_col.x) max = nd->point_col.x;
    return max;
}

/* get min Y of all points */
int tsp_lk_get_min_y_f(tsp_solver_t *solver)
{
    if(solver->first == NULL) return -1;
    int min = solver->first->point_col.y;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        if(min > nd->point_col.y) min = nd->point_col.y;
    return min;
}

/* get max Y of all points */
int tsp_lk_get_max_y_f(tsp_solver_t *solver)
{
    if(solver->first == NULL) return -1;
    int max = solver->first->point_col.y;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        if(max < nd->point_col.y) max = nd->point_col.y;
    return max;
}

/* get number of nodes */
int tsp_lk_get_number_of_nodes_f(tsp_solver_t *solver)
{
    int nr = 0;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next) nr++;
    return nr;
}

/* get distance between two nodes */
int  tsp_lk_compute_dist_between_two_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2)
{
    int x_dist = (int)(nd1->point_col.x - nd2->point_col.x);
    x_dist = (x_dist * x_dist);
    int y_dist = (int)(nd1->point_col.y - nd2->point_col.y);
    y_dist = (y_dist * y_dist);
    int rez = (int)(round(sqrt(x_dist + y_dist)));
    return rez;
}

/* get lenght of path */
long tsp_lk_compute_path_len_f(tsp_solver_t *solver)
{
    long rez = 0;
    for(tsp_node_t *nd = solver->first; nd->next != NULL; nd = nd->next)
        rez += (tsp_lk_compute_dist_between_two_nodes_f(nd, nd->next));
    return rez;
}

/* get lenght of path between two nodes */
long tsp_lk_compute_path_len_between_two_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2)
{
    long rez = 0;
    for(tsp_node_t *nd = nd1; nd->next != NULL && nd->next != nd2; nd = nd->next)
        rez += (tsp_lk_compute_dist_between_two_nodes_f(nd, nd->next));
    return rez;
}

/* free node list */
void tsp_lk_free_nodes_f(tsp_node_t *node)
{
    while(node != NULL)
    {
        tsp_node_t *nd = node->next;
        free(node);
        node = nd;
    }
}

/* free solver elem */
void tsp_lk_free_solver_f(tsp_solver_t *solver)
{
    if(solver == NULL || solver->first == NULL) return;
    tsp_node_t *node = solver->first;
    tsp_lk_free_nodes_f(node);
    if(solver->last != NULL) free(solver->last);
    if(solver->all_edges != NULL) free(solver->all_edges);
}

/* swap nodes when using nearest neighbor alg */
void tsp_lk_knn_swap_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2, tsp_node_t *nd3)
{
    nd3->next = nd2->next;
    nd2->next = nd1->next;
    nd1->next = nd2;
}

/* preprocess nodes with nearest neighbor */
void tsp_lk_knn_preprocess_f(tsp_solver_t *solver)
{
    if(solver == NULL || solver->first == NULL) return;
    tsp_node_t *node = solver->first;
    if(node == NULL || node->next == NULL) return;
    for(tsp_node_t *nd1 = node; nd1->next != NULL; nd1 = nd1->next)
    {
        unsigned int min_dist = 65000;
        cutting_order_t *aux_nd2_1, *aux_nd2_2;
        for(tsp_node_t *nd2 = nd1; nd2->next != NULL; nd2 = nd2->next)
        {
            unsigned int dist = (unsigned int)tsp_lk_compute_dist_between_two_nodes_f(nd1, nd2->next);
            if(dist < min_dist)
            {
                min_dist = dist;
                aux_nd2_1 = nd2->next;
                aux_nd2_2 = nd2;
            }
        }
        tsp_lk_knn_swap_nodes_f(nd1, aux_nd2_1, aux_nd2_2);
    }
}


/* -- K-OPT Moves & Operations -- */
/* reverse direction of some nodes */
void tsp_lk_reverse_direction_f(tsp_node_t *nd1_n, tsp_node_t *nd1_nn, tsp_node_t *nd2)
{
    if(nd1_nn == nd2) nd1_nn->next = nd1_n;
    else
    {
        cutting_order_t *aux = nd1_nn->next;
        nd1_nn->next = nd1_n;
        tsp_lk_reverse_direction_f(nd1_nn, aux, nd2);
    }
}

/* make a 2-opt move */
void tsp_lk_2opt_swap_f(tsp_node_t *nd1, tsp_node_t *nd2, tsp_node_t *nd1_n, tsp_node_t *nd2_n)
{
    tsp_lk_reverse_direction_f(nd1_n, nd1_n->next, nd2);
    nd1->next = nd2;
    nd1_n->next = nd2_n;
}

/* make a 3-opt move */
void tsp_lk_3opt_swap_f(tsp_node_t *nd1,
                        tsp_node_t *nd2,
                        tsp_node_t *nd3,
                        tsp_node_t *nd1_n,
                        tsp_node_t *nd2_n,
                        tsp_node_t *nd3_n, int type)
{
    switch(type)
    {
        case 4:
            tsp_lk_reverse_direction_f(nd1_n,nd1_n->next,nd2);
            nd1->next = nd2;
            nd1_n->next = nd3;
            tsp_lk_reverse_direction_f(nd2_n,nd2_n->next,nd3);
            nd2_n->next = nd3_n;
            break;
        case 5:
            nd1->next = nd3;
            tsp_lk_reverse_direction_f(nd2_n,nd2_n->next,nd3);
            nd2_n->next = nd1_n;
            nd2->next = nd3_n;
            break;
        case 6:
            tsp_lk_reverse_direction_f(nd1_n,nd1_n->next,nd2);
            nd1->next = nd2_n;
            nd3->next = nd2;
            nd1_n->next = nd3_n;
            break;
        case 7:
            nd1->next = nd2_n;
            nd3->next = nd1_n;
            nd2->next = nd3_n;
            break;
        default: break;
    }
}

/* partitioning with k-means */
void tsp_lk_kmeans_fill_with_centroids_f(tsp_solver_t *solver, int centroids)
{
    solver->centr.centr_point = (tsp_point_t*)malloc(sizeof(tsp_point_t)*centroids);
    int max_x = tsp_lk_get_max_x_f(solver);
    int max_y = tsp_lk_get_max_y_f(solver);
    int min_x = tsp_lk_get_min_x_f(solver);
    int min_y = tsp_lk_get_min_y_f(solver);

    int count = 0;

    while(count < centroids)
    {
        int xr = rand() %(max_x-min_x) + min_x;
        int yr = rand() %(max_y-min_y) + min_y;

        solver->centr.centr_point[count].x = xr;
        solver->centr.centr_point[count].y = yr;

        count++;
    }
}

double tsp_lk_compute_slope_f(tsp_point_t p1, tsp_point_t p2)
{
    double slope = (double)(((p1.x - p2.x)*(-1)) / (p1.y - p2.y));
    return slope;
}

double tsp_lk_compute_eq_constant_f(double slope, double x3, double y3)
{
    double rez = 0;
    rez = y3 - (slope * x3);
    return rez;
}

double tsp_lk_compute_midpoint_between_centr_f(int v1, int v2)
{
    return (double)((v1 + v2)/2);
}

void tsp_lk_kmeans_compute_equation_f(tsp_solver_t *solver, double *eq)
{
    double midx = tsp_lk_compute_midpoint_between_centr_f(solver->centr.centr_point[0].x, solver->centr.centr_point[1].x);
    double midy = tsp_lk_compute_midpoint_between_centr_f(solver->centr.centr_point[0].y, solver->centr.centr_point[1].y);
    double slope = tsp_lk_compute_slope_f(solver->centr.centr_point[0], solver->centr.centr_point[1]);
    double constant = tsp_lk_compute_eq_constant_f(slope, midx, midy);

    eq[0] = slope;
    eq[1] = 1.f;
    eq[2] = constant;
}

double tsp_lk_compute_eq_result_f(tsp_point_t p, double *eq) /* 0 - x ; 1 - y; 2 - c */
{
    double rez = 0;
    rez = p.x * eq[0] - p.y * eq[1] + eq[2];
    return rez;
}

void tsp_lk_kmeans_append_node_f(tsp_node_t *node, int x, int y)
{
    tsp_node_t *nod = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    nod->next = NULL;
    nod->point_col.x = x;
    nod->point_col.y = y;
    node->next = nod;
    node = node->next;
}

void tsp_lk_fill_points_for_each_centr_f(tsp_solver_t *solver, int centroids, double *eq)
{
    double rez_eq_p1 = tsp_lk_compute_eq_result_f(solver->centr.centr_point[0], eq);

    tsp_node_t *nc1 = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    nc1->next = NULL;
    tsp_node_t *nc1_aux = nc1;
    bool_t first_nc1 = true_t;
    int count_nc1 = 0;

    tsp_node_t *nc2 = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    nc2->next = NULL;
    tsp_node_t *nc2_aux = nc2;
    bool_t first_nc2 = true_t;
    int count_nc2 = 0;

    if(rez_eq_p1 > 0)
    {
        for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        {
            if(tsp_lk_compute_eq_result_f(nd->point_col, eq) > 0)
            {
                if(first_nc1 == true_t)
                {
                    nc1->point_col.x = nd->point_col.x;
                    nc1->point_col.y = nd->point_col.y;
                    first_nc1 = false_t;
                }
                else tsp_lk_kmeans_append_node_f(nc1, nd->point_col.x, nd->point_col.y);
                count_nc1++;
            }
            else
            {
                if(first_nc2 == true_t)
                {
                    nc2->point_col.x = nd->point_col.x;
                    nc2->point_col.y = nd->point_col.y;
                    first_nc2 = false_t;
                }
                else tsp_lk_kmeans_append_node_f(nc2, nd->point_col.x, nd->point_col.y);
                count_nc2++;
            }
        }
    }
    else if(rez_eq_p1 < 0)
    {
        for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        {
            if(tsp_lk_compute_eq_result_f(nd->point_col, eq) < 0)
            {
                if(first_nc1 == true_t)
                {
                    nc1->point_col.x = nd->point_col.x;
                    nc1->point_col.y = nd->point_col.y;
                    first_nc1 = false_t;
                }
                else tsp_lk_kmeans_append_node_f(nc1, nd->point_col.x, nd->point_col.y);
                count_nc1++;
            }
            else
            {
                if(first_nc2 == true_t)
                {
                    nc2->point_col.x = nd->point_col.x;
                    nc2->point_col.y = nd->point_col.y;
                    first_nc2 = false_t;
                }
                else tsp_lk_kmeans_append_node_f(nc2, nd->point_col.x, nd->point_col.y);
                count_nc2++;
            }
        }
    }
    else { printf("SAVAGE\n"); }

    solver->centr.len = centroids;
    solver->centr.points_of_centroids = (tsp_nodes_list_t*)malloc(sizeof(tsp_nodes_list_t)*centroids);

    if(solver->centr.points_of_centroids[0].list != NULL) tsp_lk_free_nodes_f(solver->centr.points_of_centroids[0].list);
    solver->centr.points_of_centroids[0].len = count_nc1;
    solver->centr.points_of_centroids[0].list = nc1_aux;

    if(solver->centr.points_of_centroids[1].list != NULL) tsp_lk_free_nodes_f(solver->centr.points_of_centroids[1].list);
    solver->centr.points_of_centroids[1].len = count_nc2;
    solver->centr.points_of_centroids[1].list = nc2_aux;

}

double tsp_lk_compute_arithmetic_mean_f(tsp_node_t *node, int type)
{
    double rez = 0.f;
    int count = 0;
    switch(type)
    {
    case 1:
        for(tsp_node_t *nd = node; nd != NULL; nd = nd->next)
        {
            rez += (double)(nd->point_col.x);
            count++;
        }
        break;
    case 2:
        for(tsp_node_t *nd = node; nd != NULL; nd = nd->next)
        {
            rez += (double)(nd->point_col.y);
            count++;
        }
        break;
    default: break;
    }
    return (double)(rez/count);
}

void tsp_lk_compute_new_pos_of_centr_f(tsp_solver_t *solver)
{
    double c1x = tsp_lk_compute_arithmetic_mean_f(solver->centr.points_of_centroids[0].list, 1);
    double c1y = tsp_lk_compute_arithmetic_mean_f(solver->centr.points_of_centroids[0].list, 2);
    double c2x = tsp_lk_compute_arithmetic_mean_f(solver->centr.points_of_centroids[1].list, 1);
    double c2y = tsp_lk_compute_arithmetic_mean_f(solver->centr.points_of_centroids[1].list, 2);

    solver->centr.centr_point[0].x = c1x;
    solver->centr.centr_point[0].y = c1y;
    solver->centr.centr_point[1].x = c2x;
    solver->centr.centr_point[1].y = c2y;
}

void tsp_lk_kmeans_clustering_alg_f(tsp_solver_t *solver, double *eq, int last_count)
{
    if(last_count != solver->centr.points_of_centroids[0].len)
    {
        tsp_lk_compute_new_pos_of_centr_f(solver);
        tsp_lk_kmeans_compute_equation_f(solver, eq);
        tsp_lk_fill_points_for_each_centr_f(solver, centroids, eq);
        tsp_lk_kmeans_clustering_alg_f(solver, eq, solver->centr.points_of_centroids[0].len);
    }
}

void tsp_lk_kmeans_partitioning_f(tsp_solver_t *solver, int centroids)
{
    if(centroids != 2) return;
    tsp_lk_kmeans_fill_with_centroids_f(solver, centroids);
    double *eq = (double*)malloc(sizeof(double)*3);
    tsp_lk_kmeans_compute_equation_f(solver, eq);
    tsp_lk_fill_points_for_each_centr_f(solver, centroids, eq);

    tsp_lk_kmeans_clustering_alg_f(solver, eq, 0);
}
