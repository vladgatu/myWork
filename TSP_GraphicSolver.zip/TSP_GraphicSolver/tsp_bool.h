#ifndef TSP_BOOL_H
#define TSP_BOOL_H

#define true_t 1
#define false_t 0
typedef int bool_t;

#endif // TSP_BOOL_H
