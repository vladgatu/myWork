#ifndef TSP_PROCESS_FUNC_H
#define TSP_PROCESS_FUNC_H



#include "structures.h"
#include "tsp_helper_func.h"

void tsp_swap_nodes_f(cutting_order_t *first_nd, cutting_order_t *second_nd, cutting_order_t *third_nd)
{
    third_nd->next = second_nd->next;
    second_nd->next = first_nd->next;
    first_nd->next = second_nd;
}

void tsp_knn_preprocess_f(cutting_order_t *node)
{
    if(node == NULL || node->next == NULL) return;
    for(cutting_order_t *nd1 = node; nd1->next != NULL; nd1 = nd1->next)
    {
        unsigned int min_dist = 65000;
        cutting_order_t *aux_nd2_1, *aux_nd2_2;
        for(cutting_order_t *nd2 = nd1; nd2->next != NULL; nd2 = nd2->next)
        {
            unsigned int dist = (unsigned int)tsp_dist_2_nodes_f(nd1, nd2->next);
            if(dist < min_dist)
            {
                min_dist = dist;
                aux_nd2_1 = nd2->next;
                aux_nd2_2 = nd2;
            }
        }
        tsp_swap_nodes_f(nd1, aux_nd2_1, aux_nd2_2);
    }
}

#endif // TSP_PROCESS_FUNC_H
