#ifndef TSP_POINT_STRUCT_H
#define TSP_POINT_STRUCT_H

typedef struct tsp_point_s
{
    int x,y;
} tsp_point_t;

#endif // TSP_POINT_STRUCT_H
