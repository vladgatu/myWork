#ifndef STRUCTURES_H
#define STRUCTURES_H

//#define true_t 1
//#define false_t 0
//typedef int bool_t;

typedef struct point_s
{
    int x,y;
} point_t;

typedef struct cutting_order_s
{
    point_t point_col;
    cutting_order_s *next;
    //cutting_order_s *prev;
} cutting_order_t;

/*
typedef struct tsp_edge_s
{
    point_t p1, p2;
    int cost;
} tsp_edge_t;

typedef struct tsp_solver_s
{
    tsp_edge_t *edge;
} tsp_solver_t;
*/

#endif // STRUCTURES_H
