#ifndef TSP_LIN_KERNIGHAN_ALG_FUNC_H
#define TSP_LIN_KERNIGHAN_ALG_FUNC_H


//#include "structures.h"
//#include "tsp_helper_func.h"
//#include "tsp_process_func.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define min_f(a,b) ((a > b) ? (b) : (a))
#define max_f(a,b) ((a < b) ? (b) : (a))

#define INF_T 1e30

#define true_t 1
#define false_t 0
typedef int bool_t;

typedef struct tsp_point_s
{
    int x,y;
} tsp_point_t;

typedef struct tsp_node_s
{
    tsp_point_t point_col;
    tsp_node_s *next;
} tsp_node_t;

typedef struct tsp_edge_s
{
    tsp_point_t p1, p2;
    unsigned int dist;
} tsp_edge_t;

typedef struct tsp_nodes_list_s
{
    tsp_node_t *list;
    int len;
} tsp_nodes_list_t;

typedef struct tsp_centroids_s
{
    tsp_point_t *centr_point;
    int len;
    tsp_nodes_list_t *points_of_centroids;
} tsp_centroids_t;

typedef struct tsp_solver_s
{
    tsp_node_t *first;
    tsp_node_t *last;
    unsigned int number_of_nodes;
    unsigned int initial_path_len;
    unsigned int after_nn_path_len;
    unsigned int after_lk_path_len;

    tsp_edge_t *all_edges;
    unsigned int number_of_edges;

    int max_x, max_y;
    int min_x, min_y;

    tsp_centroids_t centr;
} tsp_solver_t;

/* ------ Init Functions ------ +*/
//tsp_node_t* tsp_init_with_file(const char *name_file);
//tsp_node_t* tsp_init_with_random(const int nr_of_gen_nodes);
//tsp_node_t* tsp_init_with_random_and_ss_nodes(const int nr_of_generated_nodes);

void tsp_lk_init_with_file_f(const char *name_file, tsp_solver_t *solver);
void tsp_lk_init_with_random_f(tsp_solver_t *solver, const int nr_of_gen_nodes, const int minDist, const int maxDist);
void tsp_lk_init_with_random_and_ss_nodes_f(tsp_solver_t *solver, const int nr_of_gen_nodes, const int minDist, const int maxDist);

/* ------- Free My Mem ------- +*/
void tsp_lk_free_nodes_f(tsp_node_t *node);
void tsp_lk_free_solver_f(tsp_solver_t *solver);

/* ----- Nodes Operations ----- +*/
void tsp_lk_append_node_f(tsp_solver_t *solver, tsp_node_t *last_node);
void tsp_lk_put_first_node_f(tsp_solver_t *solver, tsp_node_t *first_node);

/* --- Nodes Operations When Randomize --- +*/
void tsp_lk_add_first_node_rand_f(tsp_solver_t *solver);
void tsp_lk_add_last_node_rand_f(tsp_solver_t *solver);

/* -- Reduce search to local -- */
//void tsp_lk_neighbor_limitation_f(int m, tsp_solver_t *solver);

/* ------- K-OPT moves ------- */
void tsp_lk_reverse_direction_f(tsp_node_t *nd1_n, tsp_node_t *nd1_nn, tsp_node_t *nd2);
void tsp_lk_2opt_swap_f(tsp_node_t *nd1, tsp_node_t *nd2, tsp_node_t *nd1_n, tsp_node_t *nd2_n);
void tsp_lk_3opt_swap_f(tsp_node_t *nd1,
                        tsp_node_t *nd2,
                        tsp_node_t *nd3,
                        tsp_node_t *nd1_n,
                        tsp_node_t *nd2_n,
                        tsp_node_t *nd3_n, int type);
//void tsp_lk_4opt_swap_f();
//void tsp_lk_5opt_swap_f();
//void tsp_lk_kopt_move_f(tsp_solver_t *solver);

/* ------ compute gain ------ */
//int tsp_lk_compute_gain_f();

/* - Preprocess initial state - +*/
void tsp_lk_knn_preprocess_f(tsp_solver_t *solver);
void tsp_lk_knn_swap_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2, tsp_node_t *nd3);

/* ---- Sort functions ---- */
//void tsp_lk_sort_asc_by_x_f(tsp_solver_t *solver);
//void tsp_lk_sort_asc_by_y_f(tsp_solver_t *solver);
//void tsp_lk_sort_desc_by_x_f(tsp_solver_t *solver);
//void tsp_lk_sort_desc_by_y_f(tsp_solver_t *solver);

/* ---- Min/Max functions ---- +*/
int tsp_lk_get_min_x_f(tsp_solver_t *solver);
int tsp_lk_get_max_x_f(tsp_solver_t *solver);
int tsp_lk_get_min_y_f(tsp_solver_t *solver);
int tsp_lk_get_max_y_f(tsp_solver_t *solver);

/* ------- Compute len ------- +*/
long tsp_lk_compute_path_len_f(tsp_solver_t *solver);
long tsp_lk_compute_path_len_between_two_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2);
int  tsp_lk_compute_dist_between_two_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2);

/* ---- Compute all edges ---- */
//void tsp_lk_get_all_edges_f(tsp_solver_t *solver);

/* ------ Partitioning ------- +_*/
/* -- Future implementation -- */

void tsp_lk_kmeans_partitioning_f(tsp_solver_t *solver, int centroids);

/* -------- Nr of nodes -------- +*/
int tsp_lk_get_number_of_nodes_f(tsp_solver_t *solver);


/* --------------------------- */


#endif // TSP_LIN_KERNIGHAN_ALG_FUNC_H
