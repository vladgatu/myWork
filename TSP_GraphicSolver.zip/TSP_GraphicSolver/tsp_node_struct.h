#ifndef TSP_NODE_STRUCT_H
#define TSP_NODE_STRUCT_H

typedef struct tsp_node_s
{
    tsp_point_t point_col;
    int partition_index;
    int point_index;
    tsp_node_s *next;
} tsp_node_t;

#endif // TSP_NODE_STRUCT_H
