#include "mainwindow.h"
#include <QApplication>
#include <QLabel>
#include <QPicture>
#include <QPainter>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QPushButton>
#include <QDebug>
#include <thread>
#include <sstream>
#include <random>
#include <time.h>
#include <QDateTime>
#include <stack>
#include <iostream>

#include "tsp_helper_func.h"
#include "tsp_process_func.h"
#include "tsp_lin_kernighan_alg_aux.h"
#include "tsp_generate_kopt_perm.h"

#include "tsp_partitioning.h"

/* -------------- TSP ---------------- */

void tsp_2opt_swap_p2_f(cutting_order_t *nd1_n, cutting_order_t *nd1_nn, cutting_order_t *nd2)
{
    if(nd1_nn == nd2)
    {
        //qDebug() << "2opt swap part 2 \n";
        nd1_nn->next = nd1_n;
    }
    else
    {
        cutting_order_t *aux = nd1_nn->next;
        nd1_nn->next = nd1_n;
        tsp_2opt_swap_p2_f(nd1_nn, aux, nd2);
    }
}

void tsp_2opt_swap_f2(cutting_order_t *nd1, cutting_order_t *nd2, cutting_order_t *nd1_n, cutting_order_t *nd2_n)
{

    //qDebug() << "2opt swap\n";
    tsp_2opt_swap_p2_f(nd1_n, nd1_n->next, nd2);
    nd1->next = nd2;
    nd1_n->next = nd2_n;
}

void tsp_3opt_swap_f(cutting_order_t *nd1,
                     cutting_order_t *nd2,
                     cutting_order_t *nd3,
                     cutting_order_t *nd1_n,
                     cutting_order_t *nd2_n,
                     cutting_order_t *nd3_n, int type)
{
    switch(type)
    {
    case 4:
        qDebug() << "Case : " << type << "\n";
        tsp_2opt_swap_p2_f(nd1_n,nd1_n->next,nd2);
        nd1->next = nd2;
        nd1_n->next = nd3;
        tsp_2opt_swap_p2_f(nd2_n,nd2_n->next,nd3);
        nd2_n->next = nd3_n;
        break;
    case 5:
        qDebug() << "Case : " << type << "\n";
        nd1->next = nd3;
        tsp_2opt_swap_p2_f(nd2_n,nd2_n->next,nd3);
        nd2_n->next = nd1_n;
        nd2->next = nd3_n;
        break;
    case 6:
        qDebug() << "Case : " << type << "\n";
        tsp_2opt_swap_p2_f(nd1_n,nd1_n->next,nd2);
        nd1->next = nd2_n;
        nd3->next = nd2;
        nd1_n->next = nd3_n;
        break;
    case 7:
        qDebug() << "Case : " << type << "\n";
        nd1->next = nd2_n;
        nd3->next = nd1_n;
        nd2->next = nd3_n;
        break;

    default: break;
    }
}


void tsp_solver_f(cutting_order_t *node)
{
    if(node == NULL || node->next == NULL) return;
    //tsp_knn_preprocess_f(node);
    int cycle = 0;
    //while(cycle < 55)
    //{
        /*
        int current_cost = tsp_compute_path_cost_f(node);
        for(cutting_order_t *nd1 = node; nd1->next != NULL; nd1 = nd1->next)
        {
            for(cutting_order_t *nd2 = nd1->next; nd2 != NULL; nd2 = nd2->next)
            {

                int cost = tsp_compute_path_cost_f(node);
                if(cost < current_cost)
                {

                }
            }
        }
        */

        for(cutting_order_t *nd1 = node, *nd2 = node->next->next; /*nd2->next != NULL ||*/ cycle < 22; nd1 = nd1->next, nd2 = nd2->next)
        {
            int old_dist = tsp_dist_2_nodes_f(nd1, nd1->next) + tsp_dist_2_nodes_f(nd2, nd2->next);
            int new_dist = tsp_dist_2_nodes_f(nd1, nd2) + tsp_dist_2_nodes_f(nd1->next, nd2->next);

            if(new_dist < old_dist)
            {
                printf("OK\n");
                tsp_2opt_swap_f2(nd1,nd2,nd1->next,nd2->next);
            }
            cycle++;
        }



        printf("Cycle = %i \n", cycle);

        //cycle++;
    //}
}


void tsv_start_solver_f(cutting_order_t *node, QLabel *lbl)
{
    tsp_fill_from_file_f(node, "D:\\Proiecte\\Gemini\\Proj1\\nodes.txt");

    node = node->next;
    tsp_print_cutting_order_f(node);

    printf("LenPath = %i \n", tsp_compute_path_cost_f(node));

    tsp_knn_preprocess_f(node);
    printf("\nAfter KNN : \n");

    tsp_print_cutting_order_f(node);

    printf("LenPath = %i \n", tsp_compute_path_cost_f(node));


    printf("\nAfter 2-OPT : \n");

    tsp_make_cycle_f(node);

    tsp_solver_f(node);

    tsp_undo_cycle_f(node);

    tsp_print_cutting_order_f(node);

    printf("LenPath = %i \n", tsp_compute_path_cost_f(node));
}

/* ----------------------------------- */

void tsp_draw_graph_f(cutting_order_t *node, QLabel *lbl)
{
    QPicture pic;
    QPainter painter(&pic);
    lbl->clear();

    painter.setRenderHint(QPainter::Antialiasing);

    cutting_order_t *aux_nd = node;
    cutting_order_t *nd = node;
    for( ; nd->next != NULL && nd->next != aux_nd; nd = nd->next)
    {
        painter.setPen(QPen(Qt::black, 5));
        painter.drawPoint(nd->point_col.x, nd->point_col.y);
        //painter.drawPoint(nd->point_col.x, nd->point_col.y);
        painter.setPen(QPen(Qt::black, 2));
        painter.drawLine(nd->point_col.x, nd->point_col.y, nd->next->point_col.x, nd->next->point_col.y);

        if(nd->next->next == NULL || nd->next->next == node)
        {
            painter.setPen(QPen(Qt::black, 8));
            painter.drawPoint(nd->next->point_col.x, nd->next->point_col.y);
        }
    }

    painter.end();

    lbl->setPicture(pic);
}


void tsp_draw_part(tsp_partition_t *part, QLabel *lbl)
{
    QPicture pic;
    QPainter painter(&pic);
    lbl->clear();

    painter.setRenderHint(QPainter::Antialiasing);

    tsp_node_t *node = part->first;

    tsp_node_t *aux_nd = node;
    tsp_node_t *nd = node;
    for( ; nd->next != NULL && nd->next != aux_nd; nd = nd->next)
    {
        switch(nd->partition_index)
        {
        case 1:
            painter.setPen(QPen(Qt::blue, 5));
            break;
        case 2:
            painter.setPen(QPen(Qt::red, 5));
            break;
        case 3:
            painter.setPen(QPen(Qt::green, 5));
            break;
        case 4:
            painter.setPen(QPen(Qt::magenta, 5));
            break;
        case 5:
            painter.setPen(QPen(Qt::yellow, 5));
            break;
        case 6:
            painter.setPen(QPen(Qt::gray, 5));
            break;
        default :
            painter.setPen(QPen(Qt::black, 5));
            break;
        }

        painter.drawPoint(nd->point_col.x, nd->point_col.y);
    }

    painter.end();

    lbl->setPicture(pic);
}


void tsp_draw_graph_f2(tsp_node_t *node, QLabel *lbl)
{
    QPicture pic;
    QPainter painter(&pic);
    lbl->clear();

    painter.setRenderHint(QPainter::Antialiasing);

    tsp_node_t *aux_nd = node;
    tsp_node_t *nd = node;
    for( ; nd->next != NULL && nd->next != aux_nd; nd = nd->next)
    {
        painter.setPen(QPen(Qt::black, 5));
        painter.drawPoint(nd->point_col.x, nd->point_col.y);
        //painter.drawPoint(nd->point_col.x, nd->point_col.y);
        painter.setPen(QPen(Qt::black, 2));
        painter.drawLine(nd->point_col.x, nd->point_col.y, nd->next->point_col.x, nd->next->point_col.y);

        if(nd->next->next == NULL || nd->next->next == node)
        {
            painter.setPen(QPen(Qt::black, 5));
            painter.drawPoint(nd->next->point_col.x, nd->next->point_col.y);
        }
    }

    painter.end();

    lbl->setPicture(pic);
}


void tsp_draw_pieces(tsp_solver_t *solver, QLabel *lbl)
{
    tsp_piece_t *piece = solver->fpiece;

    QPicture pic;
    QPainter painter(&pic);
    lbl->clear();
    painter.setRenderHint(QPainter::Antialiasing);

    for(tsp_piece_t *pnd = piece; pnd != NULL; pnd = pnd->next)
    {
        qDebug() << "sdvjkbdf";
        for(tsp_node_t *nd = pnd->pnode; nd->next != NULL; nd = nd->next)
        {
            painter.setPen(QPen(Qt::black, 5));
            painter.drawPoint(nd->point_col.x, nd->point_col.y);

            painter.setPen(QPen(Qt::black, 2));
            painter.drawLine(nd->point_col.x, nd->point_col.y, nd->next->point_col.x, nd->next->point_col.y);

            if(nd->next->next == NULL)
            {
                painter.setPen(QPen(Qt::black, 5));
                painter.drawPoint(nd->next->point_col.x, nd->next->point_col.y);
                painter.setPen(QPen(Qt::black, 2));
                painter.drawLine(nd->next->point_col.x, nd->next->point_col.y, pnd->pnode->point_col.x, pnd->pnode->point_col.y);
            }
        }

//        painter.setPen(QPen(Qt::green, 5));
//        painter.drawPoint(pnd->gcenter_scale.x, pnd->gcenter_scale.y);
//        painter.setPen(QPen(Qt::green, 2));
//        if(pnd->next != NULL && pnd->next != piece)
//            painter.drawLine(pnd->gcenter_scale.x, pnd->gcenter_scale.y, pnd->next->gcenter_scale.x, pnd->next->gcenter_scale.y);
//        else painter.drawLine(pnd->gcenter_scale.x, pnd->gcenter_scale.y, piece->gcenter_scale.x, piece->gcenter_scale.y);

        painter.setPen(QPen(Qt::green, 5));
        painter.drawPoint(pnd->gcenter.x*11, pnd->gcenter.y*11);
        painter.setPen(QPen(Qt::green, 2));
        if(pnd->next != NULL && pnd->next != piece)
            painter.drawLine(pnd->gcenter.x*11, pnd->gcenter.y*11, pnd->next->gcenter.x*11, pnd->next->gcenter.y*11);
        //else painter.drawLine(pnd->gcenter.x*11, pnd->gcenter.y*11, piece->gcenter.x*11, piece->gcenter.y*11);

        painter.setPen(QPen(Qt::red, 5));
        painter.drawPoint(pnd->gcenter_scale.x, pnd->gcenter_scale.y);
        painter.setPen(QPen(Qt::red, 2));
        painter.drawLine(pnd->gcenter.x*11, pnd->gcenter.y*11, pnd->gcenter_scale.x, pnd->gcenter_scale.y);

        if(pnd->bestp.x > -1 && pnd->bestp.y > -1)
        {
            painter.setPen(QPen(Qt::blue, 5));
            painter.drawPoint(pnd->bestp.x, pnd->bestp.y);
            painter.setPen(QPen(Qt::blue, 2));
            if(pnd->next != NULL && pnd->next != piece)
                painter.drawLine(pnd->bestp.x, pnd->bestp.y, pnd->next->bestp.x, pnd->next->bestp.y);
            //else painter.drawLine(pnd->bestp.x, pnd->bestp.y, piece->bestp.x, piece->bestp.y);
        }
        if(pnd->next == piece) break;
    }

    painter.end();
    lbl->setPicture(pic);
}


void tsp_knn_preprocess2_f(cutting_order_t *node, QLabel *lbl, QLabel *lblPathLen, int mySleep)
{
    if(node == NULL || node->next == NULL) return;
    for(cutting_order_t *nd1 = node; nd1->next != NULL; nd1 = nd1->next)
    {
        unsigned int min_dist = 65000;
        cutting_order_t *aux_nd2_1, *aux_nd2_2;
        for(cutting_order_t *nd2 = nd1; nd2->next != NULL; nd2 = nd2->next)
        {
            unsigned int dist = (unsigned int)tsp_dist_2_nodes_f(nd1, nd2->next);
            if(dist < min_dist)
            {
                min_dist = dist;
                aux_nd2_1 = nd2->next;
                aux_nd2_2 = nd2;
            }
        }
        tsp_swap_nodes_f(nd1, aux_nd2_1, aux_nd2_2);
        tsp_draw_graph_f(node, lbl);

        int path = tsp_compute_path_cost_f(node);
        std::stringstream oss;
        oss << "Path len = " << path;
        lblPathLen->setText(QString::fromStdString(oss.str()));

        _sleep(mySleep);
    }
}

void tsp_solver2_f(cutting_order_t *node, QLabel *lbl, QLabel *lblPathLen, int mySleep)
{
    if(node == NULL || node->next == NULL) return;
    //tsp_knn_preprocess_f(node);
    int cycle = 0;

    cutting_order_t *aux_nd = node;

    //tsp_make_cycle_f(aux_nd);

     cycle = 0;
     int cnt = 0;
     int auxcnt = 0;
     bool_t noMoreIm = false_t;


     for(cutting_order_t *nd1 = node; noMoreIm != true_t; nd1 = nd1->next)
     {
         //qDebug() << "ciclul : " << cycle++ << "\n";
         cutting_order_t *aux_nd1, *aux_nd2;
         int best_dist = -1;

         if(nd1->next->next == NULL) qDebug() << "NULL \n";
         else qDebug() << "Not NULL " << (cycle++) << "\n";

         if(nd1->next->next != NULL)
         for(cutting_order_t *nd2 = nd1->next->next; /* nd2->next->next != nd1 && */ nd2->next != NULL; nd2 = nd2->next)
         {
             int old_dist = tsp_dist_2_nodes_f(nd1, nd1->next) + tsp_dist_2_nodes_f(nd2, nd2->next);
             int new_dist = tsp_dist_2_nodes_f(nd1, nd2) + tsp_dist_2_nodes_f(nd1->next, nd2->next);

             if(new_dist < old_dist)
             {
                 if(best_dist == -1)
                 {
                    best_dist = new_dist;
                    aux_nd1 = nd1;
                    aux_nd2 = nd2;
                 }
                 else if(best_dist > new_dist)
                 {
                     best_dist = new_dist;
                     aux_nd1 = nd1;
                     aux_nd2 = nd2;
                 }
             }
         }

         //qDebug() << "Cycle = " << cycle << " -- cnt = " << cnt << "\n";

         if(best_dist != -1 &&
            aux_nd1 != NULL &&
            aux_nd2 != NULL)
         {
            if(aux_nd1->next != NULL &&
               aux_nd2->next != NULL)
            {
                tsp_2opt_swap_f2(aux_nd1, aux_nd2, aux_nd1->next, aux_nd2->next);
                cnt++;
            }
         }



         if(nd1->next == node || nd1->next->next == NULL)
         {
             qDebug() << "Eq Node\n";
             if(cnt == 0) noMoreIm = true_t;
             cnt = 0;
             if(nd1->next->next == NULL) nd1 = node;
         }
     }
     //qDebug() << "Undoing Cycle\n";

     //tsp_undo_cycle_f(aux_nd);

     //qDebug() << "Cycle undo\n";

     //tsp_draw_graph_f(aux_nd, lbl);

     int path = tsp_compute_path_cost_f(node);
     std::stringstream oss;
     oss << "Path len = " << path;
     lblPathLen->setText(QString::fromStdString(oss.str()));
}


void tsp_solver_3opt_f(cutting_order_t *node)
{
    if(node == NULL || node->next == NULL) return;

    int cycle = 0;

    cutting_order_t *aux_nd = node;

     cycle = 0;
     int cnt = 0;
     int auxcnt = 0;
     bool_t noMoreIm = false_t;

     for(cutting_order_t *nd1 = node;  noMoreIm != true_t /* nd1->next->next != NULL */; nd1 = nd1->next)
     {
         cycle++;
         cutting_order_t *aux_nd1, *aux_nd2, *aux_nd3;
         int best_dist = -1, index = 0;

         if(nd1->next->next != NULL)
         for(cutting_order_t *nd2 = nd1->next->next; /* nd2->next->next != nd1 && */ nd2->next != NULL; nd2 = nd2->next)
         {
             if(nd2->next != NULL)
             {
                 if(nd2->next->next != NULL)
                 for(cutting_order_t *nd3 = nd2->next->next; nd3->next != NULL; nd3 = nd3->next)
                 {

                     int vdist[8] = { 0 };
                     for(int i = 0; i < 8; i++)
                     {
                         switch(i)
                         {
                         case 0:
                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd1->next) +
                                        tsp_dist_2_nodes_f(nd2, nd2->next) +
                                        tsp_dist_2_nodes_f(nd3, nd3->next);
                             break;
                         case 1:
//                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd3->next) +
//                                        tsp_dist_2_nodes_f(nd3, nd2) +
//                                        tsp_dist_2_nodes_f(nd2->next, nd1->next);
                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd3) +
                                        tsp_dist_2_nodes_f(nd2->next, nd2) +
                                        tsp_dist_2_nodes_f(nd1->next, nd3->next);
                             break;
                         case 2:
//                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd2) +
//                                        tsp_dist_2_nodes_f(nd2->next, nd3) +
//                                        tsp_dist_2_nodes_f(nd3->next, nd1->next);
                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd1->next) +
                                        tsp_dist_2_nodes_f(nd2, nd3) +
                                        tsp_dist_2_nodes_f(nd2->next, nd3->next);
                             break;
                         case 3:
//                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd3) +
//                                        tsp_dist_2_nodes_f(nd3->next, nd2->next) +
//                                        tsp_dist_2_nodes_f(nd2, nd1->next);
                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd2) +
                                        tsp_dist_2_nodes_f(nd1->next, nd2->next) +
                                        tsp_dist_2_nodes_f(nd3, nd3->next);
                             break;
                         case 4:
//                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd2) +
//                                        tsp_dist_2_nodes_f(nd2->next, nd3->next) +
//                                        tsp_dist_2_nodes_f(nd3, nd1->next);
                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd2) +
                                        tsp_dist_2_nodes_f(nd1->next, nd3) +
                                        tsp_dist_2_nodes_f(nd2->next, nd3->next);
                             break;
                         case 5:
//                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd3) +
//                                        tsp_dist_2_nodes_f(nd3->next, nd2) +
//                                        tsp_dist_2_nodes_f(nd2->next, nd1->next);
                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd3) +
                                        tsp_dist_2_nodes_f(nd2->next, nd1->next) +
                                        tsp_dist_2_nodes_f(nd2, nd3->next);

                             break;
                         case 6:
//                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd2->next) +
//                                        tsp_dist_2_nodes_f(nd2, nd3) +
//                                        tsp_dist_2_nodes_f(nd3->next, nd1->next);
                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd2->next) +
                                        tsp_dist_2_nodes_f(nd3, nd2) +
                                        tsp_dist_2_nodes_f(nd1->next, nd3->next);
                             break;
                         case 7:
//                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd2->next) +
//                                        tsp_dist_2_nodes_f(nd2, nd3->next) +
//                                        tsp_dist_2_nodes_f(nd3, nd1->next);
                             vdist[i] = tsp_dist_2_nodes_f(nd1, nd2->next) +
                                        tsp_dist_2_nodes_f(nd3, nd1->next) +
                                        tsp_dist_2_nodes_f(nd2, nd3->next);
                             break;

                         default: break;
                         }
                     }


                     int indx = 0;
                     int bdist = vdist[0];

                     for(int i = 1; i < 8; i++)
                     {
                         if(vdist[i] < bdist)
                         {
                             bdist = vdist[i];
                             indx = i;
                         }
                     }

                     if(indx != 0)
                     if(best_dist == -1)
                     {
                         best_dist = bdist;
                         index = indx;
                         aux_nd1 = nd1;
                         aux_nd2 = nd2;
                         aux_nd3 = nd3;
                     }
                     else if(best_dist > bdist)
                     {
                         best_dist = bdist;
                         index = indx;
                         aux_nd1 = nd1;
                         aux_nd2 = nd2;
                         aux_nd3 = nd3;
                         cnt++;
                     }

                 }
             }
         }

         //qDebug() << "Cycle = " << cycle << " -- cnt = " << cnt << "\n";

         if(best_dist != -1 &&
            aux_nd1 != NULL &&
            aux_nd2 != NULL &&
            aux_nd3 != NULL)
         {
            if(aux_nd1->next != NULL &&
               aux_nd2->next != NULL &&
               aux_nd3->next != NULL)
            {

                //tsp_2opt_swap_f2(aux_nd1, aux_nd2, aux_nd1->next, aux_nd2->next);
                printf("DO SWAP : Index : %i -- Cycle : %i  -- CNT : %i\n", index, cycle, cnt);
                switch(index)
                {
                case 1:
                    qDebug() << "Case : " << index << "\n";
                    tsp_2opt_swap_f2(aux_nd1, aux_nd3, aux_nd1->next, aux_nd3->next);
                    break;
                case 2:
                    qDebug() << "Case : " << index << "\n";
                    tsp_2opt_swap_f2(aux_nd2, aux_nd3, aux_nd2->next, aux_nd3->next);
                    break;
                case 3:
                    qDebug() << "Case : " << index << "\n";
                    tsp_2opt_swap_f2(aux_nd1, aux_nd2, aux_nd1->next, aux_nd2->next);
                    break;
                case 4:
                case 5:
                case 6:
                case 7:
                    tsp_3opt_swap_f(aux_nd1,
                                    aux_nd2,
                                    aux_nd3,
                                    aux_nd1->next,
                                    aux_nd2->next,
                                    aux_nd3->next,index);
                    break;
                default: break;
                }


            }
         }


         if(nd1->next == node || nd1->next->next == NULL)
         {
             //qDebug() << "Eq Node\n";
             if(cnt == 0) noMoreIm = true_t;
             cnt = 0;
             if(nd1->next->next == NULL) nd1 = node;
         }

     }

}



QString tsp_string_point_to_print2_f(cutting_order_t *node)
{
    std::stringstream oss;
    oss << "Point(" << node->point_col.x << ", " << node->point_col.y << ")";
    return QString::fromStdString(oss.str());
}

void tsp_print_all_costs_for_each_edge_f(cutting_order_t *node)
{
    if(node != NULL)
    for(cutting_order_t *nd = node; nd->next != NULL; nd = nd->next)
    {
        qDebug() << tsp_string_point_to_print2_f(nd) << " -- "
         << tsp_string_point_to_print2_f(nd->next)
         << " -- Len : " << tsp_dist_2_nodes_f(nd, nd->next) << "\n";
    }
}

void handler_ThDraw(cutting_order_t *node, QLabel *lbl, QLabel *lblTxt, QLabel *lblPathLen, QLabel *lblTime)
{
    int mySleep = 0;
    lblTxt->setText("Initial State");
    _sleep(500);
    int path = tsp_compute_path_cost_f(node);
    std::stringstream oss;
    oss << "Path len = " << path;
    lblPathLen->setText(QString::fromStdString(oss.str()));

    _sleep(1000);

    lblTxt->setText("Preprocess K-NearestNeighbor");
    //_sleep(500);
    //tsp_knn_preprocess2_f(node, lbl, lblPathLen, mySleep);

    QTime myTimer;
    myTimer.start();

    tsp_knn_preprocess_f(node);

    tsp_fill_last_node_when_gen_f(node);

    path = tsp_compute_path_cost_f(node);

     std::stringstream oss2;
     oss2 << "Path len = " << path;
     lblPathLen->setText(QString::fromStdString(oss2.str()));
     tsp_draw_graph_f(node, lbl);
    //_sleep(500);

    lblTxt->setText("Optimize 2-OPT");
    //_sleep(2500);
    //tsp_solver2_f(node, lbl, lblPathLen, mySleep);
    tsp_solver_3opt_f(node);
    unsigned long myTime = myTimer.elapsed();
    //qDebug() << "Time = " << ((double)(myTime)/1000.f) << "sec \n";

    std::stringstream oss_time;
    oss_time << "Time = " << ((double)(myTime)/1000.f) << " sec";
    lblTime->setText(QString::fromStdString(oss_time.str()));

    _sleep(100);

    lblTxt->setText("DONE");

    path = tsp_compute_path_cost_f(node);

    std::stringstream oss3;
    oss3 << "Path len = " << path;
    lblPathLen->setText(QString::fromStdString(oss3.str()));
    tsp_draw_graph_f(node, lbl);
    _sleep(1000);

    //tsp_undo_scale_graph_f(node,1);
    tsp_print_cutting_order_f(node);
    tsp_print_all_costs_for_each_edge_f(node);

    tsp_free_node_f(node);

    //lblTxt->setText("Free Nodes");
}


void handler_ThLKDraw(tsp_solver_t *solver, QLabel *lbl, QLabel *lblTxt, QLabel *lblPathLen, QLabel *lblTime)
{
    const char *test1 = "D:\\Proiecte\\Gemini\\Proj1\\test1.txt";

    const char *file1 = "D:\\Proiecte\\Gemini\\Proj1\\points_in_1st.txt";
    const char *file2 = "D:\\Proiecte\\Gemini\\Proj1\\points_in_2nd.txt";
    const char *file3 = "D:\\Proiecte\\Gemini\\Proj1\\points_ex1.txt";
    const char *file_p131 = "D:\\Proiecte\\Gemini\\Proj1\\points_131.txt";

    _sleep(50);
    tsp_lk_init_solver_f(&solver, 6);

    //tsp_lk_init_with_random_and_ss_nodes_f(solver, 98, 120, 220);
    //tsp_lk_add_last_node_rand_f(solver);
    qDebug() << "Here1\n";
    tsp_lk_init_with_file_f(test1, solver);

    QTime myTimer;
    myTimer.start();

    qDebug() << "Here2\n";

    tsp_lk_make_cycle_f(solver->first);

    qDebug() << "Here3\n";

    tsp_lk_knn_preprocess_f(solver);

    qDebug() << "Here4\n";

    tsp_lk_2opt_solve_f(solver);
    qDebug() << "Here5\n";
    tsp_lk_3opt_solve_f(solver);
    qDebug() << "Here6\n";
    //tsp_lk_2opt_solve_f(solver);

    tsp_lk_undo_cycle_f(solver->first);

//    tsp_lk_3opt_solve_f(solver);
//    tsp_lk_2opt_solve_f(solver);
//    tsp_lk_3opt_solve_f(solver);


    unsigned long myTime = myTimer.elapsed();


    std::stringstream oss_time;
    oss_time << "Time = " << ((double)(myTime)/1000.f) << " sec";
    lblTime->setText(QString::fromStdString(oss_time.str()));

    //int pathLen = tsp_lk_compute_path_len_f(solver);
    int auxpath = tsp_lk_compute_path_len_f(solver);
    qDebug() << "Path = " << auxpath;
    int pathLen = tsp_lk_compute_cycle_path_len_f(solver);
    std::stringstream oss3;
    oss3 << "Path len = " << pathLen;
    lblPathLen->setText(QString::fromStdString(oss3.str()));
    qDebug() << "Cities : " << tsp_lk_get_number_of_nodes_f(solver) << " \n";

    tsp_lk_scale_graph_f(solver->first, 10);

    tsp_draw_graph_f2(solver->first, lbl);
    //tsp_lk_init_with_random_f(solver,98,120,220);

    tsp_lk_free_nodes_f(solver->first);
    free(solver);
}

double get_dist_between_2_points(tsp_point_t pt1, tsp_point_t pt2)
{
    double rez = 0.f;

    double x_dist = (double)(pt1.x - pt2.x);
    x_dist = (x_dist * x_dist);
    double y_dist = (double)(pt1.y - pt2.y);
    y_dist = (y_dist * y_dist);
    rez = (double)(sqrt(x_dist + y_dist));

    return rez;
}

double get_path_len_pieces(tsp_solver_t *solver)
{
    double rez = 0.f;
    for(tsp_piece_t *pnd = solver->fpiece; pnd->next != NULL; pnd = pnd->next)
    {
        rez += get_dist_between_2_points(pnd->bestp, pnd->next->bestp);
    }
    return rez;
}

void printPieceData(tsp_solver_t *solver)
{
    for(tsp_piece_t *pnd = solver->fpiece; pnd != NULL; pnd = pnd->next)
    {
        for(tsp_node_t *nd = pnd->pnode; nd != NULL; nd = nd->next)
        {
            //printf("[%i](%i, %i) - C(%i, %i)\n", pnd->index, nd->point_col.x, nd->point_col.y,pnd->gcenter.x,pnd->gcenter.y);
            qDebug() << "[" << pnd->index << "](" << nd->point_col.x << ", " << nd->point_col.y << ") - C(" << pnd->gcenter.x << ", " << pnd->gcenter.y << ")";
        }
    }
}


int getFarestY(tsp_solver_t *solver)
{
    int max = solver->fpiece->pnode->point_col.y;
    for(tsp_piece_t *pnd = solver->fpiece; pnd != NULL; pnd = pnd->next)
    {
        for(tsp_node_t *nd = pnd->pnode; nd != NULL; nd = nd->next)
        {
            if(nd->point_col.y > max) max = nd->point_col.y;
        }
    }
    return max;
}

int getClosestY(tsp_solver_t *solver)
{
    int min = solver->fpiece->pnode->point_col.y;
    for(tsp_piece_t *pnd = solver->fpiece; pnd != NULL; pnd = pnd->next)
    {
        for(tsp_node_t *nd = pnd->pnode; nd != NULL; nd = nd->next)
        {
            if(nd->point_col.y < min) min = nd->point_col.y;
        }
    }
    return min;
}

void preprocess_points(tsp_solver_t *solver)
{
    int maxy = getFarestY(solver);
    int miny = getClosestY(solver);
    int aux = maxy + miny;

    for(tsp_piece_t *pnd = solver->fpiece; pnd != NULL; pnd = pnd->next)
    {
        for(tsp_node_t *nd = pnd->pnode; nd != NULL; nd = nd->next)
        {
            nd->point_col.y -= aux;
        }
        pnd->gcenter.y -= aux;
        pnd->gcenter_scale.y -= aux;
    }
}


void handler_ThPieceDrawLK(tsp_solver_t *solver, QLabel *lbl, QLabel *lblTxt, QLabel *lblPathLen, QLabel *lblTime)
{
    const char *test1 = "D:\\Proiecte\\Gemini\\Proj1\\test1.txt";
    const char *piece1 = "D:\\Proiecte\\Gemini\\Proj1\\clustered1.txt";

    _sleep(50);
    tsp_lk_init_solver_f(&solver, 6);
    tsp_lk_init_pieces_with_file_f(piece1, solver);
    //preprocess_points(solver);

    //tsp_lk_knn_preprocess_pieces_f(solver);
    //tsp_lk_2opt_solve_pieces_f(solver);
    QTime myTimer;
    myTimer.start();

    tsp_solver_pieces_pick_best_points(solver);

    unsigned long myTime = myTimer.elapsed();


    std::stringstream oss_time;
    oss_time << "Time = " << ((double)(myTime)/1000.f) << " sec";
    lblTime->setText(QString::fromStdString(oss_time.str()));

    _sleep(100);

    printPieceData(solver);

    int scale = 11;

    double len = get_path_len_pieces(solver);
    std::stringstream oss3;
    oss3 << "Path len = " << len;
    lblPathLen->setText(QString::fromStdString(oss3.str()));

    qDebug() << "Before Scaling";

    tsp_lk_scale_pieces(solver, 11);

    tsp_draw_pieces(solver, lbl);
    //printPieceData(solver);

    qDebug() << "Before Free";

    tsp_lk_free_nodes_f(solver->first);
    tsp_lk_free_pieces(solver->fpiece);
    free(solver);

    qDebug() << "FREE";
}


void handler_ThPartDrawPoints(tsp_partition_t *part, QLabel *lbl, QLabel *lblTxt, QLabel *lblPathLen, QLabel *lblTime)
{
    tsp_part_allocate_space(&part);
    tsp_part_init_with_random(part,120,15,1000);
    tsp_part_nearestneighbor(part,20);

    tsp_draw_part(part, lbl);

    tsp_part_free(part);
}


double getDistBetweenTwoNodes(tsp_node_t *nd1, tsp_node_t *nd2)
{
    double xox = nd1->point_col.x - nd2->point_col.x;
    double yoy = nd1->point_col.y - nd2->point_col.y;
    return (double)(sqrt(xox*xox + yoy*yoy));
}


void writeFileWithData(const char *filename, tsp_solver_t *solver, unsigned int myTime, int type)
{
    qDebug() << "GiGi";
    FILE *fp = fopen(filename, "w");

    tsp_node_t *node;

    if(type == 0) node = solver->first;
    else node = solver->best;

    double sum = 0.f;// = tsp_lk_compute_dist_between_two_points(solver->istart, node->point_col);
    //fprintf(fp, "%i %i %f", node->point_index, 0, sum);

    int countn = 0;
    for(tsp_node_t *nd = node; nd->next != NULL; nd = nd->next)
    {
        countn++;
        sum += tsp_solver_lk_compute_dist(nd->point_col, nd->next->point_col);
                //getDistBetweenTwoNodes(nd, nd->next);//tsp_lk_compute_dist_between_two_points(nd->point_col, nd->next->point_col);
        fprintf(fp, "%i %i %f\n", nd->next->point_index-1, 0, sum);
    }
    fprintf(fp, "\n\tNodes : %i", countn);
    fprintf(fp, "\n\tTime : %f sec\n", ((double)(myTime/1000.f)));

    fclose(fp);
}

void writeFileWithInputData(const char *filename, tsp_solver_t *solver)
{
    FILE *fp = fopen(filename, "w");
    tsp_node_t *node = solver->best;
    for(tsp_node_t *nd = node; nd != NULL; nd = nd->next)
    {
        fprintf(fp, "%i %i\n", nd->point_col.x, nd->point_col.y);
    }
    fclose(fp);
}

void printAllNodes(tsp_solver_t *solver)
{
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
    {
        qDebug() << "Index : " << nd->point_index << " :: p(" << nd->point_col.x << ", " << nd->point_col.y << ")";
    }
}

void tsp_swap_nodes_f11(tsp_node_t *first_nd, tsp_node_t *second_nd, tsp_node_t *third_nd)
{
    third_nd->next = second_nd->next;
    second_nd->next = first_nd->next;
    first_nd->next = second_nd;
}

void swapnd(tsp_node_t *nd1, tsp_node_t *nd2, tsp_node_t *nd2n)
{
    if(nd2->next->next == NULL) nd2->next = NULL;
    else nd2->next = nd2->next->next;
    nd2n->next = nd1->next;
    nd1->next = nd2n;
}

void lel_swap(tsp_node_t *nd1, tsp_node_t *nd2)
{
    if(nd1 != NULL)
    if(nd1->next != NULL && nd2 != NULL)
    {
    int auxx = nd1->next->point_col.x;
    int auxy = nd1->next->point_col.y;
    int auxi = nd1->next->point_index;

    nd1->next->point_col.x = nd2->point_col.x;
    nd1->next->point_col.y = nd2->point_col.y;
    nd1->next->point_index = nd2->point_index;

    nd2->point_col.x = auxx;
    nd2->point_col.y = auxy;
    nd2->point_index = auxi;
    }
}

void tsp_knn_preprocess_f11(tsp_node_t *node)
{
    if(node == NULL || node->next == NULL) return;

    int for1 = 0, for2 = 0;

    for(tsp_node_t *nd1 = node; nd1->next != NULL; nd1 = nd1->next)
    {
//        qDebug() << "for1 : " << for1++;
//        qDebug() << "---> " << nd1->point_index;
//        qDebug() << "p(" << nd1->point_col.x << ", " << nd1->point_col.y << ")";
        for2 = 0;

        double min_dist = sizeof(double)*8.f;
        tsp_node_t *aux_nd2_1, *aux_nd2_2;
        for(tsp_node_t *nd2 = nd1->next; nd2 != NULL; nd2 = nd2->next)
        {
//            qDebug() << "for2 : " << for2++;
//            qDebug() << "---> " << nd2->point_index;

            //double dist = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd2->next);
            double dist = tsp_lk_compute_dist_between_two_points(nd1->point_col, nd2->point_col);
            if(dist < min_dist)
            {
                min_dist = dist;
                aux_nd2_1 = nd2->next;
                aux_nd2_2 = nd2;
            }
        }
        tsp_swap_nodes_f11(nd1, aux_nd2_1, aux_nd2_2);
        //swapnd(nd1, aux_nd2_2, aux_nd2_1);
        //lel_swap(nd1, aux_nd2_2);
    }
}

void tsp_swap_nodes_old(tsp_node_t *first_nd, tsp_node_t *second_nd, tsp_node_t *third_nd)
{
    third_nd->next = second_nd->next;
    second_nd->next = first_nd->next;
    first_nd->next = second_nd;
}

void tsp_knn_preprocess_old(tsp_node_t *node)
{
    if(node == NULL || node->next == NULL) return;
    for(tsp_node_t *nd1 = node; nd1->next != NULL; nd1 = nd1->next)
    {
        double min_dist = DBL_MAX;
        tsp_node_t *aux_nd2_1, *aux_nd2_2;
        for(tsp_node_t *nd2 = nd1; nd2->next != NULL; nd2 = nd2->next)
        {
            double dist = tsp_lk_compute_dist_between_two_points(nd1->point_col, nd2->next->point_col);
            if(dist < min_dist)
            {
                min_dist = dist;
                aux_nd2_1 = nd2->next;
                aux_nd2_2 = nd2;
            }
        }
        tsp_swap_nodes_old(nd1, aux_nd2_1, aux_nd2_2);
    }
}

void printPoints(tsp_solver_t *solver)
{
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
    {
        qDebug() << "P" << nd->point_index << " (" << nd->point_col.x << ", " << nd->point_col.y << ")";
    }
}

void handler_3opt_test(tsp_solver_t *solver, int tf, tsp_solver_t *cpysolver, int method, int methnr)
{
    const char *test0 = "D:\\Proiecte\\Gemini\\Proj1\\co_objects_00.txt";
    const char *test1 = "D:\\Proiecte\\Gemini\\Proj1\\co_objects_01.txt";
    const char *test2 = "D:\\Proiecte\\Gemini\\Proj1\\co_objects_02.txt";

    const char *out_test0 = "D:\\Proiecte\\Gemini\\Proj1\\co_objects_ordered_00.txt";
    const char *out_test1 = "D:\\Proiecte\\Gemini\\Proj1\\co_objects_ordered_01.txt";
    const char *out_test2 = "D:\\Proiecte\\Gemini\\Proj1\\co_objects_ordered_02.txt";

    int optKMoves = 5;

    if(method == 0)
        tsp_lk_init_solver_f(&solver, optKMoves);
    else if(method == 1)
    {
        qDebug() << "blah blah 1--";
        //tsp_solver_copy(&solver, cpysolver);
    }
    const char *outfile;

    qDebug() << "Before init with file";
    if(method == 0)
    switch(tf)
    {
    case 1:
        tsp_test_3opt_init_with_file(test0, solver);
        outfile = out_test0;
        break;
    case 2:
        tsp_test_3opt_init_with_file(test1, solver);
        outfile = out_test1;
        break;
    case 3:
        tsp_test_3opt_init_with_file(test2, solver);
        outfile = out_test2;
        break;

    default : return;
    }
    else
    {
        qDebug() << "blah blah 2--";
        std::stringstream oss;
        oss << "D:\\Proiecte\\Gemini\\Proj1\\method_" << (methnr) << ".txt";
        //outfile = (const char*) oss.str().c_str();
        //qDebug() << QString::fromStdString(oss.str());
        //qDebug() << outfile;
        switch(methnr)
        {
        case 1:
            outfile = "D:\\Proiecte\\Gemini\\Proj1\\method_1.txt";
            break;
        case 2:
            outfile = "D:\\Proiecte\\Gemini\\Proj1\\method_2.txt";
            break;
        case 3:
            outfile = "D:\\Proiecte\\Gemini\\Proj1\\method_3.txt";
            break;
        case 4:
            outfile = "D:\\Proiecte\\Gemini\\Proj1\\method_4.txt";
            break;
        }
    }

   // tsp_test_3opt_init_with_file(test1, solver);
    // outfile =    out_test1;
    qDebug() << "After init with file";

_sleep(10);
    printAllNodes(solver);
    qDebug() << "Before KNN";
    //tsp_lk_knn_preprocess_f(solver);
    //tsp_knn_preprocess_f11(solver->first);

    QTime myTimer;
    myTimer.start();

    tsp_knn_preprocess_old(solver->first);

    //qDebug() << "---KNN--- : " << (methnr);
    //printAllNodes(solver);

    //qDebug() << "Before 3opt";
    tsp_lk_make_cycle_f(solver->first);
    //tsp_lk_3opt_solve_f(solver);
    double gain;
    //tsp_solver_lk_lk(solver, gain, 2, 5, 10);
    //tsp_solver_lk_test_4opt(solver);
    //tsp_solver_lk_lk2(solver, 2, optKMoves, -1);
    //tsp_solver_lk_lk3(solver, 2, optKMoves, 10);

    switch(methnr)
    {
    case 1:
        //qDebug() << "blah blah 3_1 --";
        tsp_lk_3opt_solve_f(solver);
        break;
    case 2:
        //qDebug() << "blah blah 3_2 --";
        tsp_solver_lk_lk2(solver, 2, optKMoves, -1); // '-1'  means  infinite
        break;
    case 3:
        //qDebug() << "blah blah 3_3 --";
        tsp_solver_lk_lk3(solver, 2, optKMoves, 9);
        break;
    case 4:
        tsp_solver_3opt_with_4opt_perturbation(solver);
        break;
    }

    //qDebug() << "Before undoing cycle";

    unsigned long myTime = myTimer.elapsed();
    qDebug() << "Time = " << ((double)(myTime)/1000.f) << " sec";


    tsp_lk_undo_cycle_f(solver->first);

    qDebug() << "Before writing";
    if(methnr == 1)
        writeFileWithData(outfile, solver, myTime, methnr-1);
    else if(methnr == 4)
        writeFileWithData(outfile, solver, myTime, 0);
    else writeFileWithData(outfile, solver, myTime, methnr-1);
    printPoints(solver);


    qDebug() << "Before free";
    //tsp_lk_free_nodes_f(solver->first);
    //free(solver);
}


void numAllPointIndex(tsp_solver_t *solver)
{
    int count_nd = 0;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
    {
        nd->point_index = count_nd;
        count_nd++;
    }
}


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    srand(time(0));

    cutting_order_t *node = (cutting_order_t*)malloc(sizeof(cutting_order_t));
    node->next = NULL;

    //tsp_solver_t *solver = (tsp_solver_t*)malloc(sizeof(tsp_solver_t));
    tsp_solver_t *solver1, *solver2, *solver3;

    //tsp_fill_from_file_f(node, "D:\\Proiecte\\Gemini\\Proj1\\nodes.txt");
    //tsp_fill_from_file_f(node, "D:\\Proiecte\\Gemini\\Proj1\\points_in_1st.txt");
    //tsp_fill_from_file_f(node, "D:\\Proiecte\\Gemini\\Proj1\\points_in_2nd.txt");

    //tsp_generate_sample_f(node, 98, 120, 220);
    //tsp_fill_first_node_when_gen_f(node);

    //node = node->next;


    QLabel *lbl = new QLabel;
    QLabel *lblTxt = new QLabel;
    QLabel *lblPathLen = new QLabel;
    QLabel *lblTime = new QLabel;

    //QPicture pic;
    //QPainter painter(&pic);
    QGroupBox grBox;
    QVBoxLayout *vBox = new QVBoxLayout;

    tsp_scale_graph_f(node,1);
    tsp_draw_graph_f(node, lbl);

    vBox->addWidget(lbl);
    vBox->addWidget(lblTxt);
    vBox->addWidget(lblPathLen);
    vBox->addWidget(lblTime);

    grBox.setLayout(vBox);

    std::stringstream oss_time;
    oss_time << "Time = -idk- sec";
    lblTime->setText(QString::fromStdString(oss_time.str()));

    //std::thread th_lk_draw(handler_ThLKDraw, solver, lbl, lblTxt, lblPathLen, lblTime);
    //th_lk_draw.detach();

//    std::thread th_lk_drawPiece(handler_ThPieceDrawLK, solver, lbl, lblTxt, lblPathLen, lblTime);
//    th_lk_drawPiece.detach();
//    _sleep(2);

    tsp_partition_t *part;
int cc = 1;
    //qDebug() << "Here 1 " << cc++ ;
    //tsp_kopt_list_t *klist;
    //qDebug() << "Here 2 " << cc++ ;
    //kopt_gen_nod_init(&klist);
    //qDebug() << "Here 3 " << cc++ ;
    //kopt_generate_all_permutations(klist, 6);



    //qDebug() << "Here 4 " << cc++ ;
    //kopt_print_perm(klist);
    //qDebug() << "Here 5 " << cc++ ;

    //kopt_gen_nod_free(klist->start);
    //kopt_gen_list_free(klist);

//    std::thread th_part_drawPart(handler_ThPartDrawPoints, part, lbl, lblTxt, lblPathLen, lblTime);
//    th_part_drawPart.detach();
//    _sleep(2);


//    std::thread th_3opt_test1(handler_3opt_test, solver1, 1);
//    th_3opt_test1.detach();
//    std::thread th_3opt_test2(handler_3opt_test, solver2, 2);
//    th_3opt_test2.detach();
//    std::thread th_3opt_test3(handler_3opt_test, solver3, 3);
//    th_3opt_test3.detach();


    const char *test0 = "D:\\Proiecte\\Gemini\\Proj1\\co_objects_00.txt";
    const char *test1 = "D:\\Proiecte\\Gemini\\Proj1\\co_objects_01.txt";
    const char *test2 = "D:\\Proiecte\\Gemini\\Proj1\\co_objects_02.txt";


    tsp_solver_t *msolver, *solver11, *solver22, *solver33;

    tsp_lk_init_solver_f(&msolver, 5);

//    tsp_lk_init_with_random_and_ss_nodes_f(msolver, 98, 120, 220);
//    tsp_lk_add_last_node_rand_f(msolver);

    tsp_test_3opt_init_with_file(test1, msolver);

    msolver->number_of_nodes = 0;
    for(tsp_node_t *nd = msolver->first; nd != NULL; nd = nd->next)
    {
        msolver->number_of_nodes++;
    }

    //tsp_lk_init_with_file_f("D:\\Proiecte\\Gemini\\Proj1\\method_input.txt", msolver);

    //numAllPointIndex(msolver);




    tsp_solver_lk_init_best_list(msolver);
    //tsp_solver_copy_node_list(&(msolver->best), msolver->first);


    printAllNodes(msolver);

    writeFileWithInputData("D:\\Proiecte\\Gemini\\Proj1\\method_input.txt", msolver);


    //std::thread th_lk_th1(handler_3opt_test,solver11,1,msolver,1,1);
    //th_lk_th1.detach();

    //std::thread th_lk_th2(handler_3opt_test,solver22,1,msolver,1,2);
    //th_lk_th2.detach();

    //std::thread th_lk_th3(handler_3opt_test,solver33,1,msolver,1,3);
    //th_lk_th3.detach();


    handler_3opt_test(msolver,1,msolver,1,1);
    _sleep(50);
    handler_3opt_test(msolver,1,msolver,1,2);
    _sleep(50);
    handler_3opt_test(msolver,1,msolver,1,4);
    _sleep(50);
    handler_3opt_test(msolver,1,msolver,1,3);
    _sleep(50);

    //th_lk_th2.join();
    //th_lk_th3.join();

    //std::thread th_draw(handler_ThDraw, node, lbl, lblTxt, lblPathLen, lblTime);
    //th_draw.detach();

    _sleep(100);

    tsp_lk_free_nodes_f(msolver->first);
    //tsp_lk_free_nodes_f(solver11->first);
    //tsp_lk_free_nodes_f(solver22->first);
    //tsp_lk_free_nodes_f(solver33->first);

    free(msolver);
    //free(solver11);
    //free(solver22);
    //free(solver33);


    grBox.show();

    //tsp_free_node_f(node);
    return a.exec();
}
