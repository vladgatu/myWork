#ifndef TSP_LIN_KERNIGHAN_ALG_AUX_H
#define TSP_LIN_KERNIGHAN_ALG_AUX_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random>
#include <math.h>
#include <QDebug>

#include "tsp_point_struct.h"
#include "tsp_node_struct.h"
#include "tsp_bool.h"

#include "tsp_generate_kopt_perm.h"
#include "tsp_aux_helper_funct.h"

#define min_f(a,b) ((a > b) ? (b) : (a))
#define max_f(a,b) ((a < b) ? (b) : (a))

#define INF_T 1e30

typedef struct tsp_edge_s
{
    tsp_point_t p1, p2;
    unsigned int dist;
} tsp_edge_t;

typedef struct tsp_nodes_list_s
{
    tsp_node_t *list;
    int len;
} tsp_nodes_list_t;

typedef struct tsp_centroids_s
{
    tsp_point_t *centr_point;
    int len;
    tsp_nodes_list_t *points_of_centroids;
} tsp_centroids_t;

typedef struct tsp_piece_s
{
    int index;
    tsp_node_t *pnode;
    tsp_point_t gcenter;
    tsp_point_t gcenter_scale;
    tsp_point_t bestp;
    int max_x, min_x, max_y, min_y;
    tsp_piece_s *next;
}tsp_piece_t;


typedef struct tsp_swap_positions_s
{
    int typeOpt;
    int *swapSecvPos;
    int size_secv;
    int *swapNonSecvPos;
    int size_non_secv;
} tsp_swap_positions_t;

typedef struct tsp_solver_s
{
    tsp_point_t istart;

    double bestLen;
    tsp_node_t *best;

    tsp_node_t *first;
    tsp_node_t *last;
    unsigned int number_of_nodes;
    unsigned int initial_path_len;
    unsigned int after_nn_path_len;
    unsigned int after_lk_path_len;

    tsp_edge_t *all_edges;
    unsigned int number_of_edges;

    int max_x, max_y;
    int min_x, min_y;

    tsp_centroids_t centr;

    tsp_piece_t *fpiece;

    tsp_kopt_list_t *opt2list;
    tsp_kopt_list_t *opt3list;
    tsp_kopt_list_t *opt4list;
    tsp_kopt_list_t *opt5list;

    tsp_kopt_list_t **optKlist;
    int maxKopt;

    tsp_swap_positions_s *swapPos;
    int size_swapPos;

    int *prime_vect;
    int prime_vect_size;

    int *hash_numbers;
    int hash_numbers_size;
    int hash_numbers_last_index;

} tsp_solver_t;


bool_t tsp_solver_lk_is_negative_swap(int *vect, int size)
{
    int i = 0;
    for(i = 0; i < size; i++)
    {
        if(vect[i] < 0) return true_t;
    }
    return false_t;
}

int tsp_solver_lk_get_number_of_secv_swaps(tsp_kopt_list_t *klist)
{
    int i = 0, count = 0;
    for(i = 0; i < klist->size; i++)
    {
        if(tsp_solver_lk_is_negative_swap(klist->mat[i], klist->k) == true_t)
            count++;
    }
    return count;
}



void tsp_solver_copy_node_list(tsp_node_t **dest1, tsp_node_t *src)
{
    bool_t firstn = true_t;
    tsp_node_t *dest, *dst = dest;
    int count = 0;
    for(tsp_node_t *nd = src; nd != NULL; nd = nd->next)
    {
        if(firstn == true_t)
        {
            //qDebug() << "first node : c : " << (++count);
            dest = (tsp_node_t*)calloc(1, sizeof(tsp_node_t));
            dest->next = NULL;

            firstn = false_t;
        }
        else if(firstn == false_t)
        {
            //qDebug() << "next node : c : " << (++count);
            tsp_node_t *nnode = (tsp_node_t*)calloc(1, sizeof(tsp_node_t));
            nnode->next = NULL;
            dest->next = nnode;
            dest = dest->next;
        }

        dest->partition_index = src->partition_index;
        dest->point_index = src->point_index;
        memcpy(&dest->point_col, &src->point_col, sizeof(tsp_point_t));
        //dest1 = &dst;
        (*dest1) = dst;
    }

//    for(tsp_node_t *nd = (*dest1); nd != NULL; nd = nd->next)
//    {
//        qDebug() << "P" << nd->point_index << " (" << nd->point_col.x << ", " << nd->point_col.y << ")";
//    }

//    exit(0);
}

void tsp_solver_copy_pieces(tsp_solver_t *solver_dest, tsp_solver_t *solver_src)
{
    bool_t firstp = true_t;
    if(solver_src->fpiece != NULL)
    {
        for(tsp_piece_t *pnd = solver_src->fpiece; pnd != NULL; pnd = pnd->next)
        {
            if(firstp == true_t)
            {
                solver_dest->fpiece = (tsp_piece_t*)malloc(sizeof(tsp_piece_t));
                solver_dest->fpiece->next = NULL;
                firstp = false_t;
            }
            else
            {
                tsp_piece_t *npiece = (tsp_piece_t*)malloc(sizeof(tsp_piece_t));
                npiece->next = NULL;
                solver_dest->fpiece->next = npiece;
                solver_dest->fpiece = solver_dest->fpiece->next;
            }
            memcpy(&solver_dest->fpiece->bestp, &solver_src->fpiece->bestp, sizeof(tsp_point_t));
            memcpy(&solver_dest->fpiece->gcenter, &solver_src->fpiece->gcenter, sizeof(tsp_point_t));
            memcpy(&solver_dest->fpiece->gcenter_scale, &solver_src->fpiece->gcenter_scale, sizeof(tsp_point_t));

            solver_dest->fpiece->index = solver_src->fpiece->index;
            solver_dest->fpiece->max_x = solver_src->fpiece->max_x;
            solver_dest->fpiece->max_y = solver_src->fpiece->max_y;
            solver_dest->fpiece->min_x = solver_src->fpiece->min_x;
            solver_dest->fpiece->min_y = solver_src->fpiece->min_y;

            tsp_solver_copy_node_list(&(solver_dest->fpiece->pnode), solver_src->fpiece->pnode);
        }
    }
}

void tsp_solver_copy_koptmoves(tsp_solver_t *solverd, tsp_solver_t *solvers)
{
    solverd->maxKopt = solvers->maxKopt;
    solverd->optKlist = (tsp_kopt_list_t**)calloc(solverd->maxKopt, sizeof(tsp_kopt_list_t*));

    int i = 0;
    for(i = 0; i < solvers->maxKopt; i++)
    {
        solverd->optKlist[i] = solvers->optKlist[i];
    }
}

void tsp_solver_copy_swap_pos(tsp_solver_t *solverd, tsp_solver_t *solvers)
{
    solverd->size_swapPos = solvers->size_swapPos;
    solverd->swapPos = solvers->swapPos;
}

void tsp_solver_copy(tsp_solver_t **solver_dest, tsp_solver_t *solver_src)
{
    *solver_dest = (tsp_solver_t*)malloc(sizeof(tsp_solver_t));
    //tsp_solver_copy_pieces(*solver_dest, solver_src);
    tsp_solver_copy_node_list(&((*solver_dest)->first), solver_src->first);

    tsp_solver_copy_koptmoves(*solver_dest, solver_src);
    tsp_solver_copy_swap_pos(*solver_dest, solver_src);

    qDebug() << "-----> Printing All Cpy Solver <-----";

    for(tsp_node_t *nd = (*solver_dest)->first; nd != NULL; nd = nd->next)
    {
        qDebug() << "I : " << nd->point_index << "  P(" << nd->point_col.x << ", " << nd->point_col.y << ")";
    }

    qDebug() << "";

//    for(int i = 0; i < (*solver_dest)->maxKopt - 1; i++)
//    {
//        qDebug() << "K = " << (i+2) << "  Size : " << (*solver_dest)->optKlist[i]->size;
//        int countt = 0;
//        for(int j = 0; j < (*solver_dest)->optKlist[i]->size; j++)
//        {
//            qDebug() << "Count : " << (++countt);
//            for(int l = 0; l < (*solver_dest)->optKlist[i]->k; l++)
//            {
//                qDebug() << (*solver_dest)->optKlist[i]->mat[j][l];
//            }
//        }
//    }


    qDebug() << "-------------------------------------";

}

void tsp_lk_init_solver_f(tsp_solver_t **solver, int maxk)
{
    srand(time(0));
    *solver = (tsp_solver_t*)malloc(sizeof(tsp_solver_t));

    (*solver)->fpiece = NULL;

    (*solver)->istart.x = 0;
    (*solver)->istart.y = 0;

    (*solver)->bestLen = DBL_MAX;
    (*solver)->best = NULL;

    (*solver)->first = NULL;
    (*solver)->last = NULL;
    (*solver)->after_lk_path_len = 0;
    (*solver)->after_nn_path_len = 0;
    (*solver)->initial_path_len = 0;
    (*solver)->number_of_edges = 0;
    (*solver)->number_of_nodes = 0;
    (*solver)->max_x = 0;
    (*solver)->max_y = 0;
    (*solver)->min_x = 0;
    (*solver)->min_y = 0;
    (*solver)->centr.points_of_centroids = NULL;
    (*solver)->centr.centr_point = NULL;
    (*solver)->centr.len = 0;
    (*solver)->all_edges = NULL;

    int k = maxk;
    int prime_vect_size = 20;

    (*solver)->prime_vect = (int*)calloc(prime_vect_size, sizeof(int));
    (*solver)->prime_vect_size = prime_vect_size;

    int hash_numbers_size = 50;
    (*solver)->hash_numbers = (int*)calloc(hash_numbers_size, sizeof(int));
    (*solver)->hash_numbers_last_index = 0;
    (*solver)->hash_numbers_size = hash_numbers_size;

    helper_fill_vect_with_prime_numbers((*solver)->prime_vect, (*solver)->prime_vect_size);

    (*solver)->optKlist = (tsp_kopt_list_t**)calloc(k, sizeof(tsp_kopt_list_t*));
    (*solver)->maxKopt = k;

    int i = 2;

    for(i = 2; i <= k; i++)
    {
        kopt_gen_nod_init(&((*solver)->optKlist[i-2]));
        kopt_generate_all_permutations((*solver)->optKlist[i-2], i);
    }

    (*solver)->swapPos = (tsp_swap_positions_s*)calloc(k-3, sizeof(tsp_swap_positions_s));
    (*solver)->size_swapPos = k-3;

    //int xxx = 0;
    //qDebug() << "Aici " << (++xxx) << " k-3 = " << k-3;

    for(i = 0; i < k-3; i++)
    {
        //i+3 -> ?
        int secv_swap_count = tsp_solver_lk_get_number_of_secv_swaps((*solver)->optKlist[i+2]) + 1;
        //qDebug() << "Aici 22 " << (++xxx);
        int nonsecv_swap_count = abs((*solver)->optKlist[i+2]->size - secv_swap_count) + 1;

        (*solver)->swapPos[i].swapNonSecvPos = (int*)calloc(nonsecv_swap_count, sizeof(int));
        (*solver)->swapPos[i].swapSecvPos = (int*)calloc(secv_swap_count, sizeof(int));

        (*solver)->swapPos[i].typeOpt = i + 4;
        (*solver)->swapPos[i].swapSecvPos[0] = 0;
        (*solver)->swapPos[i].swapNonSecvPos[0] = 0;

        qDebug() << "i = " << i;
        qDebug() << "k-3 = " << (k-3);
        qDebug() << "non secv nr = " << nonsecv_swap_count;
        qDebug() << "secv nr = " << secv_swap_count << "\n";

        //qDebug() << "Aici 2" << (++xxx);

        int nonsecv_swap_index = 1;
        int secv_swap_index = 1;
        int j = 0;

        (*solver)->swapPos[i].size_secv = secv_swap_count;
        (*solver)->swapPos[i].size_non_secv = nonsecv_swap_count;

        //qDebug() << "Aici 3" << (++xxx);

        for(j = 1; j < (*solver)->optKlist[i+2]->size; j++)
        {
            if(tsp_solver_lk_is_negative_swap((*solver)->optKlist[i+2]->mat[j], (*solver)->optKlist[i+2]->k) == true_t)
            {
                if(secv_swap_index < secv_swap_count)
                {
                    (*solver)->swapPos[i].swapSecvPos[secv_swap_index] = j;
                    secv_swap_index++;
                }
            }
            else
            {
                if(nonsecv_swap_index < nonsecv_swap_count)
                {
                    (*solver)->swapPos[i].swapNonSecvPos[nonsecv_swap_index] = j;
                    nonsecv_swap_index++;
                }
            }
        }

        /*
        int l;
        for(l = 0; l < (*solver)->swapPos[i].size_secv; l++)
        {
            qDebug() << "secv : " << (*solver)->swapPos[i].swapSecvPos[l];
        }
        qDebug() << "\n";

        for(l = 0; l < (*solver)->swapPos[i].size_non_secv; l++)
        {
            qDebug() << "non secv : " << (*solver)->swapPos[i].swapNonSecvPos[l];
        }
        qDebug() << "\n";
        */

        //qDebug() << "Aici 4" << (++xxx);
    }



//    kopt_gen_nod_init(&((*solver)->opt2list));
//    kopt_gen_nod_init(&((*solver)->opt3list));
//    kopt_gen_nod_init(&((*solver)->opt4list));
//    kopt_gen_nod_init(&((*solver)->opt5list));

//    kopt_generate_all_permutations((*solver)->opt2list, 2);
//    kopt_generate_all_permutations((*solver)->opt3list, 3);
//    kopt_generate_all_permutations((*solver)->opt4list, 4);
//    kopt_generate_all_permutations((*solver)->opt5list, 5);
//exit(0);
    //qDebug() << "Aici 5" << (++xxx);
}

void tsp_solver_lk_init_best_list(tsp_solver_t *solver)
{
    tsp_node_t *node = solver->first;
    //tsp_node_t *bestn = solver->best;
    solver->best = (tsp_node_t*)calloc(1, sizeof(tsp_node_t));
    solver->best->next = NULL;
    tsp_node_t *bestn = solver->best;


    bool_t firstn = true_t;
    int count = 0;

    for(tsp_node_t *nd = node; nd != NULL; nd = nd->next)
    {
        if(firstn == true_t)
        {
            qDebug() << "first node : c : " << (++count);
//            bestn1 = (tsp_node_t*)calloc(1, sizeof(tsp_nodes_list_t));
            bestn->next = NULL;
            firstn = false_t;
        }
        else
        {
            qDebug() << "next node : c : " << (++count);
            tsp_node_t *nod = (tsp_node_t*)calloc(1, sizeof(tsp_node_t));
            nod->next = NULL;
            bestn->next = nod;
            bestn = bestn->next;
        }

        bestn->partition_index = nd->partition_index;
        bestn->point_index = nd->point_index;
        bestn->point_col.x = nd->point_col.x;
        bestn->point_col.y = nd->point_col.y;
    }

//    if(bestn != NULL)
//    {
//        qDebug() << "NOT NULL";
//        qDebug() << "P" << bestn->point_index << " (" << bestn->point_col.x << ", " << bestn->point_col.y << ")";
//    }
//    else qDebug() << "NULL NULL NULL";

//    for(tsp_node_t *nd = solver->best; nd != NULL /*&& nd->next != solver->best*/; nd = nd->next)
//    {
//        qDebug() << "P" << nd->point_index << " (" << nd->point_col.x << ", " << nd->point_col.y << ")";
//    }

//    exit(0);
}

void tsp_solver_lk_copy_best_list(tsp_solver_t *solver, double path_len)
{
    tsp_node_t *node = solver->first;
    tsp_node_t *bestn = solver->best;

    for(tsp_node_t *nd1 = bestn, *nd2 = node; nd1 != NULL && nd2 != NULL; nd1 = nd1->next, nd2 = nd2->next)
    {
        nd1->partition_index = nd2->partition_index;
        nd1->point_index = nd2->point_index;
        nd1->point_col.x = nd2->point_col.x;
        nd1->point_col.y = nd2->point_col.y;
    }

    solver->bestLen = path_len;
}

/* add node at end */
void tsp_lk_append_node_f(tsp_solver_t *solver, tsp_node_t *last_node)
{
    tsp_node_t *node = solver->first;
    for(tsp_node_t *nd = node; nd != NULL; nd = nd->next)
    {
        if(nd->next == NULL)
        { nd->next = last_node; break; }
    }
    solver->last = last_node;
}

/* add node at beginning */
void tsp_lk_put_first_node_f(tsp_solver_t *solver, tsp_node_t *first_node)
{
    first_node->next = solver->first;
    solver->first = first_node;
}

/* get min X of all points */
int tsp_lk_get_min_x_f(tsp_solver_t *solver)
{
    if(solver->first == NULL) return -1;
    int min = solver->first->point_col.x;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        if(min > nd->point_col.x) min = nd->point_col.x;
    return min;
}

/* get max X of all points */
int tsp_lk_get_max_x_f(tsp_solver_t *solver)
{
    if(solver->first == NULL) return -1;
    int max = solver->first->point_col.x;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        if(max < nd->point_col.x) max = nd->point_col.x;
    return max;
}

/* get min Y of all points */
int tsp_lk_get_min_y_f(tsp_solver_t *solver)
{
    if(solver->first == NULL) return -1;
    int min = solver->first->point_col.y;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        if(min > nd->point_col.y) min = nd->point_col.y;
    return min;
}

/* get max Y of all points */
int tsp_lk_get_max_y_f(tsp_solver_t *solver)
{
    if(solver->first == NULL) return -1;
    int max = solver->first->point_col.y;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        if(max < nd->point_col.y) max = nd->point_col.y;
    return max;
}

/* add first node when init with random points */
void tsp_lk_add_first_node_rand_f(tsp_solver_t *solver)
{
    int max_y = tsp_lk_get_max_y_f(solver);
    int min_x = tsp_lk_get_min_x_f(solver);
    tsp_node_t *node = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    node->next = NULL;
    node->point_col.x = min_x;
    node->point_col.y = max_y;
    tsp_lk_put_first_node_f(solver, node);
}

/* add last node when init with random points */
void tsp_lk_add_last_node_rand_f(tsp_solver_t *solver)
{
    int max_x = tsp_lk_get_max_x_f(solver);
    int min_y = tsp_lk_get_min_y_f(solver);
    tsp_node_t *node = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    node->next = NULL;
    node->point_col.x = max_x;
    node->point_col.y = min_y;
    tsp_lk_append_node_f(solver, node);
}

/* get distance between two nodes */
double  tsp_lk_compute_dist_between_two_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2)
{
    double x_dist = (nd1->point_col.x - nd2->point_col.x);
    x_dist = (x_dist * x_dist);
    double y_dist = (nd1->point_col.y - nd2->point_col.y);
    y_dist = (y_dist * y_dist);
    double rez = sqrt(x_dist + y_dist);
    return rez;
}

double tsp_lk_compute_dist_between_two_nodes(tsp_node_t *nd1, tsp_node_t *nd2)
{
    double x_dist = (double)(nd1->point_col.x - nd2->point_col.x);
    x_dist = (x_dist * x_dist);
    double y_dist = (double)(nd1->point_col.y - nd2->point_col.y);
    y_dist = (y_dist * y_dist);
    double rez = (double)(sqrt(x_dist + y_dist));
    return rez;
}

int  tsp_lk_compute_dist_between_two_points_f(tsp_point_t nd1, tsp_point_t nd2)
{
    int x_dist = (int)(nd1.x - nd2.x);
    x_dist = (x_dist * x_dist);
    int y_dist = (int)(nd1.y - nd2.y);
    y_dist = (y_dist * y_dist);
    //double rez = sqrt((double)(x_dist + y_dist));
    double rez = (double)(sqrt(x_dist + y_dist));
    return (int)rez;
}

double tsp_lk_compute_dist_between_two_points(tsp_point_t nd1, tsp_point_t nd2)
{
    double x_dist = (double)(nd1.x - nd2.x);
    x_dist = (x_dist * x_dist);
    double y_dist = (double)(nd1.y - nd2.y);
    y_dist = (y_dist * y_dist);
    //double rez = sqrt((double)(x_dist + y_dist));
    double rez = (double)(sqrt(x_dist + y_dist));
    return rez;
}

/* get lenght of path */
long tsp_lk_compute_path_len_f(tsp_solver_t *solver)
{
    long rez = 0;
    for(tsp_node_t *nd = solver->first; nd->next != NULL; nd = nd->next)
        rez += (tsp_lk_compute_dist_between_two_nodes_f(nd, nd->next));
    return rez;
}

/* get lenght of path when cycle */
long tsp_lk_compute_cycle_path_len_f(tsp_solver_t *solver)
{
    printf("compute cycle path len\n");

    long rez = 0;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
    {
        if(nd->next != NULL)
            rez += (tsp_lk_compute_dist_between_two_nodes_f(nd, nd->next));
        else rez += (tsp_lk_compute_dist_between_two_nodes_f(nd, solver->first));
    }
    return rez;
}

/* get lenght of path between two nodes */


long tsp_lk_compute_path_len_between_two_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2)
{
    long rez = 0;
    for(tsp_node_t *nd = nd1; nd->next != NULL && nd->next != nd2; nd = nd->next)
        rez += (tsp_lk_compute_dist_between_two_nodes_f(nd, nd->next));
    return rez;
}

/* get number of nodes */
int tsp_lk_get_number_of_nodes_f(tsp_solver_t *solver)
{
    int nr = 0;
    for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next) nr++;
    return nr;
}

void tsp_lk_scale_graph_f(tsp_node_t *node, int scale)
{
    for(tsp_node_t *nd = node; nd != NULL; nd = nd->next)
    {
        nd->point_col.x *= scale;
        nd->point_col.y *= scale;
    }
}

void tsp_lk_undo_scale_graph_f(tsp_node_t *node, int scale)
{
    for(tsp_node_t *nd = node; nd != NULL; nd = nd->next)
    {
        nd->point_col.x /= scale;
        nd->point_col.y /= scale;
    }
}

void tsp_lk_make_cycle_f(tsp_node_t *node)
{
    tsp_node_t *nd = node;
    while(node->next != NULL)
    { node = node->next; }
    node->next = nd;
}

void tsp_lk_undo_cycle_f(tsp_node_t *node)
{
    tsp_node_t *nod = node;
    for(tsp_node_t *nd = node->next; nd != NULL; nd = nd->next)
    {
        if(nd->next == nod)
        {
            printf("Found\n");
            nd->next = NULL;
            break;
        }
    }
}


long readInt(char *buff, int size, int pos)
{
    long nr = 0;
    int nrcount = 1;
    for(int i = 0; i < size; i++)
    {
        if(pos == nrcount && buff[i] != ' ' && buff[i] != '\n')
        {
            if(buff[i] == ' ' || buff[i] == '\n' || buff[i] == '\0') break;
            nr = nr * 10 + (buff[i] - '0');
        }
        else
        {
            if(buff[i] == ' ') nrcount++;
        }
    }
    return nr;
}


void tsp_test_3opt_init_with_file(const char *filename, tsp_solver_t *solver)
{
    FILE *fd = fopen(filename, "r");
    char buff[128];
    memset(&buff, 0, sizeof(buff));

    solver->first = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    solver->first->next = NULL;

    tsp_node_t *node = solver->first;

    int lcount = 0, pcount = 0;
    long pnr = 0;
    bool_t canContinue = false_t;

    while(fgets(buff, sizeof(buff), fd))
    {
        if(lcount == 0)
        {
            solver->istart.x = readInt(buff, 128, 1);
            solver->istart.y = readInt(buff, 128, 2);
            qDebug() << "IStart = p(" << solver->istart.x << ", " << solver->istart.y << ")";
//            node->point_col.x = 0;
//            node->point_col.y = 0;
//            node->next = (tsp_node_t*)malloc(sizeof(tsp_node_t));
//            node = node->next;
//            node->next = NULL;
            lcount++;
        }
        else if(lcount == 1)
        {
            pnr = readInt(buff, 128, 1);
            qDebug() << "PNR = " << pnr;
            lcount++;
        }
        else
        {
            lcount++;
            if(buff[0] == '1' && buff[1] == ' ')
            {
                qDebug() << "yes";
                canContinue = true_t;
                continue;
            }
            else
            {
                qDebug() << "no";
                if(canContinue == true_t)
                {
                    if(pcount < pnr)
                    {
                        if(pcount + 1 == pnr)
                        {
                            long nrx = readInt(buff, 128, 1);
                            long nry = readInt(buff, 128, 2);
                            node->point_index = pcount+1;
                            node->point_col.x = nrx;
                            node->point_col.y = nry;
                            node->next = NULL;
                            qDebug() << "(" << nrx << ", " << nry << ")";
                            pcount++;
                        }
                        else
                        {
                            long nrx = readInt(buff, 128, 1);
                            long nry = readInt(buff, 128, 2);
                            node->point_index = pcount+1;
                            node->point_col.x = nrx;
                            node->point_col.y = nry;
                            node->next = (tsp_node_t*)malloc(sizeof(tsp_node_t));
                            node->next->next = NULL;
                            node = node->next;
                            qDebug() << "(" << nrx << ", " << nry << ")";
                            pcount++;
                        }
                    }
                    canContinue = false_t;
                    qDebug() << "Continue";
                }
                else qDebug() << "NoCont";
            }
        }
    }

    tsp_node_t *nod = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    nod->point_col.x = solver->istart.x;
    nod->point_col.y = solver->istart.y;
    nod->point_index = 0;
    nod->next = solver->first;
    solver->first = nod;

    fclose(fd);
}


/* init solver with nodes from file */
void tsp_lk_init_with_file_f(const char *name_of_file, tsp_solver_t *solver)
{
    FILE *fd = fopen(name_of_file, "r");
    char buff[128];
    memset(&buff, 0, sizeof(buff));

    solver->first = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    solver->first->next = NULL;

    tsp_node_t *node = solver->first;

    bool_t firstNode = true_t;

    int nodenr = 0;

    while(fgets(buff, sizeof(buff),fd))
    {
        int nr = 0;
        if(firstNode == false_t)
        {
            tsp_node_t *nod = (tsp_node_t*)malloc(sizeof(tsp_node_t));
            nod->point_index = ++nodenr;
            for(int i = 0; i < 128; i++)
            {
                if(buff[i] != '\n' && buff[i] != EOF)
                {
                    if(buff[i] != ' ') nr = nr * 10 + (buff[i] - '0');
                    else
                    {
                        nod->point_col.x = nr;
                        nr = 0;
                    }
                }
                else
                {
                    nod->point_col.y = nr;
                    node->next = nod;
                    node = node->next;
                    node->next = NULL;
                    break;
                }
            }
        }
        else if(firstNode == true_t)
        {
            node->point_index = ++nodenr;
            for(int i = 0; i < 128; i++)
            {
                if(buff[i] != '\n' && buff[i] != EOF)
                {
                    if(buff[i] != ' ') nr = nr * 10 + (buff[i] - '0');
                    else
                    {
                        node->point_col.x = nr;
                        nr = 0;
                    }
                }
                else { node->point_col.y = nr; break; }
            }
            firstNode = false_t;
        }
        memset(&buff, 0, sizeof(buff));
    }

//    solver->last = node;
//    solver->initial_path_len = tsp_lk_compute_path_len_f(solver);
//    solver->number_of_nodes = tsp_lk_get_number_of_nodes_f(solver);

    fclose(fd);
}

//char delimiters[] = "= \n\t\r\f\v\xef\xbb\xbf";

void tsp_lk_compute_piece_center(tsp_solver_t *solver)
{
    int pcount = 0;
    int count = 0;
    int x = 0, y = 0;

    for(tsp_piece_t *pnd = solver->fpiece; pnd != NULL; pnd = pnd->next)
    {
        count++;
        tsp_node_t *nd;
        for(nd = pnd->pnode; nd != NULL; nd = nd->next)
        {
            x += nd->point_col.x;
            y += nd->point_col.y;
            pcount++;
        }
        pnd->gcenter.x = x/pcount;
        pnd->gcenter.y = y/pcount;
        pnd->index = count;
        pcount = 0;
        x = 0;
        y = 0;
        pnd->bestp.x = -1;
        pnd->bestp.y = -1;
    }
}

void tsp_lk_compute_piece_sclae_center(tsp_solver_t *solver)
{
    int pcount = 0;
    int x = 0, y = 0;

    for(tsp_piece_t *pnd = solver->fpiece; pnd != NULL; pnd = pnd->next)
    {
        tsp_node_t *nd;
        for(nd = pnd->pnode; nd != NULL; nd = nd->next)
        {
            x += nd->point_col.x;
            y += nd->point_col.y;
            pcount++;
        }
        pnd->gcenter_scale.x = x/pcount;
        pnd->gcenter_scale.y = y/pcount;
        pcount = 0;
        x = 0;
        y = 0;

        if(pnd->next == solver->fpiece) break;
    }
}

void tsp_solver_piece_scale_best_point(tsp_solver_t *solver, int scale)
{
    for(tsp_piece_t *pnd = solver->fpiece; pnd != NULL; pnd = pnd->next)
    {
        if(pnd->bestp.x != -1 && pnd->bestp.y != -1)
        {
            pnd->bestp.x *= scale;
            pnd->bestp.y *= scale;
        }
        if(pnd->next == solver->fpiece) break;
    }
}

void tsp_lk_scale_pieces(tsp_solver_t *solver, int scale)
{
    for(tsp_piece_t *pnd = solver->fpiece; pnd != NULL; pnd = pnd->next)
    {
        tsp_lk_scale_graph_f(pnd->pnode, scale);
        if(pnd->next == solver->fpiece) break;
    }
    tsp_lk_compute_piece_sclae_center(solver);
    tsp_solver_piece_scale_best_point(solver, scale);
}

void tsp_lk_init_pieces_with_file_f(const char *name_of_file, tsp_solver_t *solver)
{
    FILE *fd = fopen(name_of_file, "r");
    char buff[12];
    memset(&buff, 0, sizeof(buff));

    solver->fpiece = (tsp_piece_t*)malloc(sizeof(tsp_piece_t));
    solver->fpiece->next = NULL;
    solver->fpiece->pnode = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    solver->fpiece->pnode->next = NULL;

    tsp_piece_t *piece = solver->fpiece;
    tsp_node_t *node = piece->pnode;

    bool_t firstNode = true_t;
    bool_t firstPiece = true_t;


    while(fgets(buff, sizeof(buff),fd))
    {
        if(strstr(buff,"piece") != NULL)
        {
            if(firstPiece == false_t)
            {
                piece->next = (tsp_piece_t*)malloc(sizeof(tsp_piece_t));
                piece = piece->next;
               // piece = (tsp_piece_t*)malloc(sizeof(tsp_piece_t));
                piece->next = NULL;
                piece->pnode = NULL;

                piece->pnode = (tsp_node_t*)malloc(sizeof(tsp_node_t));
                node = piece->pnode;
                //node = (tsp_node_t*)malloc(sizeof(tsp_node_t));
                node->next = NULL;
                firstNode = true_t;
                //printf("NewPiece\n");
            }
            else firstPiece = false_t;
            memset(&buff, 0, sizeof(buff));
        }
        else if(strstr(buff, "EOF") != NULL) { /*printf("EOF\n");*/ break; }
        else
        {
            //printf("Else3\n");
            int nr = 0;
            if(firstNode == false_t)
            {
                tsp_node_t *nod = (tsp_node_t*)malloc(sizeof(tsp_node_t));

                for(int i = 0; i < 6; i++)
                {
                    if(buff[i] != '\n' && buff[i] != EOF)
                    {
                        if(buff[i] != ' ') nr = nr * 10 + (buff[i] - '0');
                        else
                        {
                            nod->point_col.x = nr;
                            nr = 0;
                        }
                    }
                    else
                    {
                        nod->point_col.y = nr;
                        node->next = nod;
                        node = node->next;
                        node->next = NULL;
                        break;
                    }
                }
            }
            else if(firstNode == true_t)
            {
                for(int i = 0; i < 6; i++)
                {
                    if(buff[i] != '\n' && buff[i] != EOF)
                    {
                        if(buff[i] != ' ') nr = nr * 10 + (buff[i] - '0');
                        else
                        {
                            node->point_col.x = nr;
                            nr = 0;
                        }
                    }
                    else { node->point_col.y = nr; break; }
                }
                firstNode = false_t;
            }
            memset(&buff, 0, sizeof(buff));
        }
    }

    //solver->last = node;
    //solver->initial_path_len = tsp_lk_compute_path_len_f(solver);
    //solver->number_of_nodes = tsp_lk_get_number_of_nodes_f(solver);
    tsp_lk_compute_piece_center(solver);
    tsp_lk_compute_piece_sclae_center(solver);
    fclose(fd);
}

/* init solver with random points */
void tsp_lk_init_with_random_f(tsp_solver_t *solver, const int nr_of_gen_nodes, const int minDist, const int maxDist)
{
    int count = 0;
    int ok_first = 0;
    tsp_node_t *old_node;
    tsp_node_t *first_node;

    solver->first = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    solver->first->next = NULL;
    tsp_node_t *node = solver->first;

    while(count < nr_of_gen_nodes)
    {
        int xr = rand() %6000;
        int yr = rand() %500;
        if(!ok_first)
        {
            node->point_col.x = xr;
            node->point_col.y = yr;
            old_node = node;
            first_node = node;
            ok_first = 1;
            count++;
        }
        else
        {
            tsp_node_t *nod = (tsp_node_t*)malloc(sizeof(tsp_node_t));
            nod->next = NULL;
            nod->point_col.x = xr;
            nod->point_col.y = yr;

            int dist = (int)tsp_lk_compute_dist_between_two_nodes_f(nod, old_node);

            if(dist >= minDist && dist <= maxDist)
            {
                int ok = 0;
                for(tsp_node_t *nd = first_node; nd != NULL; nd = nd->next)
                {
                    int dist2 = (int)tsp_lk_compute_dist_between_two_nodes_f(nod, nd);
                    if(dist2 < minDist/3 || dist2 > 600)
                    { ok = 1; break; }
                }

                if(ok == 0)
                {
                    old_node = nod;
                    node->next = nod;
                    node = node->next;
                    count++;
                }
            }
        }
    }
}

/* init solver with random points and add first & last nodes */
void tsp_lk_init_with_random_and_ss_nodes_f(tsp_solver_t *solver, const int nr_of_gen_nodes, const int minDist, const int maxDist)
{
    tsp_lk_init_with_random_f(solver, nr_of_gen_nodes, minDist, maxDist);
    tsp_lk_add_first_node_rand_f(solver);
//    tsp_lk_add_last_node_rand_f(solver);
}



/* free node list */
void tsp_lk_free_nodes_f(tsp_node_t *node)
{
    while(node != NULL)
    {
        tsp_node_t *nd = node->next;
        free(node);
        node = nd;
    }
}

void tsp_lk_free_pieces(tsp_piece_t *fnode)
{
    while(fnode != NULL)
    {
        tsp_piece_t *fnd = fnode->next;
        tsp_lk_free_nodes_f(fnode->pnode);
        free(fnode);
        fnode = fnd;
    }
}

void tsp_solver_lk_free_optkmove(tsp_solver_t *solver)
{
    int i = 2;
    for(i = 2; i <= solver->maxKopt; i++)
    {
        if(solver->optKlist[i-2] != NULL) kopt_gen_list_free(solver->optKlist[i-2]);
    }
    free(solver->optKlist);
}

void tsp_solver_lk_free_move_pos_struct(tsp_solver_t *solver)
{
    int i = 0;
    if(solver->swapPos != NULL)
    for(i = 0; i < solver->size_swapPos; i++)
    {
        if(solver->swapPos[i].swapSecvPos != NULL)
            free(solver->swapPos[i].swapSecvPos);
        if(solver->swapPos[i].swapNonSecvPos != NULL)
            free(solver->swapPos[i].swapNonSecvPos);
    }
    if(solver->swapPos != NULL)
        free(solver->swapPos);
}

/* free solver elem */
void tsp_lk_free_solver_f(tsp_solver_t *solver)
{
    if(solver == NULL || solver->first == NULL) return;
    tsp_node_t *node = solver->first;
    tsp_lk_free_nodes_f(node);
    tsp_lk_free_nodes_f(solver->best);
    if(solver->last != NULL) free(solver->last);
    if(solver->all_edges != NULL) free(solver->all_edges);

    if(solver->prime_vect != NULL) free(solver->prime_vect);
    if(solver->hash_numbers != NULL) free(solver->hash_numbers);

    if(solver->opt2list != NULL) kopt_gen_list_free(solver->opt2list);
    if(solver->opt3list != NULL) kopt_gen_list_free(solver->opt3list);
    if(solver->opt4list != NULL) kopt_gen_list_free(solver->opt4list);
    if(solver->opt5list != NULL) kopt_gen_list_free(solver->opt5list);

    tsp_solver_lk_free_optkmove(solver);
    tsp_solver_lk_free_move_pos_struct(solver);

    free(solver);
}

/* swap nodes when using nearest neighbor alg */
void tsp_lk_knn_swap_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2, tsp_node_t *nd3)
{
    nd3->next = nd2->next;
    nd2->next = nd1->next;
    nd1->next = nd2;
}

/* preprocess nodes with nearest neighbor */
void tsp_lk_knn_preprocess_f(tsp_solver_t *solver)
{
    if(solver == NULL || solver->first == NULL) return;
    tsp_node_t *node = solver->first;
    if(node == NULL || node->next == NULL) return;

//    tsp_node_t *ndl;
//    for(tsp_node_t *nd1 = node; nd1 != NULL; nd1 = nd1->next)
//    {
//        if(nd1->next == NULL)
//            ndl = nd1;
//    }

    int for1 = 0, for2 = 0;

    for(tsp_node_t *nd1 = node; nd1->next != NULL/* && nd1->next != node*/; nd1 = nd1->next)
    {
        qDebug() << "for1 : " << for1++;
        qDebug() << "---> " << nd1->point_index;
        qDebug() << "p(" << nd1->point_col.x << ", " << nd1->point_col.y << ")";
        for2 = 0;
        double min_dist = 65000;
        tsp_node_t *aux_nd2_1, *aux_nd2_2;
        for(tsp_node_t *nd2 = nd1; nd2->next != NULL/* && nd2->next != node */; nd2 = nd2->next)
        {
//            if(nd2 == NULL || nd2->next == NULL) break;
//            qDebug() << "for2 : " << for2++;
//            qDebug() << "---> " << nd2->point_index;
            double dist = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd2->next);
            if(dist < min_dist)
            {
                min_dist = dist;
                aux_nd2_1 = nd2->next;
                aux_nd2_2 = nd2;
            }
        }
        tsp_lk_knn_swap_nodes_f(nd1, aux_nd2_1, aux_nd2_2);
    }

}

void tsp_lk_knn_swap_pieces_f(tsp_piece_t *nd1, tsp_piece_t *nd2, tsp_piece_t *nd3)
{
    nd3->next = nd2->next;
    nd2->next = nd1->next;
    nd1->next = nd2;
}

void tsp_lk_knn_preprocess_pieces_f(tsp_solver_t *solver)
{
    if(solver == NULL || solver->fpiece == NULL) return;
    tsp_piece_t *piece = solver->fpiece;
    if(piece == NULL || piece->next == NULL) return;

    for(tsp_piece_t *nd1 = piece; nd1->next != NULL && nd1->next != piece; nd1 = nd1->next)
    {
        unsigned int min_dist = 65000;
        tsp_piece_t *aux_nd2_1, *aux_nd2_2;
        for(tsp_piece_t *nd2 = nd1; nd2->next != NULL && nd2->next != piece; nd2 = nd2->next)
        {
            unsigned int dist = (unsigned int)tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd2->next->gcenter);
            if(dist < min_dist)
            {
                min_dist = dist;
                aux_nd2_1 = nd2->next;
                aux_nd2_2 = nd2;
            }
        }
        tsp_lk_knn_swap_pieces_f(nd1, aux_nd2_1, aux_nd2_2);
    }

}


/* ---- Implementare Metoda Proprie ---- */

void tsp_solver_compute_max_min_points(tsp_solver_t *solver)
{
    for(tsp_piece_t *pnd = solver->fpiece; pnd != NULL; pnd = pnd->next)
    {
        int maxx = pnd->pnode->point_col.x,
            maxy = pnd->pnode->point_col.y,
            minx = pnd->pnode->point_col.x,
            miny = pnd->pnode->point_col.y;

        for(tsp_node_t *nd = pnd->pnode; nd != NULL; nd = nd->next)
        {
            if(maxx < nd->point_col.x) maxx = nd->point_col.x;
            if(minx > nd->point_col.x) minx = nd->point_col.x;
            if(maxy < nd->point_col.y) maxy = nd->point_col.y;
            if(miny > nd->point_col.y) miny = nd->point_col.y;
        }
        pnd->max_x = maxx;
        pnd->max_y = maxy;
        pnd->min_x = minx;
        pnd->min_y = miny;
        if(pnd == solver->fpiece->next) break;
    }
}

void tsp_solver_piece_make_cycle(tsp_solver_t *solver)
{
    tsp_piece_t *piece = solver->fpiece;
    for(tsp_piece_t *nd = piece; nd != NULL; nd = nd->next)
    {
        if(nd->next == NULL)
        {
            nd->next = piece;
            break;
        }
    }
}

void tsp_solver_piece_undo_cycle(tsp_solver_t *solver)
{
    tsp_piece_t *piece = solver->fpiece;
    for(tsp_piece_t *nd = piece; /*nd != NULL && nd != piece*/; nd = nd->next)
    {
        if(nd->next == piece)
        {
            nd->next = NULL;
            break;
        }
    }
}

int  tsp_solver_piece_compute_dist_between_two_points_nosqrt(tsp_point_t nd1, tsp_point_t nd2)
{
    int x_dist = (int)(nd1.x - nd2.x);
    x_dist = (x_dist * x_dist);
    int y_dist = (int)(nd1.y - nd2.y);
    y_dist = (y_dist * y_dist);
    double rez = ((double)((x_dist + y_dist)));
    return (int)rez;
}

tsp_point_t tsp_solver_piece_get_mid_point(tsp_point_t pt1, tsp_point_t pt2)
{
    tsp_point_t pt;
    pt.x = (pt1.x + pt2.x) / 2;
    pt.y = (pt1.y + pt2.y) / 2;
    return pt;
}

tsp_point_t tsp_solver_piece_get_min_dist_point_to_section(tsp_piece_t *piece, double *eq)
{
    tsp_point_t pt;
    double dist = 0.f;
    dist = (double)(abs(eq[0] * piece->pnode->point_col.x + eq[1] * piece->pnode->point_col.y + eq[2]) / sqrt(eq[0] * eq[0] + eq[1] * eq[1]));
    pt.x = piece->pnode->point_col.x;
    pt.y = piece->pnode->point_col.y;

    for(tsp_node_t *nd = piece->pnode; nd != NULL; nd = nd->next)
    {
        double aux = (double)(abs(eq[0] * nd->point_col.x + eq[1] * nd->point_col.y + eq[2]) / sqrt(eq[0] * eq[0] + eq[1] * eq[1]));
        if(dist > aux)
        {
            dist = aux;
            pt.x = nd->point_col.x;
            pt.y = nd->point_col.y;
        }
    }
    return pt;
}

void tsp_solver_piece_compute_eq_of_two_points(tsp_point_t pt1, tsp_point_t pt2, double *eq, double *slope)
{
    eq[0] = (double)(pt2.y - pt1.y);
    eq[1] = (double)((-1.f)*(pt2.x - pt1.x));
    eq[2] = (double)((-1.f)*(pt1.x * (pt2.y - pt1.y) - pt1.y * (pt2.x - pt1.x)));
    slope[0] = (double)(pt2.y - pt1.y);
    slope[1] = (double)(pt2.x - pt1.x);

//    if(eq[0] < 0.f)
//    {
//        eq[0] *= (-1.f);
//        eq[1] *= (-1.f);
//        eq[2] *= (-1.f);
//    }

//    eq[0] = slope[0];
//    eq[1] = -slope[1];
//    eq[2] = -(slope[1] * pt1.x - slope[0] * pt1.y);
}

void tsp_solver_piece_compute_paralel_eq(tsp_point_t pt1, tsp_point_t pt2, double *eq, double *eqd, tsp_point_t minp, double *slope)
{
    //tsp_point_t midp = tsp_solver_piece_get_mid_point(pt1, pt2);

    //double nc = minp.y + eqd[0] * minp.x;

    //eq[0] = (double)(-1.f * eqd[0]);

//    eq[0] = (double)(((-1.f) * eqd[0]) / eqd[1]);
//    eq[1] = 1;
//    eq[2] = nc;

    eq[0] = slope[0];
    eq[1] = (-1.f)*slope[1];
    eq[2] = slope[1]*minp.y - slope[0]*minp.x;
}

void tsp_solver_piece_compute_perpendicular_eq(tsp_point_t pt1, tsp_point_t pt2, tsp_point_t midp, double *eq, double *eqd, double *slope)
{
    //double m = (-1.f)*((pt1.y-pt2.y)/(pt1.x-pt2.x));

//    double m = (double)(-1.f)*(eqd[1] / ((-1.f) * eqd[0]));
//    double b = midp.y - m * midp.x;
//    eq[0] = m;
//    eq[1] = 1;
//    eq[2] = b;

    eq[0] = (-1.f) * slope[1];
    eq[1] = (-1.f) * slope[0];
    eq[2] = (-1.f) * (-1.f) * (slope[0]*midp.y + slope[1]*midp.x);

}

void tsp_solver_piece_compute_dragged_centr(tsp_piece_t *first, tsp_piece_t *mid, tsp_piece_t *last, int *xx, int *yy)
{
    tsp_point_t pt;

    double *eqdr = (double*)malloc(sizeof(double)*3);
    double *eqpar = (double*)malloc(sizeof(double)*3); /* 1 */
    double *eqper = (double*)malloc(sizeof(double)*3); /* 2 */
    double *slope = (double*)malloc(sizeof(double)*2);

    tsp_solver_piece_compute_eq_of_two_points(first->gcenter, last->gcenter, eqdr, slope);
    tsp_point_t ptmin = tsp_solver_piece_get_min_dist_point_to_section(mid, eqdr);

    qDebug() << "first point : (" << first->gcenter.x << ", " << first->gcenter.y << ")";
    qDebug() << "mid point : (" << mid->gcenter.x << ", " << mid->gcenter.y << ")";
    qDebug() << "last point : (" << last->gcenter.x << ", " << last->gcenter.y << ")";

    qDebug() << "min point : (" << ptmin.x << ", " << ptmin.y << ")";

    tsp_solver_piece_compute_paralel_eq(first->gcenter, last->gcenter, eqpar, eqdr, ptmin, slope);
    tsp_point_t ptmid;
    ptmid.x = (first->gcenter.x + last->gcenter.x) / 2;
    ptmid.y = (first->gcenter.y + last->gcenter.y) / 2;

    qDebug() << "midd point : (" << ptmid.x << ", " << ptmid.y << ")";

    tsp_solver_piece_compute_perpendicular_eq(first->gcenter, last->gcenter, ptmid, eqper, eqdr, slope);

    qDebug() << "EqDreapta  : (" << eqdr[0] << "^x) + (" << eqdr[1] << "^y) + (" << eqdr[2] << ")";
    qDebug() << "EqParalela : (" << eqpar[0] << "^x) + (" << eqpar[1] << "^y) + (" << eqpar[2] << ")";
    qDebug() << "EqPerpendi : (" << eqper[0] << "^x) + (" << eqper[1] << "^y) + (" << eqper[2] << ")";

    double x,y;

    double eqper2[3], eqpar2[3];

    eqper2[0] = eqper[0];
    eqper2[1] = eqper[1];
    eqper2[2] = eqper[2];

    eqpar2[0] = eqpar[0];
    eqpar2[1] = eqpar[1];
    eqpar2[2] = eqpar[2];

    if(eqpar[0] != 0.f && eqpar[1] != 0.f && eqper[0] != 0.f && eqper[1] != 0.f)
    {
    if(abs(eqpar2[1]) == abs(eqper2[1]))
    {
        if((eqpar2[1] > 0.f && eqper2[1] > 0.f) ||
           (eqpar2[1] < 0.f && eqper2[1] < 0.f))
        {
            for(int i = 2; i >= 0; i--)
            {
                eqpar2[i] *= (-1.f);
            }

            x = ((-1.f)*(eqper2[2] + eqpar2[2])) / (eqper2[0] + eqpar2[0]);
            y = ((-1.f) * (eqper[0] * x + eqper[2])) / (eqper[1]);
        }
        else
        {
            x = ((-1.f)*(eqper2[2] + eqpar2[2])) / (eqper2[0] + eqpar2[0]);
            y = ((-1.f) * (eqper[0] * x + eqper[2])) / (eqper[1]);
        }
    }
    else
    {
        for(int i = 2; i >= 0; i--)
        {
            eqper2[i] *= eqper2[0];
            eqpar2[i] *= eqpar2[0];
        }

        if((eqpar2[1] > 0.f && eqper2[1] > 0.f) ||
           (eqpar2[1] < 0.f && eqper2[1] < 0.f))
        {
            for(int i = 2; i >= 0; i--)
            {
                eqpar2[i] *= (-1.f);
            }

            x = ((-1.f)*(eqper2[2] + eqpar2[2])) / (eqper2[0] + eqpar2[0]);
            y = ((-1.f) * (eqper[0] * x + eqper[2])) / (eqper[1]);
        }
        else
        {
            x = ((-1.f)*(eqper2[2] + eqpar2[2])) / (eqper2[0] + eqpar2[0]);
            y = ((-1.f) * (eqper[0] * x + eqper[2])) / (eqper[1]);
        }
    }
    }
    else
    {
        if(eqpar[0] == 0.f)
        {
            x = (-1.f) * (eqper[2] / eqper[0]);
            y = (-1.f) * (eqpar[2] / eqpar[1]);
        }
        else if(eqper[0] == 0.f)
        {
            x = (-1.f) * (eqpar[2] / eqpar[0]);
            y = (-1.f) * (eqper[2] / eqper[1]);
        }
    }

    qDebug() << "EQPAR2 : " << "(" << eqpar2[0] << "^x) + (" << eqpar2[1] << "^y) + (" << eqpar2[2] << ")";
    qDebug() << "EQPER2 : " << "(" << eqper2[0] << "^x) + (" << eqper2[1] << "^y) + (" << eqper2[2] << ")";

    pt.x = round(x);
    pt.y = round(y);
//    *xx = abs(pt.x);
//    *yy = abs(pt.y);
    *xx = pt.x;
    *yy = pt.y;

    //*xx = ptmin.x;
    //*yy = ptmin.y;

    //return pt;
}

void tsp_solver_piece_reposition_centr(tsp_solver_t *solver)
{
    //tsp_solver_piece_compute_dist_between_two_points_nosqrt()
    //unsigned int dist = pow(2.0, sizeof(int)*8.f);
    //unsigned int old_dist = 0;

    int nrImpr = 0;

    bool_t noMoreImpr = false_t;

    tsp_piece_t *piece = solver->fpiece;
    int cnt = 0;
    do
    {
        qDebug() << "--> VSS " << ++cnt;
        //tsp_piece_t *first = piece;
        //tsp_piece_t *mid = piece->next;
        //tsp_piece_t *last = mid->next;

        int x,y;

        tsp_point_t new_centr;
        tsp_solver_piece_compute_dragged_centr(piece, piece->next, piece->next->next, &x, &y);
        new_centr.x = x;
        new_centr.y = y;

        qDebug() << "New Center : (" << new_centr.x << ", " << new_centr.y << ")";
        qDebug() << "Old Center : (" << piece->next->gcenter.x << ", " << piece->next->gcenter.y << ")";

        double old_dist = tsp_solver_piece_compute_dist_between_two_points_nosqrt(piece->gcenter, piece->next->gcenter) +
                          tsp_solver_piece_compute_dist_between_two_points_nosqrt(piece->next->gcenter, piece->next->next->gcenter);
        double new_dist = tsp_solver_piece_compute_dist_between_two_points_nosqrt(piece->gcenter, new_centr) +
                          tsp_solver_piece_compute_dist_between_two_points_nosqrt(new_centr, piece->next->next->gcenter);

        qDebug() << "New Dist : " << new_dist;
        qDebug() << "Old Dist : " << old_dist;

        if(old_dist > new_dist)
        {
            piece->next->gcenter.x = new_centr.x;
            piece->next->gcenter.y = new_centr.y;
            nrImpr++;
            qDebug() << "--> Impr Dist !";
        } else qDebug() << "--> NO IMPR";

        if(piece->next->next == solver->fpiece || piece->next->next == NULL)
        {
            if(nrImpr == 0)
            {
                qDebug() << "--> NO NO MORE IMPR";
                noMoreImpr = true_t;
                //break;
            }
            else
            {
                qDebug() << "--> MORE IMPR";
                nrImpr = 0;
                if(piece->next->next == NULL) piece = solver->fpiece;
            }
        }

        piece = piece->next;
    }
    while(noMoreImpr == false_t && piece->next != NULL);
}


/* -- K-OPT Moves & Operations -- */
/* reverse direction of some nodes */
void tsp_lk_reverse_direction_f(tsp_node_t *nd1_n, tsp_node_t *nd1_nn, tsp_node_t *nd2)
{
    if(nd1_nn == nd2) nd1_nn->next = nd1_n;
    else
    {
        tsp_node_t *aux = nd1_nn->next;
        nd1_nn->next = nd1_n;
        tsp_lk_reverse_direction_f(nd1_nn, aux, nd2);
    }
}

void tsp_lk_reverse_direction_pieces_f(tsp_piece_t *nd1_n, tsp_piece_t *nd1_nn, tsp_piece_t *nd2)
{
    if(nd1_nn == nd2) nd1_nn->next = nd1_n;
    else
    {
        tsp_piece_t *aux = nd1_nn->next;
        nd1_nn->next = nd1_n;
        tsp_lk_reverse_direction_pieces_f(nd1_nn, aux, nd2);
    }
}

/* make a 2-opt move */
void tsp_lk_2opt_swap_f(tsp_node_t *nd1, tsp_node_t *nd2, tsp_node_t *nd1_n, tsp_node_t *nd2_n)
{
    tsp_lk_reverse_direction_f(nd1_n, nd1_n->next, nd2);
    nd1->next = nd2;
    nd1_n->next = nd2_n;
}

void tsp_lk_2opt_swap_piece_f(tsp_piece_t *nd1, tsp_piece_t *nd2, tsp_piece_t *nd1_n, tsp_piece_t *nd2_n)
{
    tsp_lk_reverse_direction_pieces_f(nd1_n, nd1_n->next, nd2);
    nd1->next = nd2;
    nd1_n->next = nd2_n;
    //printf("ooo");
}

/* make a 3-opt move */
void tsp_lk_3opt_swap_f(tsp_node_t *nd1,
                        tsp_node_t *nd2,
                        tsp_node_t *nd3,
                        tsp_node_t *nd1_n,
                        tsp_node_t *nd2_n,
                        tsp_node_t *nd3_n, int type)
{
    switch(type)
    {
        case 4:
            tsp_lk_reverse_direction_f(nd1_n,nd1_n->next,nd2);
            nd1->next = nd2;
            nd1_n->next = nd3;
            tsp_lk_reverse_direction_f(nd2_n,nd2_n->next,nd3);
            nd2_n->next = nd3_n;
            break;
        case 5:
            nd1->next = nd3;
            tsp_lk_reverse_direction_f(nd2_n,nd2_n->next,nd3);
            nd2_n->next = nd1_n;
            nd2->next = nd3_n;
            break;
        case 6:
            tsp_lk_reverse_direction_f(nd1_n,nd1_n->next,nd2);
            nd1->next = nd2_n;
            nd3->next = nd2;
            nd1_n->next = nd3_n;
            break;
        case 7:
            nd1->next = nd2_n;
            nd3->next = nd1_n;
            nd2->next = nd3_n;
            break;
        default: break;
    }
}


void tsp_lk_3opt_swap_pieces_f(tsp_piece_t *nd1,
                               tsp_piece_t *nd2,
                               tsp_piece_t *nd3,
                               tsp_piece_t *nd1_n,
                               tsp_piece_t *nd2_n,
                               tsp_piece_t *nd3_n, int type)
{
    switch(type)
    {
        case 4:
            tsp_lk_reverse_direction_pieces_f(nd1_n,nd1_n->next,nd2);
            nd1->next = nd2;
            nd1_n->next = nd3;
            tsp_lk_reverse_direction_pieces_f(nd2_n,nd2_n->next,nd3);
            nd2_n->next = nd3_n;
            break;
        case 5:
            nd1->next = nd3;
            tsp_lk_reverse_direction_pieces_f(nd2_n,nd2_n->next,nd3);
            nd2_n->next = nd1_n;
            nd2->next = nd3_n;
            break;
        case 6:
            tsp_lk_reverse_direction_pieces_f(nd1_n,nd1_n->next,nd2);
            nd1->next = nd2_n;
            nd3->next = nd2;
            nd1_n->next = nd3_n;
            break;
        case 7:
            nd1->next = nd2_n;
            nd3->next = nd1_n;
            nd2->next = nd3_n;
            break;
        default: break;
    }
}


void tsp_lk_2opt_solve_pieces_f(tsp_solver_t *solver)
{
    if(solver == NULL) return;
    tsp_piece_t *node = solver->fpiece;

    if(node == NULL || node->next == NULL) return;
    int cycle = 0;

    tsp_piece_t *aux_nd = node;

     cycle = 0;
     int cnt = 0;
     int auxcnt = 0;
     bool_t noMoreIm = false_t;

     printf("pff\n");

     int ccc = 0;

     for(tsp_piece_t *nd1 = node; noMoreIm != true_t /* && nd1->next != NULL*/; nd1 = nd1->next)
     {
         qDebug() << "Vasile : " << (ccc++);
         tsp_piece_t *aux_nd1, *aux_nd2;
         int best_dist = -1;

         if(nd1->next->next != NULL)
         for(tsp_piece_t *nd2 = nd1->next->next;  nd2->next->next != nd1 && nd2->next != NULL; nd2 = nd2->next)
         {
             int old_dist = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd1->next->gcenter) +
                            tsp_lk_compute_dist_between_two_points_f(nd2->gcenter, nd2->next->gcenter);
             int new_dist = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd2->gcenter) +
                            tsp_lk_compute_dist_between_two_points_f(nd1->next->gcenter, nd2->next->gcenter);

             if(new_dist < old_dist)
             {
                 if(best_dist == -1)
                 {
                    best_dist = new_dist;
                    aux_nd1 = nd1;
                    aux_nd2 = nd2;
                 }
                 else if(best_dist > new_dist)
                 {
                     best_dist = new_dist;
                     aux_nd1 = nd1;
                     aux_nd2 = nd2;
                 }
             }
         }

         if(best_dist != -1 &&
            aux_nd1 != NULL &&
            aux_nd2 != NULL)
         {
            if(aux_nd1->next != NULL &&
               aux_nd2->next != NULL)
            {

                qDebug() << "Swap";
                tsp_lk_2opt_swap_piece_f(aux_nd1, aux_nd2, aux_nd1->next, aux_nd2->next);
                cnt++;
            }
         }

         if(nd1->next == node || nd1->next->next == NULL)
         {
             if(cnt == 0) noMoreIm = true_t;
             cnt = 0;
             if(nd1->next->next == NULL)
             {
                 nd1 = node;
                 qDebug() << "MakeNuLL";
             }
         }
     }
}

void tsp_lk_2opt_solve_f(tsp_solver_t *solver)
{
    if(solver == NULL) return;
    tsp_node_t *node = solver->first;

    if(node == NULL || node->next == NULL) return;
    int cycle = 0;

    tsp_node_t *aux_nd = node;

     cycle = 0;
     int cnt = 0;
     int auxcnt = 0;
     bool_t noMoreIm = false_t;


     for(tsp_node_t *nd1 = node; noMoreIm != true_t; nd1 = nd1->next)
     {
         tsp_node_t *aux_nd1, *aux_nd2;
         int best_dist = -1;

         if(nd1->next->next != NULL)
         for(tsp_node_t *nd2 = nd1->next->next; nd2->next->next != nd1 && nd2->next != NULL; nd2 = nd2->next)
         {
             int old_dist = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd1->next) +
                            tsp_lk_compute_dist_between_two_nodes_f(nd2, nd2->next);
             int new_dist = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd2) +
                            tsp_lk_compute_dist_between_two_nodes_f(nd1->next, nd2->next);

             if(new_dist < old_dist)
             {
                 if(best_dist == -1)
                 {
                    best_dist = new_dist;
                    aux_nd1 = nd1;
                    aux_nd2 = nd2;
                 }
                 else if(best_dist > new_dist)
                 {
                     best_dist = new_dist;
                     aux_nd1 = nd1;
                     aux_nd2 = nd2;
                 }
             }
         }

         if(best_dist != -1 &&
            aux_nd1 != NULL &&
            aux_nd2 != NULL)
         {
            if(aux_nd1->next != NULL &&
               aux_nd2->next != NULL)
            {
                tsp_lk_2opt_swap_f(aux_nd1, aux_nd2, aux_nd1->next, aux_nd2->next);
                cnt++;
            }
         }

         if(nd1->next == node || nd1->next->next == NULL)
         {
             if(cnt == 0) noMoreIm = true_t;
             cnt = 0;
             if(nd1->next->next == NULL) nd1 = node;
         }
     }
}

bool_t tsp_lk_compare_two_nodes_f(tsp_node_t *nd1, tsp_node_t *nd2)
{
    if(nd1->point_col.x == nd2->point_col.x && nd1->point_col.y == nd2->point_col.y) return true_t;
    return false_t;
}

void tsp_lk_3opt_solve_f(tsp_solver_t *solver)
{
    qDebug() << "3opt solver\n";

    if(solver == NULL) return;
    tsp_node_t *node = solver->first;
    if(node == NULL || node->next == NULL) return;

    int cycle = 0;

    tsp_node_t *aux_nd = node;

     cycle = 0;
     int cnt = 0;
     int auxcnt = 0;
     bool_t noMoreIm = false_t;

     int for1 = 0, for2 = 0, for3 = 0;

     for(tsp_node_t *nd1 = node;  noMoreIm != true_t /* nd1->next->next != NULL */; nd1 = nd1->next)
     {
         //qDebug() << "3opt for1 = " << ++for1;
         for2 = 0;
         for3 = 0;
         cycle++;
         tsp_node_t *aux_nd1, *aux_nd2, *aux_nd3;
         double best_dist = -1;
         int index = 0;

         if(nd1->next->next != NULL)
         for(tsp_node_t *nd2 = nd1->next->next; nd2->next->next != nd1 && nd2->next != NULL; nd2 = nd2->next)
         {
             //qDebug() << "3opt for2 = " << ++for2;
             if(nd2->next != NULL)
             {
                 tsp_node_t *nd3;
                 if(nd2->next->next != NULL) nd3 = nd2->next->next;
                 //for(tsp_node_t *nd3 = nd2->next->next; tsp_lk_compare_two_nodes_f(nd3->next->next, nd1) == false_t && tsp_lk_compare_two_nodes_f(nd3->next->next, nd2) == false_t && nd3->next->next != nd1 && nd3->next->next != nd2 && nd3->next != NULL; nd3 = nd3->next)
                 //while(tsp_lk_compare_two_nodes_f(nd3->next, nd1) == false_t &&
                   //tsp_lk_compare_two_nodes_f(nd3->next, nd2) == false_t)
                 for3 = 0;
                 while(nd3->next != NULL && nd3->next != nd1)
                 {
                     //qDebug() << "3opt for3 = " << ++for3;

                     double vdist[8] = { 0.f };
                     for(int i = 0; i < 8; i++)
                     {
                         switch(i)
                         {
                         case 0:
                             vdist[i] = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd1->next) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd2, nd2->next) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd3, nd3->next);
                             break;
                         case 1:
                             vdist[i] = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd3) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd2->next, nd2) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd1->next, nd3->next);
                             break;
                         case 2:
                             vdist[i] = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd1->next) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd2, nd3) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd2->next, nd3->next);
                             break;
                         case 3:
                             vdist[i] = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd2) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd1->next, nd2->next) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd3, nd3->next);
                             break;
                         case 4:
                             vdist[i] = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd2) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd1->next, nd3) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd2->next, nd3->next);
                             break;
                         case 5:
                             vdist[i] = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd3) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd2->next, nd1->next) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd2, nd3->next);

                             break;
                         case 6:
                             vdist[i] = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd2->next) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd3, nd2) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd1->next, nd3->next);
                             break;
                         case 7:
                             vdist[i] = tsp_lk_compute_dist_between_two_nodes_f(nd1, nd2->next) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd3, nd1->next) +
                                        tsp_lk_compute_dist_between_two_nodes_f(nd2, nd3->next);
                             break;
                         default: break;
                         }
                     }

                     int indx = 0;
                     double bdist = vdist[0];

                     for(int i = 4; i < 8; i++)
                     {
                         if(vdist[i] < bdist)
                         {
                             bdist = vdist[i];
                             indx = i;
                         }
                     }

                     if(indx != 0)
                     if(best_dist == -1)
                     {
                         best_dist = bdist;
                         index = indx;
                         aux_nd1 = nd1;
                         aux_nd2 = nd2;
                         aux_nd3 = nd3;
                     }
                     else if(best_dist > bdist)
                     {
                         best_dist = bdist;
                         index = indx;
                         aux_nd1 = nd1;
                         aux_nd2 = nd2;
                         aux_nd3 = nd3;
                         cnt++;
                     }

                     nd3 = nd3->next;
                 }
             }
         }

         if(best_dist != -1 &&
            aux_nd1 != NULL &&
            aux_nd2 != NULL &&
            aux_nd3 != NULL)
         {
            if(aux_nd1->next != NULL &&
               aux_nd2->next != NULL &&
               aux_nd3->next != NULL)
            {
                switch(index)
                {
                case 1:
                    tsp_lk_2opt_swap_f(aux_nd1, aux_nd3, aux_nd1->next, aux_nd3->next);
                    break;
                case 2:
                    tsp_lk_2opt_swap_f(aux_nd2, aux_nd3, aux_nd2->next, aux_nd3->next);
                    break;
                case 3:
                    tsp_lk_2opt_swap_f(aux_nd1, aux_nd2, aux_nd1->next, aux_nd2->next);
                    break;
                case 4:
                case 5:
                case 6:
                case 7:
                    tsp_lk_3opt_swap_f(aux_nd1,
                                       aux_nd2,
                                       aux_nd3,
                                       aux_nd1->next,
                                       aux_nd2->next,
                                       aux_nd3->next,
                                       index);
                    break;
                default: break;
                }


            }
         }

         if(nd1->next == node || nd1->next->next == NULL)
         {
             if(cnt == 0) noMoreIm = true_t;
             cnt = 0;
             if(nd1->next->next == NULL) nd1 = node;
         }
     }
}


void tsp_lk_3opt_solve_piece_f(tsp_solver_t *solver)
{
    //printf("3opt solver\n");

    if(solver == NULL) return;
    tsp_piece_t *node = solver->fpiece;
    if(node == NULL || node->next == NULL) return;

    int cycle = 0;

    tsp_piece_t *aux_nd = node;

     cycle = 0;
     int cnt = 0;
     int auxcnt = 0;
     bool_t noMoreIm = false_t;

     int for1 = 0, for2 = 0, for3 = 0;

     for(tsp_piece_t *nd1 = node;  noMoreIm != true_t /* nd1->next->next != NULL */; nd1 = nd1->next)
     {
         //printf("3opt for1 = %i\n", ++for1);
         cycle++;
         tsp_piece_t *aux_nd1, *aux_nd2, *aux_nd3;
         int best_dist = -1, index = 0;

         if(nd1->next->next != NULL)
         for(tsp_piece_t *nd2 = nd1->next->next; nd2->next->next != nd1 && nd2->next != NULL; nd2 = nd2->next)
         {
             //printf("3opt for2 = %i\n", ++for2);
             if(nd2->next != NULL)
             {
                 tsp_piece_t *nd3;
                 if(nd2->next->next != NULL) nd3 = nd2->next->next;
                 //for(tsp_node_t *nd3 = nd2->next->next; tsp_lk_compare_two_nodes_f(nd3->next->next, nd1) == false_t && tsp_lk_compare_two_nodes_f(nd3->next->next, nd2) == false_t && nd3->next->next != nd1 && nd3->next->next != nd2 && nd3->next != NULL; nd3 = nd3->next)
                 //while(tsp_lk_compare_two_nodes_f(nd3->next, nd1) == false_t &&
                   //tsp_lk_compare_two_nodes_f(nd3->next, nd2) == false_t)
                 while(nd3->next != nd1)
                 {
                     //printf("3opt for3 = %i\n", ++for3);

                     int vdist[8] = { 0 };
                     for(int i = 0; i < 8; i++)
                     {
                         switch(i)
                         {
                         case 0:
                             vdist[i] = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd1->next->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd2->gcenter, nd2->next->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd3->gcenter, nd3->next->gcenter);
                             break;
                         case 1:
                             vdist[i] = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd3->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd2->next->gcenter, nd2->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd1->next->gcenter, nd3->next->gcenter);
                             break;
                         case 2:
                             vdist[i] = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd1->next->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd2->gcenter, nd3->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd2->next->gcenter, nd3->next->gcenter);
                             break;
                         case 3:
                             vdist[i] = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd2->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd1->next->gcenter, nd2->next->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd3->gcenter, nd3->next->gcenter);
                             break;
                         case 4:
                             vdist[i] = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd2->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd1->next->gcenter, nd3->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd2->next->gcenter, nd3->next->gcenter);
                             break;
                         case 5:
                             vdist[i] = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd3->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd2->next->gcenter, nd1->next->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd2->gcenter, nd3->next->gcenter);

                             break;
                         case 6:
                             vdist[i] = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd2->next->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd3->gcenter, nd2->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd1->next->gcenter, nd3->next->gcenter);
                             break;
                         case 7:
                             vdist[i] = tsp_lk_compute_dist_between_two_points_f(nd1->gcenter, nd2->next->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd3->gcenter, nd1->next->gcenter) +
                                        tsp_lk_compute_dist_between_two_points_f(nd2->gcenter, nd3->next->gcenter);
                             break;
                         default: break;
                         }
                     }

                     int indx = 0;
                     int bdist = vdist[0];

                     for(int i = 1; i < 8; i++)
                     {
                         if(vdist[i] < bdist)
                         {
                             bdist = vdist[i];
                             indx = i;
                         }
                     }

                     if(indx != 0)
                     if(best_dist == -1)
                     {
                         best_dist = bdist;
                         index = indx;
                         aux_nd1 = nd1;
                         aux_nd2 = nd2;
                         aux_nd3 = nd3;
                     }
                     else if(best_dist > bdist)
                     {
                         best_dist = bdist;
                         index = indx;
                         aux_nd1 = nd1;
                         aux_nd2 = nd2;
                         aux_nd3 = nd3;
                         cnt++;
                     }

                     nd3 = nd3->next;
                 }
             }
         }

         if(best_dist != -1 &&
            aux_nd1 != NULL &&
            aux_nd2 != NULL &&
            aux_nd3 != NULL)
         {
            if(aux_nd1->next != NULL &&
               aux_nd2->next != NULL &&
               aux_nd3->next != NULL)
            {
                switch(index)
                {
                case 1:
                    tsp_lk_2opt_swap_piece_f(aux_nd1, aux_nd3, aux_nd1->next, aux_nd3->next);
                    break;
                case 2:
                    tsp_lk_2opt_swap_piece_f(aux_nd2, aux_nd3, aux_nd2->next, aux_nd3->next);
                    break;
                case 3:
                    tsp_lk_2opt_swap_piece_f(aux_nd1, aux_nd2, aux_nd1->next, aux_nd2->next);
                    break;
                case 4:
                case 5:
                case 6:
                case 7:
                    tsp_lk_3opt_swap_pieces_f(aux_nd1,
                                       aux_nd2,
                                       aux_nd3,
                                       aux_nd1->next,
                                       aux_nd2->next,
                                       aux_nd3->next,
                                       index);
                    break;
                default: break;
                }


            }
         }

         if(nd1->next == node || nd1->next->next == NULL)
         {
             if(cnt == 0) noMoreIm = true_t;
             cnt = 0;
             if(nd1->next->next == NULL) nd1 = node;
         }
     }
}

/* BEGIN --- Incercare Implementare Lin-Kernighan Pure --- */

void tsp_solver_lk_make_cycle(tsp_solver_t *solver)
{

}

void tsp_solver_lk_undo_cycle(tsp_solver_t *solver)
{

}


double tsp_solver_lk_compute_dist(tsp_point_t pt1, tsp_point_t pt2)
{
    double x_dist = (double)(pt1.x - pt2.x);
    x_dist = (x_dist * x_dist);
    double y_dist = (double)(pt1.y - pt2.y);
    y_dist = (y_dist * y_dist);
    double rez = (double)(sqrt(x_dist + y_dist));
    //double rez = (double)(x_dist + y_dist);
    return rez;
}

double tsp_solver_lk_compute_gain(tsp_point_t pt1x, tsp_point_t pt2x, tsp_point_t pt1y, tsp_point_t pt2y)
{
    return (double)(tsp_solver_lk_compute_dist(pt1x, pt2x) - tsp_solver_lk_compute_dist(pt1y, pt2y));
}

void tsp_solver_lk_reverse2(tsp_node_t *nd1_n, tsp_node_t *nd1_nn, tsp_node_t *nd2)
{
    if(nd1_nn == nd2) nd1_nn->next = nd1_n;
    else
    {
        tsp_node_t *aux = nd1_nn->next;
        nd1_nn->next = nd1_n;
        tsp_solver_lk_reverse2(nd1_nn, aux, nd2);
    }
}

void tsp_solver_lk_reverse(tsp_node_t *nd1, tsp_node_t *nd1_n, tsp_node_t *nd1_nn, tsp_node_t *nd2, tsp_node_t *nd2_n)
{
    if(nd1_nn == nd2)
    {
        nd1_nn->next = nd1_n;
        nd1->next->next = nd2_n;
        nd1->next = nd2;
    }
    else
    {
        tsp_node_t *aux = nd1_nn->next;
        nd1_nn->next = nd1_n;
        tsp_solver_lk_reverse(nd1, nd1_nn, aux, nd2, nd2_n);
    }
}


tsp_node_t *tsp_solver_lk_get_node_for(tsp_node_t **nodes, int k, int maxk, bool_t reverse, bool_t absolute)
{
    if(absolute == true_t) k = abs(k);

    if(abs(k) <= maxk)
    if(k > 0)
    {
        if(reverse == false_t) return nodes[k*2-1];
        else if(reverse == true_t) return nodes[k*2];
    }
    else if(k < 0)
    {
        if(reverse == false_t) return nodes[abs(k)*2];
        else if(reverse == true_t) return nodes[abs(k)*2-1];
    }

    return NULL;
}

tsp_node_t *tsp_solver_lk_get_prev_node_for(tsp_node_t **nodes, int k, int maxk)
{
    k = abs(k);
    if(k <= maxk)
    {
        return nodes[k*2-2];
    }
}

tsp_node_t *tsp_solver_lk_get_next_node_for(tsp_node_t **nodes, int k, int maxk)
{
    k = abs(k);
    if(k <= maxk)
    {
        return nodes[k*2+1];
    }
}


tsp_node_t *tsp_solver_lk_get_start_node(tsp_node_t **nodes, int k)
{
    return nodes[k*2];
}


tsp_node_t *tsp_solver_lk_get_end_node_for(tsp_node_t **nodes, int size)
{
    if(nodes[size*2+1] != NULL) return nodes[size*2+1];
    return NULL;
}

void printPoints22(tsp_solver_t *solver)
{
    qDebug() << "NODES : ";
    int c = 0;
    double pathlen = 0;
    for(tsp_node_t *nd = solver->first; nd != NULL/* && nd->next != solver->first*/; nd = nd->next)
    {
        c++;
        qDebug() << "P" << nd->point_index << " (" << nd->point_col.x << ", " << nd->point_col.y << ")";
        pathlen += tsp_solver_lk_compute_dist(nd->point_col, nd->next->point_col);
        if(c > 100) break;
        if(nd->next == solver->first) break;
    }
    qDebug() << "Total : " << c << " -- Len : " << QString::number(pathlen, 'f', 18);
}

void printPoints222(tsp_node_t *node)
{
    qDebug() << "NODES : ";
    int c = 0;
    double pathlen = 0;
    for(tsp_node_t *nd = node; nd != NULL/* && nd->next != solver->first*/; nd = nd->next)
    {
        c++;
        qDebug() << "P" << nd->point_index << " (" << nd->point_col.x << ", " << nd->point_col.y << ")";
        pathlen += tsp_solver_lk_compute_dist(nd->point_col, nd->next->point_col);
        if(c > 100) break;
        if(nd->next == node) break;
    }
    qDebug() << "Total : " << c << " -- Len : " << QString::number(pathlen, 'f', 18);
}

void tsp_solver_kopt_gen_swap2(tsp_node_t **nodes, int **perm, int size, int pos)
{
    int i = 0;
    for(i = 0; i < size; i++)
    {
        switch(size)
        {
        case 1:
        {
            qDebug() << "Size = 1";
            tsp_node_t *ndfirst = nodes[0];
            tsp_node_t *ndfnext = nodes[1];
            tsp_node_t *ndpend = nodes[2];
            tsp_node_t *ndend = nodes[3];
            if(perm[pos][i] < 0)
            {
               // tsp_solver_lk_reverse(ndfnext, ndfnext->next, ndpend);
                ndfnext->next = ndend;
                ndfirst->next = ndpend;
            }
            break;
        }
        case 2:
        {
            qDebug() << "Size = 2";
            if(i == 0)
            {
                tsp_node_t *ndfirst = nodes[0];

                tsp_node_t *ndfnextf = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, false_t);
                tsp_node_t *ndfnexte = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, false_t);

                tsp_node_t *ndfnextf_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, true_t);
                tsp_node_t *ndfnexte_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, true_t);

                tsp_node_t *ndend = tsp_solver_lk_get_node_for(nodes,perm[pos][i+1],size, false_t, false_t);

                if(perm[pos][i] < 0)
                {
                   // tsp_solver_lk_reverse(ndfnextf_rev, ndfnextf_rev->next, ndfnexte_rev);
                    ndfnextf->next = ndend;
                    ndfirst->next = ndfnexte;
                }
                else
                {
                    ndfirst->next = ndfnextf;
                    ndfnexte->next = ndend;
                }
            }
            else if(i == size - 1)
            {
                tsp_node_t *ndpfirst = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, false_t);
                tsp_node_t *ndpend = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, false_t);

                tsp_node_t *ndpfirst_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, true_t);
                tsp_node_t *ndpend_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, true_t);

                tsp_node_t *ndend = tsp_solver_lk_get_end_node_for(nodes, size);

                if(perm[pos][i] < 0)
                {
                   // tsp_solver_lk_reverse(ndpfirst_rev, ndpfirst_rev->next, ndpend_rev);
                    ndpend->next = ndend;
                }
                else
                {
                    ndpend->next = ndend;
                }
            }
            break;
        }
        default:
        {
            qDebug() << "Size = other";
            if(i == 0)
            {
                tsp_node_t *ndfirst = nodes[0];

                tsp_node_t *ndfnextf = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, false_t);
                tsp_node_t *ndfnexte = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, false_t);

                tsp_node_t *ndfnextf_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, true_t);
                tsp_node_t *ndfnexte_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, true_t);

                tsp_node_t *ndend = tsp_solver_lk_get_node_for(nodes,perm[pos][i+1],size, false_t, false_t);

                if(perm[pos][i] < 0)
                {
                   // tsp_solver_lk_reverse(ndfnextf_rev, ndfnextf_rev->next, ndfnexte_rev);
                    //ndfnextf->next = ndend;
                    ndfirst->next = ndfnexte;
                }
                else
                {
                    ndfirst->next = ndfnextf;
                    //ndfnexte->next = ndend;
                }
            }
            else if(i == size - 1)
            {
                tsp_node_t *ndstart = tsp_solver_lk_get_node_for(nodes,perm[pos][i-1],size, true_t, false_t);

                tsp_node_t *ndpfirst = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, false_t);
                tsp_node_t *ndpend = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, false_t);

                tsp_node_t *ndpfirst_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, true_t);
                tsp_node_t *ndpend_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, true_t);

                tsp_node_t *ndend = tsp_solver_lk_get_end_node_for(nodes, size);

                if(perm[pos][i] < 0)
                {
                    ndstart->next = ndpfirst;
                    //tsp_solver_lk_reverse(ndpfirst_rev, ndpfirst_rev->next, ndpend_rev);
                    ndpend->next = ndend;
                }
                else
                {
                    ndstart->next = ndpfirst;
                    ndpend->next = ndend;
                }
            }
            else
            {
                tsp_node_t *ndstart = tsp_solver_lk_get_node_for(nodes,perm[pos][i-1],size, true_t, false_t);

                tsp_node_t *ndfnextf = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, false_t);
                tsp_node_t *ndfnexte = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, false_t);

                tsp_node_t *ndfnextf_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, true_t);
                tsp_node_t *ndfnexte_rev = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, true_t);

                //tsp_node_t *ndend = tsp_solver_lk_get_node_for(nodes,perm[pos][i+1],size, false_t, false_t);


                if(perm[pos][i] < 0)
                {
                    ndstart->next = ndfnextf;
                    //ndfnexte->next = ndend;
                    //tsp_solver_lk_reverse(ndfnextf_rev, ndfnextf_rev->next, ndfnexte_rev);
                }
                else
                {
                    ndstart->next = ndfnextf;
                    //ndfnexte->next = ndend;
                }
            }
            break;
        }
        }
    }
}

void tsp_solver_kopt_gen_swap_el_vect(tsp_node_t **nodes, int pos1, int pos2)
{
    tsp_node_t *aux = nodes[pos1];
    nodes[pos1] = nodes[pos2];
    nodes[pos2] = aux;
}

tsp_node_t *tsp_solver_lk_get_prev_for(tsp_node_t *node)
{
    qDebug() << "Get prev node funct";
    int cc = 0;
    for(tsp_node_t *nd = node->next; nd != node; nd = nd->next)
    {
        qDebug() << "PrefNodeFunct : " << (++cc) << "P" << nd->point_index << "(" << nd->point_col.x << ", " << nd->point_col.y << ")";
        if(nd->next == node) return nd;
    }
}

void tsp_solver_kopt_gen_reverse_all(tsp_node_t **nodes, int **perm, int size, int pos)
{
    int i = 0;
    for(i = 0; i < size; i++)
    {
        if(perm[pos][i] < 0)
        {
            tsp_node_t *ndfirst = tsp_solver_lk_get_prev_node_for(nodes, perm[pos][i], size);
            tsp_node_t *ndfnextf = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, false_t, true_t);
            tsp_node_t *ndfnexte = tsp_solver_lk_get_node_for(nodes,perm[pos][i],size, true_t, true_t);
            tsp_node_t *ndend = tsp_solver_lk_get_next_node_for(nodes, perm[pos][i], size);
            tsp_solver_lk_reverse(ndfirst, ndfnextf, ndfnextf->next, ndfnexte, ndfnexte->next);
            tsp_solver_kopt_gen_swap_el_vect(nodes, abs(perm[pos][i])*2-1, abs(perm[pos][i])*2);
        }
    }
}


void tsp_solver_lk_vect_swap(tsp_node_t **nodes, int p1, int p2)
{
    tsp_node_t *aux1 = nodes[p1 * 2 - 1];
    tsp_node_t *aux2 = nodes[p1 * 2];
    nodes[p1 * 2 - 1] = nodes[p2 * 2 - 1];
    nodes[p1 * 2] = nodes[p2 * 2];
    nodes[p2 * 2 - 1] = aux1;
    nodes[p2 * 2] = aux2;
}


void tsp_solver_kopt_gen_swap22(tsp_node_t **nodes, int **perm, int size, int pos)
{
    tsp_solver_kopt_gen_reverse_all(nodes, perm, size, pos);

    tsp_node_t **nodesaux = (tsp_node_t**)calloc(size*2+2, sizeof(tsp_node_t*));
    int i = 0;
    for(i = 0; i < size*2+2; i++)
    {
        nodesaux[i] = nodes[i];
    }

    bool_t canLeave = false_t;

    for(i = 0; i < size; i++)
    {
        if(canLeave == true_t) break;

        switch(size)
        {
        case 1: break;
        default:
        {
                if(i == 0)
                {
                    tsp_node_t *ndstart = nodes[0];
                    tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodesaux,perm[pos][i],size, false_t, true_t);
                    if(ndstart->next != ndnexts) ndstart->next = ndnexts;
                    nodes[(i+1)*2] = tsp_solver_lk_get_node_for(nodesaux,perm[pos][i],size, true_t, true_t);
                }
                else if(i == size - 1)
                {
                    tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodesaux,perm[pos][i-1],size, true_t, true_t);
                    tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodesaux,perm[pos][i],size, false_t, true_t);
                    if(ndpreve->next != ndnexts) ndpreve->next = ndnexts;

                    nodes[(i+1)*2] = tsp_solver_lk_get_node_for(nodesaux,perm[pos][i],size, true_t, true_t);

                    tsp_node_t *ndnexte = tsp_solver_lk_get_node_for(nodesaux,perm[pos][i],size, true_t, true_t);
                    tsp_node_t *ndend = tsp_solver_lk_get_end_node_for(nodesaux, size);
                    if(ndnexte->next != ndend) ndnexte->next = ndend;
                }
                else
                {
                    tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodesaux,perm[pos][i-1],size, true_t, true_t);
                    tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodesaux,perm[pos][i],size, false_t, true_t);
                    if(ndpreve->next != ndnexts) ndpreve->next = ndnexts;
                    nodes[(i+1)*2] = tsp_solver_lk_get_node_for(nodesaux,perm[pos][i],size, true_t, true_t);
                }
            break;
        }
        }
    }
    nodes = nodesaux;
}

double tsp_solver_lk_comp_pathlen(tsp_solver_t *solver)
{
    double pathlen = 0;
    for(tsp_node_t *nd = solver->first; nd != NULL && nd->next != solver->first; nd = nd->next)
    { pathlen += tsp_solver_lk_compute_dist(nd->point_col, nd->next->point_col); }
    return pathlen;
}

void tsp_solver_lk_compute_first_best_exchange1(tsp_node_t **nodes, int** mat,
                                               int row, int col, double *gain, int *pos)
{
    double gi = 0.f;
    int bpos = -1;

    double bg = gi;
    double lastdiff = 0.f;

    int i;
    for(i = 0; i < row; i++)
    {
        int j;
        double g = 0.f;

        for(j = 0; j < col; j++)
        {
            if(col == 1)
            {
                tsp_node_t *ndstart = nodes[0];
                tsp_node_t *ndsnext;
                tsp_node_t *ndeprev;
                tsp_node_t *ndend = nodes[3];

                if(mat[i][j] > 0)
                {
                    ndsnext = nodes[1];
                    ndeprev = nodes[2];
                    g += tsp_solver_lk_compute_dist(ndstart->point_col, ndsnext->point_col);
                    g += tsp_solver_lk_compute_dist(ndeprev->point_col, ndend->point_col);
                }
                else
                {
                    ndsnext = nodes[2];
                    ndeprev = nodes[1];
                    g += tsp_solver_lk_compute_dist(ndstart->point_col, ndsnext->point_col);
                    g += tsp_solver_lk_compute_dist(ndeprev->point_col, ndend->point_col);
                }
            }
            else
            {
                if(j == 0)
                {
                    tsp_node_t *ndstart = nodes[0];
                    tsp_node_t *ndnext = tsp_solver_lk_get_node_for(nodes, mat[i][j], col, false_t, false_t);
                    g += tsp_solver_lk_compute_dist(ndstart->point_col, ndnext->point_col);
                }
                else if(j == col-1)
                {
                    tsp_node_t *ndprevstart = tsp_solver_lk_get_node_for(nodes, mat[i][j-1], col, false_t, false_t);
                    tsp_node_t *ndstart = tsp_solver_lk_get_node_for(nodes, mat[i][j], col, true_t, false_t);
                    g += tsp_solver_lk_compute_dist(ndprevstart->point_col, ndstart->point_col);
                    tsp_node_t *ndnext = tsp_solver_lk_get_end_node_for(nodes, col);

                    g += tsp_solver_lk_compute_dist(ndstart->point_col, ndnext->point_col);
                }
                else
                {
                    tsp_node_t *ndstart = tsp_solver_lk_get_node_for(nodes, mat[i][j-1], col, true_t, false_t);
                    tsp_node_t *ndnext = tsp_solver_lk_get_node_for(nodes, mat[i][j], col, false_t, false_t);
                    g += tsp_solver_lk_compute_dist(ndstart->point_col, ndnext->point_col);
                }
            }
        }

        if(i == 0)
        {
            bg = gi = g;
            bpos = i;
        }
        else
        {
            //if(g - bg > 0.f)
            //if(gi - g > 0.f && bg - g > lastdiff)
            if(g < bg)
            {
                lastdiff = bg - g;
                //qDebug() << "Da boss";
                bg = g;
                bpos = i;
                //break;
            }
        }
    }

    *pos = bpos;
    *gain = bg;
}


void tsp_solver_lk_compute_first_best_exchange(tsp_solver_t *solver, tsp_node_t **nodes, int** mat,
                                               int row, int col, double *gain, int *pos, bool_t is_secv)
{
    double gi = 0.f;
    int bpos = -1;
    double bg = gi;

    int i = 0;
    if(col <= 5/*2*/)
    {
        for(i = 0; i < row; i++)
        {
            int j = 0;
            double g = 0.f;

            for(j = 0; j < col; j++)
            {
                if(col > 1)
                {
                    if(j == 0)
                    {
                        tsp_node_t *ndstart = nodes[0];
                        tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                        g += tsp_solver_lk_compute_dist(ndstart->point_col, ndnexts->point_col);
                    }
                    else if(j == col - 1)
                    {
                        tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,mat[i][j-1],col, true_t, false_t);
                        tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                        g += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);

                        tsp_node_t *ndnexte = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, true_t, false_t);
                        tsp_node_t *ndend = tsp_solver_lk_get_end_node_for(nodes, col);
                        g += tsp_solver_lk_compute_dist(ndnexte->point_col, ndend->point_col);
                    }
                    else
                    {
                        tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,mat[i][j-1],col, true_t, false_t);
                        tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                        g += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);
                    }
                }
                else
                {
                    tsp_node_t *ndstart = nodes[0];
                    tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                    g += tsp_solver_lk_compute_dist(ndstart->point_col, ndnexts->point_col);


                    tsp_node_t *ndnexte = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, true_t, false_t);
                    tsp_node_t *ndend = nodes[3];
                    g += tsp_solver_lk_compute_dist(ndnexte->point_col, ndend->point_col);
                }
            }

            if(i == 0)
            {
                gi = bg = g;
                bpos = i;
            }
            else
            {
                if(g < bg)
                {
                    bg = g;
                    bpos = i;
                }
            }
        }
    }
    else
    {
        int l;
        //qDebug() << "Aici " << col;

        int lmax = 0;//is_secv == true_t ? solver->swapPos[col-3].size_secv : solver->swapPos[col-3].size_non_secv;

        if(is_secv == true_t) lmax = solver->swapPos[col-3].size_secv;
        else if(is_secv == false_t) lmax = solver->swapPos[col-3].size_non_secv;
        //qDebug() << "lmax = " << lmax;

        for(l = 0; l < lmax; l++)
        {
            int j = 0;
            double g = 0.f;
            //i = is_secv == true_t ? solver->swapPos[col-4].swapSecvPos[l] : solver->swapPos[col-4].swapNonSecvPos[l];

            if(is_secv == true_t) i = solver->swapPos[col-3].swapSecvPos[l];
            else if(is_secv == false_t) i = solver->swapPos[col-3].swapNonSecvPos[l];

            //qDebug() << "i = " << i;

            for(j = 0; j < col; j++)
            {
                if(col > 1)
                {
                    if(j == 0)
                    {
                        tsp_node_t *ndstart = nodes[0];
                        tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                        g += tsp_solver_lk_compute_dist(ndstart->point_col, ndnexts->point_col);
                    }
                    else if(j == col - 1)
                    {
                        tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,mat[i][j-1],col, true_t, false_t);
                        tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                        g += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);

                        tsp_node_t *ndnexte = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, true_t, false_t);
                        tsp_node_t *ndend = tsp_solver_lk_get_end_node_for(nodes, col);
                        g += tsp_solver_lk_compute_dist(ndnexte->point_col, ndend->point_col);
                    }
                    else
                    {
                        tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,mat[i][j-1],col, true_t, false_t);
                        tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                        g += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);
                    }
                }
                else
                {
                    tsp_node_t *ndstart = nodes[0];
                    tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                    g += tsp_solver_lk_compute_dist(ndstart->point_col, ndnexts->point_col);


                    tsp_node_t *ndnexte = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, true_t, false_t);
                    tsp_node_t *ndend = nodes[3];
                    g += tsp_solver_lk_compute_dist(ndnexte->point_col, ndend->point_col);
                }
            }

            if(i == 0)
            {
                gi = bg = g;
                bpos = i;
            }
            else
            {
                if(g < bg)
                {
                    bg = g;
                    bpos = i;
                }
            }
        }
    }

    *pos = bpos;
    *gain = bg;
}


void tsp_solver_lk_compute_first_best_exchange3(tsp_solver_t *solver, tsp_node_t **nodes, int** mat,
                                                int row, int col, double *gain, int *pos, bool_t is_secv)
{
    double gi = 0.f;
    int bpos = -1;
    double bg = gi;

    int i = 0;
    for(i = 0; i < row; i++)
    {
        int j = 0;
        double g = 0.f;

        for(j = 0; j < col; j++)
        {
            if(col > 1)
            {
                if(j == 0)
                {
                    tsp_node_t *ndstart = nodes[0];
                    tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                    g += tsp_solver_lk_compute_dist(ndstart->point_col, ndnexts->point_col);
                }
                else if(j == col - 1)
                {
                    tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,mat[i][j-1],col, true_t, false_t);
                    tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                    g += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);

                    tsp_node_t *ndnexte = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, true_t, false_t);
                    tsp_node_t *ndend = tsp_solver_lk_get_end_node_for(nodes, col);
                    g += tsp_solver_lk_compute_dist(ndnexte->point_col, ndend->point_col);
                }
                else
                {
                    tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,mat[i][j-1],col, true_t, false_t);
                    tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                    g += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);
                }
            }
            else
            {
                tsp_node_t *ndstart = nodes[0];
                tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, false_t, false_t);
                g += tsp_solver_lk_compute_dist(ndstart->point_col, ndnexts->point_col);


                tsp_node_t *ndnexte = tsp_solver_lk_get_node_for(nodes,mat[i][j],col, true_t, false_t);
                tsp_node_t *ndend = nodes[3];
                g += tsp_solver_lk_compute_dist(ndnexte->point_col, ndend->point_col);
            }
        }

        if(i == 0)
        {
            gi = bg = g;
            bpos = i;
        }
        else
        {
            if(g < bg)
            {
                bg = g;
                bpos = i;
            }
        }
    }
    *pos = bpos;
    *gain = bg;
}




void tsp_solver_lk_test_4opt(tsp_solver_t *solver)
{
    tsp_node_t *node = solver->first;

    tsp_node_t **nodes = (tsp_node_t**)calloc(8, sizeof(tsp_node_t*));

    bool_t noMoreImpr = false_t;
    printPoints22(solver);

    double gain = 0;
    double bgain = DBL_MAX;
    int pos = 0, bpos = 0;
    tsp_node_t **bnodes = (tsp_node_t**)calloc(8, sizeof(tsp_node_t*));

    long exchanges = 0;

    for(tsp_node_t *nd1 = node; noMoreImpr != true_t ; nd1 = nd1->next)
    {
        //qDebug() << "for 1";
        if(nd1->next->next == NULL) break;
        nodes[0] = nd1;
        nodes[1] = nd1->next;
        for(tsp_node_t *nd2 = nd1->next->next; nd2->next->next != nd1; nd2 = nd2->next)
        {
            //qDebug() << "for 2";
            if(nd2->next->next == NULL || nd2->next->next == nd1) break;
            nodes[2] = nd2;
            nodes[3] = nd2->next;
            for(tsp_node_t *nd3 = nd2->next->next; nd3->next->next != nd1; nd3 = nd3->next)
            {
                //qDebug() << "for 3";
                if(nd3->next->next == NULL || nd3->next->next == nd1) break;
                nodes[4] = nd3;
                nodes[5] = nd3->next;
                for(tsp_node_t *nd4 = nd3->next->next; nd4->next->next != NULL && nd4->next->next != nd1; nd4 = nd4->next)
                {
                    //qDebug() << "for 4";
                    if(nd4->next->next == NULL || nd4->next->next == nd1) break;

                    tsp_node_t *nd1n = nd1->next;
                    tsp_node_t *nd2n = nd2->next;
                    tsp_node_t *nd3n = nd3->next;
                    tsp_node_t *nd4n = nd4->next;

                    nodes[0] = nd1;
                    nodes[1] = nd1->next;
                    nodes[2] = nd2;
                    nodes[3] = nd2->next;
                    nodes[4] = nd3;
                    nodes[5] = nd3->next;
                    nodes[6] = nd4;
                    nodes[7] = nd4->next;

                    if(nd1 != nd2 && nd1->next != nd2 && nd1 != nd2->next && nd1->next != nd2->next &&
                       nd1 != nd3 && nd1->next != nd3 && nd1 != nd3->next && nd1->next != nd3->next &&
                       nd1 != nd4 && nd1->next != nd4 && nd1 != nd4->next && nd1->next != nd4->next &&
                       nd2 != nd3 && nd2->next != nd3 && nd2 != nd3->next && nd2->next != nd3->next &&
                       nd2 != nd4 && nd2->next != nd4 && nd2 != nd4->next && nd2->next != nd4->next &&
                       nd3 != nd4 && nd3->next != nd4 && nd3 != nd4->next && nd3->next != nd4->next)
                    {
                        tsp_solver_lk_compute_first_best_exchange(solver, nodes, solver->opt4list->mat,
                                                                    solver->opt4list->size,
                                                                    solver->opt4list->k, &gain, &pos, true_t);
                    }

                    if(pos != 0)
                    {
                        //qDebug() << "pos is not zero";
                        if(gain < bgain)
                        {
                            //qDebug() << "gain = " << gain;
                            //qDebug() << "pos = " << pos;
                            bgain = gain;
                            bpos = pos;

                            bnodes[0] = nodes[0];
                            bnodes[1] = nodes[1];
                            bnodes[2] = nodes[2];
                            bnodes[3] = nodes[3];
                            bnodes[4] = nodes[4];
                            bnodes[5] = nodes[5];
                            bnodes[6] = nodes[6];
                            bnodes[7] = nodes[7];
                        }
                        //else qDebug() << "gain no good gain = " << gain;
                    }
                    //else qDebug() << "pos is - zero";

                    if(nd4->next->next->next == nd1)
                    {

                        if(bpos != 0)
                        {
                            if(nd1 != nd2 && nd1->next != nd2 && nd1 != nd2->next && nd1->next != nd2->next &&
                               nd1 != nd3 && nd1->next != nd3 && nd1 != nd3->next && nd1->next != nd3->next &&
                               nd1 != nd4 && nd1->next != nd4 && nd1 != nd4->next && nd1->next != nd4->next &&
                               nd2 != nd3 && nd2->next != nd3 && nd2 != nd3->next && nd2->next != nd3->next &&
                               nd2 != nd4 && nd2->next != nd4 && nd2 != nd4->next && nd2->next != nd4->next &&
                               nd3 != nd4 && nd3->next != nd4 && nd3 != nd4->next && nd3->next != nd4->next)
                            {
                                qDebug() << "----------------------";
                                qDebug() << "EXCHANGE";
                                exchanges++;
                                qDebug() << "bpos = " << bpos;
                                qDebug() << "bgain = " << bgain;

                                for(int i = 0; i < 3; i++)
                                {
                                    qDebug() << " " << solver->opt4list->mat[bpos][i];
                                }
                                //qDebug() << "k = " << (int)solver->opt4list->k;
                                nodes[6] = bnodes[6];
                                nodes[7] = bnodes[7];

                                tsp_solver_kopt_gen_swap22(nodes, solver->opt4list->mat, solver->opt4list->k, bpos);
                                //bgain = 0;
                                bpos = 0;
                                qDebug() << "----------------------";

                                nd1 = node;
                                nd2 = nd1->next->next;
                                nd3 = nd2->next;
                            }

                            bpos = 0;
                            gain = bgain = DBL_MAX;

                            break;
                        }
                        gain = bgain = DBL_MAX;
                    }
                }
            }
        }

        if(nd1->next == node)
        {
            if(exchanges == 0) noMoreImpr = true_t;
            else exchanges = 0;
        }
    }

    qDebug() << "Finish 4opt";
}

void tsp_solver_lk_lk(tsp_solver_t *solver, double gain, int kmove, int max_kmove, int max_neighbors)
{
    gain = 0.f;

    int mink = kmove;
    int k = kmove;

    if(mink < 2) mink = k = 2;

    int maxk = max_kmove;
    int global_max_kmove = 5;
    bool_t stop = false_t;
    tsp_node_t *node = solver->first;

    if(maxk > global_max_kmove) maxk = global_max_kmove;
    if(k > maxk) k = maxk;

    bool_t noNeighborsLimit = true_t;

    if(max_neighbors > 0) noNeighborsLimit = false_t;
    else if(max_neighbors == -1) noNeighborsLimit = true_t;

    int pos = -1;

    bool_t noMoreImpr = false_t;
    bool_t noMoreGainImpr = false_t;
    bool_t noMoreGainImprFromAbove = false_t;

    double bgain = 0.f;
    int bpos = 0;

    int for2c = 0, for3c = 0, for4c = 0, for5c = 0;
    int escapeFromK = k;

    int iter2opt = 0, iter3opt = 0, iter4opt = 0, iter5opt = 0;

    long exchanges = 0;
    int cycle = 0;

    int t2optf = 0, t3optf = 0, t4optf = 0, t5optf = 0;

    do
    {
        for(tsp_node_t *nd1 = node;
            /*gain >= 0.f && */noMoreImpr == false_t /*&& nd1->next != NULL*/;
            nd1 = nd1->next)
        {
            qDebug() << "Cycle : " << ++cycle;
            double g1 = 0.f;
            if(cycle >= 100000) {noMoreImpr = true_t; break; };

            if(!(nd1->next->next != NULL && nd1->next->next != nd1))
            {
                //qDebug() << "Wrong lel";
                //if(nd1->next->next == NULL) qDebug() << "NULL";
                //if(nd1->next->next == nd1) qDebug() << "ND1";
            }
            else
            for(tsp_node_t *nd2 = nd1->next->next;
                nd2->next != nd1 && nd2->next != NULL;
                nd2 = nd2->next)
            {
                for2c++;
                if(for2c > max_neighbors && noNeighborsLimit == false_t) { for2c = 0; break; }

                qDebug() << "2optFor";
                t2optf++;

                if(k >= 3)
                {
                    if(nd2->next->next != NULL && nd2->next->next != nd1)
                    for(tsp_node_t *nd3 = nd2->next->next;
                        nd3->next != nd1 && nd3->next != NULL;
                        nd3 = nd3->next)
                    {
                        for3c++;
                        if(for3c > max_neighbors && noNeighborsLimit == false_t) { for3c = 0; break; }

                        qDebug() << "3optFor";
                        t3optf++;

                        if(k >= 4)
                        {
                            if(nd3->next->next != NULL && nd3->next->next != nd1)
                            for(tsp_node_t *nd4 = nd3->next->next;
                                nd4->next != nd1 && nd4->next != NULL;
                                nd4 = nd4->next)
                            {
                                for4c++;
                                if(for4c > max_neighbors && noNeighborsLimit == false_t) { for4c = 0; break; }

                                //qDebug() << "4optFor";
                                t4optf++;

                                if(k >= 5)
                                {
                                    if(nd4->next->next != NULL && nd4->next->next != nd1)
                                    for(tsp_node_t *nd5 = nd4->next->next;
                                        nd5->next != nd1 && nd5->next != NULL;
                                        nd5 = nd5->next)
                                    {
                                        for5c++;
                                        if(for5c > max_neighbors && noNeighborsLimit == false_t) { for5c = 0; break; }

                                        tsp_node_t **nodes = (tsp_node_t**)calloc(k*2, sizeof(tsp_node_t*));
                                        nodes[0] = nd1;
                                        nodes[1] = nd1->next;
                                        nodes[2] = nd2;
                                        nodes[3] = nd2->next;
                                        nodes[4] = nd3;
                                        nodes[5] = nd3->next;
                                        nodes[6] = nd4;
                                        nodes[7] = nd4->next;
                                        nodes[8] = nd5;
                                        nodes[9] = nd5->next;

                                        //qDebug() << "5optFor";
                                        t5optf++;

                                        tsp_solver_lk_compute_first_best_exchange(solver, nodes, solver->opt5list->mat,
                                                                                  solver->opt5list->size,
                                                                                  solver->opt5list->k, &g1, &pos, true_t);
                                        if(bgain < g1) { bgain = g1; bpos = pos; }

                                        if(nd5->next->next == nd4 ||
                                           nd5->next->next == NULL ||
                                           for5c == max_neighbors)
                                        {
                                            qDebug() << "Vasile5";

                                            if(bgain > 0.f && bpos != 0)
                                            {
                                                qDebug() << "before swap5";
                                                tsp_solver_kopt_gen_swap22(nodes, solver->opt5list->mat,
                                                                         solver->opt5list->k, bpos);
                                                qDebug() << "after swap5";

                                                exchanges++;
                                                bgain = 0.f;
                                                if(k-1 >= mink) k--;
                                                for5c = 0;
                                                escapeFromK = 5;
                                                break;
                                            }
                                            else if(bpos == 0)
                                            {
                                                qDebug() << "bpos5=0";
                                                bgain = 0.f;
                                                if(k-1 >= mink) k--;
                                                for5c = 0;
                                                break;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    tsp_node_t **nodes = (tsp_node_t**)calloc(k*2, sizeof(tsp_node_t*));
                                    nodes[0] = nd1;
                                    nodes[1] = nd1->next;
                                    nodes[2] = nd2;
                                    nodes[3] = nd2->next;
                                    nodes[4] = nd3;
                                    nodes[5] = nd3->next;
                                    nodes[6] = nd4;
                                    nodes[7] = nd4->next;

                                    tsp_solver_lk_compute_first_best_exchange(solver, nodes, solver->opt4list->mat,
                                                                              solver->opt4list->size,
                                                                              solver->opt4list->k, &g1, &pos, true_t);
                                    if(bgain < g1) { bgain = g1; bpos = pos; }



                                    if(nd4->next->next == nd3 ||
                                       nd4->next->next == NULL ||
                                       for4c == max_neighbors)
                                    {
                                        qDebug() << "Vasile4";

                                        if(bgain > 0.f && bpos != 0)
                                        {
                                            qDebug() << "before swap4";
                                            tsp_solver_kopt_gen_swap22(nodes, solver->opt4list->mat,
                                                                     solver->opt4list->k, bpos);

                                            printPoints22(solver);

                                            qDebug() << "after swap4";
                                            exchanges++;
                                            bgain = 0.f;
                                            if(k-1 >= mink) k--;
                                            for4c = 0;
                                            break;
                                        }
                                        else if(bpos == 0)
                                        {
                                            if(iter4opt == 0)
                                            {
                                                iter4opt++;
                                                if(k+1 <= maxk)
                                                {
                                                    k++;
                                                    for4c = 0;
                                                    bgain = 0.f;
                                                    nd4 = nd3->next->next;
                                                }
                                                else
                                                {
                                                    k--;
                                                    for4c = 0;
                                                    bgain = 0.f;
                                                    iter4opt = 0;
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                iter4opt = 0;
                                                for4c = 0;
                                                bgain = 0.f;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            tsp_node_t **nodes = (tsp_node_t**)calloc(k*2, sizeof(tsp_node_t*));
                            nodes[0] = nd1;
                            nodes[1] = nd1->next;
                            nodes[2] = nd2;
                            nodes[3] = nd2->next;
                            nodes[4] = nd3;
                            nodes[5] = nd3->next;
                            tsp_solver_lk_compute_first_best_exchange(solver, nodes, solver->opt3list->mat,
                                                                      solver->opt3list->size,
                                                                      solver->opt3list->k, &g1, &pos, true_t);

                            if(bgain < g1) { bgain = g1; bpos = pos; }

                            if(nd3->next->next == nd2 ||
                               nd3->next->next == NULL ||
                               for3c == max_neighbors)
                            {
                                if(bgain > 0.f && bpos != 0)
                                {
                                    qDebug() << "before swap3";
                                    tsp_solver_kopt_gen_swap2(nodes, solver->opt3list->mat,
                                                             solver->opt3list->k, bpos);
                                    qDebug() << "after swap3";

                                    exchanges++;
                                    if(k-1 >= mink) k--;
                                    for3c = 0;
                                    bgain = 0.f;
                                    break;
                                }
                                else if(bpos == 0)
                                {
                                    if(iter3opt == 0)
                                    {
                                        iter3opt++;
                                        if(k+1 <= maxk)
                                        {
                                            k++;
                                            for3c = 0;
                                            bgain = 0.f;
                                            nd3 = nd2->next->next;
                                        }
                                        else
                                        {
                                            k--;
                                            for3c = 0;
                                            bgain = 0.f;
                                            iter3opt = 0;
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        iter3opt = 0;
                                        for3c = 0;
                                        bgain = 0.f;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    tsp_node_t **nodes = (tsp_node_t**)calloc(k*2, sizeof(tsp_node_t*));
                    nodes[0] = nd1;
                    nodes[1] = nd1->next;
                    nodes[2] = nd2;
                    nodes[3] = nd2->next;
                    tsp_solver_lk_compute_first_best_exchange(solver, nodes, solver->opt2list->mat,
                                                              solver->opt2list->size,
                                                              solver->opt2list->k, &g1, &pos, true_t);

                    if(bgain < g1) { bgain = g1; bpos = pos; }

                    if(nd2->next->next == nd1 ||
                       nd2->next->next == NULL ||
                       for2c == max_neighbors)
                    {
                        if(bgain > 0.f && bpos != 0)
                        {
                            qDebug() << "before swap2";
                            tsp_solver_kopt_gen_swap2(nodes, solver->opt2list->mat,
                                                     solver->opt2list->k, bpos);
                            qDebug() << "after swap2";

                            exchanges++;
                            bgain = 0.f;
                            for2c = 0;
                            break;
                        }
                        else if(bpos == 0)
                        {
                            qDebug() << "2opt bpos=0";
                            if(iter2opt == 0)
                            {
                                qDebug() << "2opt k++";
                                if(k+1 <= maxk) k++;
                                for2c = 0;
                                bgain = 0.f;
                                iter2opt++;
                                nd2 = nd1->next->next;
                            }
                            else
                            {
                                qDebug() << "inter2opt > 0";
                                for2c = 0;
                                bgain = 0.f;
                                iter2opt = 0;
                                break;
                            }
                        }
                    }
                }

                //qDebug() << "k = " << k;
            }

            //qDebug() << "k = " << k;

            noMoreGainImpr = false_t;

            if(nd1->next->next == node)
            {
                qDebug() << "NODE";
                if(exchanges > 0)
                {
                    exchanges = 0;
                    noMoreImpr = false_t;
                }
                else noMoreImpr = true_t;
            }
            else if(nd1->next->next == NULL)
            {
                if(exchanges > 0)
                {
                    exchanges = 0;
                    noMoreImpr = false_t;
                    nd1 = node;
                }
                else noMoreImpr = true_t;
            }
        }

        if(exchanges > 0)
        {
            noMoreImpr = false_t;
            exchanges = 0;
        }
        else qDebug() << "NoExcenges";

    }
    while(noMoreImpr != true_t);

    qDebug() << "2opt : " << t2optf;
    qDebug() << "3opt : " << t3optf;
    qDebug() << "4opt : " << t4optf;
    qDebug() << "5opt : " << t5optf;
    //while(gain >= 0.f && stop != true_t && noMoreGainImpr != false_t);
}


tsp_node_t **tsp_solver_lk_lk_search_upper_levels(tsp_solver_t *solver, tsp_node_t *ndstart, tsp_node_t *stop,
                                                  tsp_node_t **nodes, int *k, int max_neighbors, int *poss, int maxk)
{
    double gain = 0.f, bgain = DBL_MAX;
    int bpos = 0, neighbor = 0, pos = 0, ck = *k + 1;
    bool_t found = false_t;

    tsp_node_t **auxnodes = (tsp_node_t**)calloc(ck*2, sizeof(tsp_node_t*));

    int i = 0;
    for(i = 0; i < *k*2; i++) auxnodes[i] = nodes[i];

    tsp_node_t *bnode;

    for(tsp_node_t *ndk = ndstart; /*ndk->next != stop && ndk->next != NULL*/; ndk = ndk->next)
    {
        if(/*ndk == stop || */ndk->next == stop/* || ndk == NULL*/ || ndk->next == NULL) { break; }
        if(max_neighbors > 0)
        if(++neighbor > max_neighbors) break;

        auxnodes[ck*2-2] = ndk;
        auxnodes[ck*2-1] = ndk->next;

        tsp_solver_lk_compute_first_best_exchange(solver, auxnodes, solver->optKlist[ck-2]->mat, solver->optKlist[ck-2]->size,
                                                  solver->optKlist[ck-2]->k, &gain, &pos, true_t);

        if(pos > 0 && gain < bgain)
        {
            found = true_t;
            bgain = gain;
            bpos = pos;
            bnode = ndk;
            //break;
        }
        pos = 0;
    }

    if(found != false_t)
    {
        if(ck < maxk)
        {
            if(bnode->next->next != stop &&
               bnode->next != stop &&
               stop != bnode &&
               stop->next != bnode &&
               bnode->next != stop->next)
            {
                *k = ck;
                auxnodes[ck*2-2] = bnode;
                auxnodes[ck*2-1] = bnode->next;
                *poss = bpos;
                return tsp_solver_lk_lk_search_upper_levels(solver, bnode->next->next, stop,
                                                            auxnodes, k, max_neighbors, poss, maxk);
            }
            else if(bnode->next != stop &&
                    stop != bnode &&
                    stop->next != bnode)
            {
                *k = ck;
                auxnodes[ck*2-2] = bnode;
                auxnodes[ck*2-1] = bnode->next;
                *poss = bpos;
                return auxnodes;
            }
            else return nodes;
        }
        else
        {
            if(bnode->next != stop &&
               stop != bnode &&
               stop->next != bnode)
            {
                *k = ck;
                auxnodes[ck*2-2] = bnode;
                auxnodes[ck*2-1] = bnode->next;
                *poss = bpos;
                return auxnodes;
            }
            else return nodes;
        }
    }
    else { return nodes; }
}


tsp_node_t **tsp_solver_lk_lk_search_upper_levels2(tsp_solver_t *solver, tsp_node_t *ndstart, tsp_node_t *stop,
                                                   tsp_node_t **nodes, int *k, int max_neighbors, int *poss, int maxk)
{
    double gain = 0.f, bgain = DBL_MAX;
    int bpos = 0, neighbor = 0, pos = 0, ck = *k + 1;
    bool_t found = false_t;

    //qDebug() << "ck = " << ck;

    tsp_node_t **auxnodes = (tsp_node_t**)calloc(ck*2, sizeof(tsp_node_t*));

    int i = 0;
    for(i = 0; i < *k*2; i++) auxnodes[i] = nodes[i];

    tsp_node_t *bnode;

    for(tsp_node_t *ndk = ndstart; /*ndk->next != stop && ndk->next != NULL*/; ndk = ndk->next)
    {
        if(/*ndk == stop || */ndk->next == stop/* || ndk == NULL*/ || ndk->next == NULL) { break; }
        if(max_neighbors > 0)
        if(++neighbor > max_neighbors) break;

        auxnodes[ck*2-2] = ndk;
        auxnodes[ck*2-1] = ndk->next;

        tsp_solver_lk_compute_first_best_exchange(solver, auxnodes, solver->optKlist[ck-2]->mat, solver->optKlist[ck-2]->size,
                                                   solver->optKlist[ck-2]->k, &gain, &pos, true_t);

        if(pos > 0 && gain < bgain)
        {
            found = true_t;
            bgain = gain;
            bpos = pos;
            bnode = ndk;
            break;
        }
        pos = 0;
    }

    if(found != false_t)
    {
        if(ck < maxk)
        {
            //qDebug() << "11";
            if(bnode->next->next != stop &&
               bnode->next != stop &&
               stop != bnode &&
               stop->next != bnode &&
               bnode->next != stop->next)
            {
                *k = ck;
                auxnodes[ck*2-2] = bnode;
                auxnodes[ck*2-1] = bnode->next;
                *poss = bpos;
                //return tsp_solver_lk_lk_search_upper_levels(solver, bnode->next->next, stop,
                                                            //auxnodes, k, max_neighbors, poss, maxk);
                return auxnodes;
            }
            else if(bnode->next != stop &&
                    stop != bnode &&
                    stop->next != bnode)
            {
                //qDebug() << "22";
                *k = ck;
                auxnodes[ck*2-2] = bnode;
                auxnodes[ck*2-1] = bnode->next;
                *poss = bpos;
                return auxnodes;
            }
            else
            {
                //qDebug() << "33";
                return nodes;
            }
        }
        else
        {
            //qDebug() << "44";
            if(bnode->next != stop &&
               stop != bnode &&
               stop->next != bnode)
            {
                *k = ck;
                auxnodes[ck*2-2] = bnode;
                auxnodes[ck*2-1] = bnode->next;
                *poss = bpos;
                return auxnodes;
            }
            else
            {
                //qDebug() << "55";
                return nodes;
            }
        }
    }
    else
    { //return nodes;

        //qDebug() << "66";
        if(ck < maxk)
        if(ndstart->next->next != stop &&
           ndstart->next != stop &&
           stop != ndstart &&
           stop->next != ndstart &&
           ndstart->next != stop->next)
        {
            //qDebug() << "lel 111";
            *k = ck;
            auxnodes[ck*2-2] = ndstart;
            auxnodes[ck*2-1] = ndstart->next;
            *poss = bpos;
            //qDebug() << "111";
            return tsp_solver_lk_lk_search_upper_levels2(solver, ndstart->next->next, stop,
                                                         auxnodes, k, max_neighbors, poss, maxk);
        }

        //qDebug() << "end 66";
    }

    //qDebug() << "finish lel 1111";
}


double tsp_solver_lk_comp_gain(tsp_point_t pt1, tsp_point_t pt2, tsp_point_t pt3, tsp_point_t pt4)
{
    double dist1 = tsp_solver_lk_compute_dist(pt1, pt2) + tsp_solver_lk_compute_dist(pt3, pt4);
    double dist2 = tsp_solver_lk_compute_dist(pt1, pt3) + tsp_solver_lk_compute_dist(pt2, pt4);
    return dist1 - dist2;
}


tsp_node_t **tsp_solver_lk_perturbation_search2(tsp_solver_t *solver, tsp_node_t *start, tsp_node_t *stop,
                                                tsp_node_t **cnodes, tsp_node_t **bnodes, int *ck, int *bk,
                                                double *cgain, double *bgain, int maxk, int iteration, bool_t done,
                                                int *pos)
{
    tsp_node_t *nd = iteration == 1 ? solver->first : start;
    tsp_node_t **auxnodes = (tsp_node_t**)calloc(iteration*2, sizeof(tsp_node_t*));
    double lgain = *cgain;
    tsp_node_t *bnode;
    bool_t found = false_t;

    int cpos = 0;

    tsp_node_t **bestnodes = (tsp_node_t**)calloc(iteration*2, sizeof(tsp_node_t*));

    memcpy(auxnodes, cnodes, sizeof(tsp_node_t*)*(iteration*2));

    qDebug() << "Iter = " << iteration;

    int ll = 0;

    for(; nd->next != stop; nd = nd->next)
    {
        //if(iteration == 1) qDebug() << "for iter 1 lel : " << (++ll);

        auxnodes[iteration*2-2] = nd;
        auxnodes[iteration*2-1] = nd->next;

        if(iteration == 1)
        {
            if(nd->next == stop)
            {
                //qDebug() << "iter 1 stop crit";
                bnodes = tsp_solver_lk_perturbation_search2(solver, start, stop, cnodes, bnodes,
                                                          ck, bk, cgain, bgain, maxk, iteration+1, true_t, pos);
                break;
            }
            else
            {
                //qDebug() << "iter 1 no stop";
                if(nd->next->next != stop)
                {
                    //qDebug() << "iter 1 stop crit nn";
                    bnodes = tsp_solver_lk_perturbation_search2(solver, nd->next->next, stop, auxnodes, bnodes,
                                                              ck, bk, cgain, bgain, maxk, iteration+1, false_t, pos);
                }
            }
        }
        else if(iteration > 1 && iteration < 4)
        {
            if(done == true_t) break; //return bnodes;
            else
            {
                if(nd->next == stop)
                {
                    bnodes = tsp_solver_lk_perturbation_search2(solver, start, stop, cnodes, bnodes,
                                                              ck, bk, cgain, bgain, maxk, iteration+1, true_t, pos);
                    break;
                }
                else
                {
                    if(nd->next->next != stop)
                    {
                        *cgain = 0.f;
                        *ck = iteration;
                        *cgain += tsp_solver_lk_comp_gain(auxnodes[iteration*2-4]->point_col,
                                                         auxnodes[iteration*2-3]->point_col,
                                                         auxnodes[iteration*2-2]->point_col,
                                                         auxnodes[iteration*2-1]->point_col);

                        bnodes = tsp_solver_lk_perturbation_search2(solver, nd->next->next, stop, auxnodes, bnodes,
                                                                  ck, bk, cgain, bgain, maxk, iteration+1, false_t, pos);
                    }
                }
            }
        }
        else if(iteration == maxk)
        {
            if(done == true_t) break; //return bnodes;
            else
            {
                if(nd->next == stop)
                {
                    break;
                }
                else
                {
                    *ck = iteration;
                    *cgain += tsp_solver_lk_comp_gain(auxnodes[iteration*2-4]->point_col,
                                                      auxnodes[iteration*2-3]->point_col,
                                                      auxnodes[iteration*2-2]->point_col,
                                                      auxnodes[iteration*2-1]->point_col);

                    tsp_solver_lk_compute_first_best_exchange(solver, auxnodes, solver->optKlist[iteration-2]->mat,
                                                              solver->optKlist[iteration-2]->size,
                                                              solver->optKlist[iteration-2]->k, cgain, &cpos, false_t);

                    if(cpos != 0)
                    if(*cgain > *bgain)
                    {
                        *bgain = *cgain;
                        *bk = *ck;
                        *pos = cpos;
                        memcpy(bestnodes, auxnodes, sizeof(tsp_node_t*)*(iteration*2));
                        bnodes = bestnodes;
                    }
                    break;
                }
            }
        }
        else if(iteration >= 4)
        {
            if(done == true_t) break; //return bnodes;
            else
            {
                if(nd->next == stop)
                {
                    bnodes = tsp_solver_lk_perturbation_search2(solver, start, stop, cnodes, bnodes,
                                                              ck, bk, cgain, bgain, maxk, iteration+1, true_t, pos);
                    break;
                }
                else
                {
                    *ck = iteration;
                    *cgain += tsp_solver_lk_comp_gain(auxnodes[iteration*2-4]->point_col,
                                                      auxnodes[iteration*2-3]->point_col,
                                                      auxnodes[iteration*2-2]->point_col,
                                                      auxnodes[iteration*2-1]->point_col);

                    tsp_solver_lk_compute_first_best_exchange(solver, auxnodes, solver->optKlist[iteration-2]->mat,
                                                              solver->optKlist[iteration-2]->size,
                                                              solver->optKlist[iteration-2]->k, cgain, &cpos, false_t);



                    if(cpos != 0)
                    if(*cgain > *bgain)
                    {
                        *bgain = *cgain;
                        *bk = *ck;
                        *pos = cpos;

                        memcpy(bestnodes, auxnodes, sizeof(tsp_node_t*)*(iteration*2));

                        bnodes = bestnodes;

                        if(nd->next->next != stop)
                        {

                            bnodes = tsp_solver_lk_perturbation_search2(solver, nd->next->next, stop, auxnodes, bestnodes,
                                                                      ck, bk, cgain, bgain, maxk, iteration+1, true_t, pos);
                        }
                        else
                        {
                            bnodes = tsp_solver_lk_perturbation_search2(solver, nd->next->next, stop, auxnodes, bestnodes,
                                                                      ck, bk, cgain, bgain, maxk, iteration+1, false_t, pos);
                        }
                    }
                }
            }
        }

        *cgain = lgain;
    }

    //if(iteration == 1)
        return bnodes;
}


tsp_node_t **tsp_solver_lk_perturbation_search(tsp_solver_t *solver, tsp_node_t *ndstart, tsp_node_t *stop,
                                       tsp_node_t **nodes, int *k, int *pos, double *gain, double *bgain,
                                       int maxk, int iteration)
{
    tsp_node_t *nd = iteration == 1 ? solver->first : ndstart;
    tsp_node_t **auxnodes = (tsp_node_t**)calloc(iteration*2,sizeof(tsp_node_t*));
    double cgain = *gain;
    double auxgain = 0.f;
    int ck = *k;
    int cpos = *pos;
    tsp_node_t *bnode;
    bool_t found = false_t;

    memcpy(auxnodes, nodes, sizeof(tsp_node_t*)*(iteration*2));

    for(; nd->next != stop; nd = nd->next)
    {
        auxnodes[iteration*2-2] = nd;
        auxnodes[iteration*2-1] = nd->next;

        if(iteration == 1)
        {
            qDebug() << "iter == 1 : " << iteration;
            if(nd->next->next != stop)
            {
                *k = iteration;
                return tsp_solver_lk_perturbation_search(solver, nd->next->next, stop, auxnodes,
                                                        k, pos, gain, bgain, maxk, iteration+1);
            }
        }
        else if(iteration > 1 && iteration < 4)
        {
            qDebug() << "iter >1 <4 : " << iteration;

            *gain = 0.f;
            *k = iteration;
            *gain += tsp_solver_lk_comp_gain(auxnodes[iteration*2-4]->point_col, auxnodes[iteration*2-3]->point_col,
                                             auxnodes[iteration*2-2]->point_col, auxnodes[iteration*2-1]->point_col);
            return tsp_solver_lk_perturbation_search(solver, nd->next->next, stop, auxnodes,
                                                     k, pos, gain, bgain, maxk, iteration+1);

        }
        else if(iteration == maxk)
        {
            qDebug() << "iter == maxk : " << iteration;

            *gain += tsp_solver_lk_comp_gain(auxnodes[iteration*2-4]->point_col, auxnodes[iteration*2-3]->point_col,
                                             auxnodes[iteration*2-2]->point_col, auxnodes[iteration*2-1]->point_col);
            if(*gain > *bgain)
            {
                *bgain = *gain;
                bnode = nd;
                *k = iteration;
                found = true_t;
            }
        }
        else if(iteration >= 4)
        {
            qDebug() << "iter >= 4 : " << iteration;

            *gain += tsp_solver_lk_comp_gain(auxnodes[iteration*2-4]->point_col, auxnodes[iteration*2-3]->point_col,
                                             auxnodes[iteration*2-2]->point_col, auxnodes[iteration*2-1]->point_col);
            if(*gain > *bgain)
            {
                *bgain = *gain;
                bnode = nd;
                *k = iteration;
                found = true_t;
                qDebug() << "* found >= 4";
            }

            if(found == true_t)
                return tsp_solver_lk_perturbation_search(solver, nd->next->next, stop, auxnodes,
                                                     k, pos, gain, bgain, maxk, iteration+1);
        }

        *gain = cgain;
    }

    if(found == true_t)
    {
        if(iteration >= 4)
        {
            qDebug() << "Found if";
            auxnodes[iteration*2-2] = bnode;
            auxnodes[iteration*2-1] = bnode->next;
            *k = iteration;
            return auxnodes;
        }
    }
    else
    {
        //qDebug() << "else found";
        //*k = iteration;
        //return nodes;
    }
}




void tsp_solver_lk_perturbation_kopt_gain_compute(tsp_solver_t *solver, tsp_node_t **nodes, double *bgain, int *bpos, int k)
{
    double best_gain = -(DBL_MAX-10);
    double dist = 0.f;
    int pos = 0, l = 0;
    for(l = 0; l < solver->swapPos[k-4].size_non_secv; l++)
    {
        double gain = 0.f;
        int i = solver->swapPos[k-4].swapNonSecvPos[l], j = 0;
        for(j = 0; j < solver->optKlist[k-2]->k; j++)
        {
            if(j == 0)
            {
                tsp_node_t *ndstart = nodes[0];
                tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j],
                                                                 solver->optKlist[k-2]->k, false_t, false_t);
                gain += tsp_solver_lk_compute_dist(ndstart->point_col, ndnexts->point_col);
            }
            else if(j == solver->optKlist[k-2]->k - 1)
            {
                tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j-1],
                                                                 solver->optKlist[k-2]->k, true_t, false_t);
                tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j],
                                                                 solver->optKlist[k-2]->k, false_t, false_t);
                gain += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);

                tsp_node_t *ndnexte = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j],
                                                                 solver->optKlist[k-2]->k, true_t, false_t);
                tsp_node_t *ndend = tsp_solver_lk_get_end_node_for(nodes, solver->optKlist[k-2]->k);
                gain += tsp_solver_lk_compute_dist(ndnexte->point_col, ndend->point_col);
            }
            else
            {
                tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j-1],
                                                                 solver->optKlist[k-2]->k, true_t, false_t);
                tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j],
                                                                 solver->optKlist[k-2]->k, false_t, false_t);
                gain += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);
            }
        }

        if(l == 0)
        {
            best_gain = -(DBL_MAX-10);
            pos = 0;
            dist = gain;
        }
        else
        {
            if(dist - gain > best_gain)
            {
                best_gain = dist - gain;
                pos = i;
            }
        }

        //gain = fabs(gain);

        //if(gain < best_gain)
        //{ best_gain = gain; pos = i; }
    }
    *bpos = pos;
    *bgain = best_gain;
}


bool_t tsp_solver_lk_perturbation_point_set_check(tsp_solver_t *solver, tsp_node_t **nodes, int pos, int k)
{
    int i = 0, hash_code = 0;
    hash_code += pos * solver->hash_numbers[0];
    for(i = 0; i < k; i++)
        hash_code += nodes[i*2]->point_index   * solver->prime_vect[i*2+1] +
                     nodes[i*2+1]->point_index * solver->prime_vect[i*2+2];
    for(i = 0; i < solver->hash_numbers_last_index; i++)
        if(hash_code == solver->hash_numbers[i]) return true_t;
    return false_t;
}

void tsp_solver_lk_perturbation_upper_level_search(tsp_solver_t *solver, tsp_node_t *ndstart, tsp_node_t *stop,
                                                   tsp_node_t **nodes, tsp_node_t ***bnodes, int *k, int *bk,
                                                   int *pos, double *gain, double *bgain, int maxk)
{
    int ck = *k + 1, cpos = 0;
    double cgain = 0.f;
    tsp_node_t **auxnodes = (tsp_node_t**)calloc((ck)*2, sizeof(tsp_node_t*));
    memcpy(auxnodes, nodes, sizeof(tsp_node_t*)*((ck-1)*2));

    if(ndstart != stop && ndstart != stop->next && ndstart->next != stop && ndstart->next != stop->next)
    for(tsp_node_t *ndk = ndstart; ndk->next != stop && ndk->next != NULL; ndk = ndk->next)
    {
        auxnodes[ck*2-2] = ndk;
        auxnodes[ck*2-1] = ndk->next;
        cgain = 0.f; cpos = 0;

        tsp_solver_lk_perturbation_kopt_gain_compute(solver, auxnodes, &cgain, &cpos, ck);

        if(cgain > *bgain && cpos != 0)
        {
            if(solver->hash_numbers_last_index > 0)
            {
                if(tsp_solver_lk_perturbation_point_set_check(solver, auxnodes, cpos, ck) == false_t)
                {
                    *bgain = cgain; *pos = cpos;
                    *bk = ck; *bnodes = auxnodes;
                    //break;
                }
            }
            else
            {
                *bgain = cgain; *pos = cpos;
                *bk = ck; *bnodes = auxnodes;
                //break;
            }

        }

        if(ck < maxk)
        {
            if(ndk->next->next != stop && ndk->next->next != NULL &&
               ndk->next != stop && ndk->next != NULL &&
               ndk != stop && ndk != NULL)
            tsp_solver_lk_perturbation_upper_level_search(solver, ndk->next->next, stop, auxnodes, bnodes,
                                                          &ck, bk, pos, gain, bgain, maxk);
        }
    }
}

double tsp_solver_lk_3opt_presearch_gain_compute(tsp_solver_t *solver, tsp_node_t **nodes, int k)
{
    double bgain = -(DBL_MAX-10), dist = 0.f;

    int i = 0;
    for(i = 0; i < solver->optKlist[k-2]->size; i++)
    {
        //qDebug() << "for1 ---";

        double gain = 0.f;
        int j = 0;
        for(j = 0; j < solver->optKlist[k-2]->k; j++)
        {
            //qDebug() << "for2 ---";

            if(j == 0)
            {
                tsp_node_t *ndstart = nodes[0];
                tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j],
                                                                 solver->optKlist[k-2]->k, false_t, false_t);
                gain += tsp_solver_lk_compute_dist(ndstart->point_col, ndnexts->point_col);
            }
            else if(j == solver->optKlist[k-2]->k - 1)
            {
                tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j-1],
                                                                 solver->optKlist[k-2]->k, true_t, false_t);
                tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j],
                                                                 solver->optKlist[k-2]->k, false_t, false_t);
                gain += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);

                tsp_node_t *ndnexte = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j],
                                                                 solver->optKlist[k-2]->k, true_t, false_t);
                tsp_node_t *ndend = tsp_solver_lk_get_end_node_for(nodes, solver->optKlist[k-2]->k);
                gain += tsp_solver_lk_compute_dist(ndnexte->point_col, ndend->point_col);
            }
            else
            {
                tsp_node_t *ndpreve = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j-1],
                                                                 solver->optKlist[k-2]->k, true_t, false_t);
                tsp_node_t *ndnexts = tsp_solver_lk_get_node_for(nodes,solver->optKlist[k-2]->mat[i][j],
                                                                 solver->optKlist[k-2]->k, false_t, false_t);
                gain += tsp_solver_lk_compute_dist(ndpreve->point_col, ndnexts->point_col);
            }
        }
//        gain = fabs(gain);
//        if(gain < bgain) bgain = gain;

        if(i == 0)
        {
            bgain = 0.f;
            dist = gain;
        }
        else
        {
            if(dist - gain > bgain)
            {
                bgain = dist - gain;
            }
        }
    }
    return bgain;
}


void tsp_solver_lk_3opt_presearch_perturbation(tsp_solver_t *solver, tsp_node_t ***bnodes)
{
    double best_gain = -(DBL_MAX-10), current_gain = 0.f;
    int k = 3;

    for(tsp_node_t *nd1 = solver->first; nd1->next != solver->first && nd1->next != NULL; nd1 = nd1->next)
    {
        //qDebug() << "for1 : " << for1++;
        if(nd1->next->next != nd1 && nd1->next->next != NULL)
        for(tsp_node_t *nd2 = nd1->next->next; nd2->next != nd1 && nd2->next != NULL; nd2 = nd2->next)
        {
            //qDebug() << "for2 : " << for1 << " : " << for2++;
            if(nd2->next->next != nd1 && nd2->next->next != NULL)
            for(tsp_node_t *nd3 = nd2->next->next; nd3->next != nd1 && nd3->next != NULL; nd3 = nd3->next)
            {
                //qDebug() << "for3 : " << for1 << " : " << for2 << " : " << for3++;
                tsp_node_t **nodes = (tsp_node_t**)calloc(6, sizeof(tsp_node_t*));

                nodes[0] = nd1;
                nodes[1] = nd1->next;
                nodes[2] = nd2;
                nodes[3] = nd2->next;
                nodes[4] = nd3;
                nodes[5] = nd3->next;

                //qDebug() << "before 3opt presearch ---";
                current_gain = tsp_solver_lk_3opt_presearch_gain_compute(solver, nodes, k);
                //qDebug() << "after 3opt presearch ---";

                if(current_gain > best_gain)
                {
                    best_gain = current_gain;
                    *bnodes = nodes;
                }
            }
        }
    }
}


bool_t tsp_solver_lk_check_time_stop_criterion(long start_time, long curr_time, long stop_msec_time)
{
    long difference = curr_time - start_time;
    long msec = difference * 1000 / CLOCKS_PER_SEC;
    if(msec % 1000 > stop_msec_time) return false_t;
    return true_t;
}


double tsp_solver_lk_get_path_len(tsp_solver_t *solver)
{
    double path = 0.f;

    for(tsp_node_t *nd = solver->first; nd->next != solver->first && nd->next != NULL; nd = nd->next)
    {
        path += tsp_solver_lk_compute_dist(nd->point_col, nd->next->point_col);
    }

    return path;
}

tsp_node_t** tsp_solver_lk_random_perturbation(tsp_solver_t *solver, int k, int max_nodes)
{
    tsp_node_t **nodes = (tsp_node_t**)calloc(k*2, sizeof(tsp_node_t*));
    int *vect = (int*)calloc(k, sizeof(int));
    memset(vect, -1, sizeof(int)*k);
    bool_t found = false_t;
    int index_vect = 0;

    int ccc = 0;

    do
    {
        int r = rand() % (max_nodes-2);
        //qDebug() << "ccc = " << (++ccc) << "r = " << r;
        if(index_vect == 0)
        {
            vect[index_vect] = r;
            index_vect++;
        }
        else if(index_vect == k)
        {
            int i = 0, j = 0;
            for(i = 0; i < k - 1; i++)
            {
                for(j = i+1; j < k; j++)
                {
                    if(vect[i] > vect[j])
                    {
                        vect[i] = vect[i] ^ vect[j];
                        vect[j] = vect[j] ^ vect[i];
                        vect[i] = vect[i] ^ vect[j];
                    }
                }
            }
            found = true_t;
        }
        else
        {
            int i = 0;
            bool_t ok = true_t;
            for(i = 0; i < index_vect; i++)
            {
                if(r == vect[i] || r - 1 == vect[i] || r + 1 == vect[i])
                {
                    ok = false_t;
                    break;
                }
            }

            if(ok == true_t)
            {
                vect[index_vect] = r;
                index_vect++;
            }
        }
    }
    while(found == false_t);

    int count = 0;
    tsp_node_t *nd;
    index_vect = 0;

    for(nd = solver->first; nd->next->next != solver->first; nd = nd->next)
    {
        if(index_vect == k) break;
        if(vect[index_vect] == count)
        {
            nodes[index_vect*2] = nd;
            nodes[index_vect*2+1] = nd->next;
            //nd = nd->next;
            index_vect++;
        }
        count++;
    }

//    qDebug() << "index vect = " << index_vect;
//    qDebug() << "count = " << count;

//    for(int l = 0; l < k; l++)
//        qDebug() << "vect[" << l << "] = " << vect[l];

//    exit(0);

    return nodes;
}

void tsp_solver_lk_lk2(tsp_solver_t *solver, int kmove, int max_kmove, int max_neighbors)
{
    solver->bestLen = DBL_MAX;

    int mink = kmove, k = kmove, pos = -1, bpos = 0, maxk = max_kmove, global_max_kmove = 6, global_min_kmove = 2;
    double gain = 0.f, bgain = 0.f;
    tsp_node_t *node = solver->first;
    bool_t noNeighborsLimit = true_t, noMoreImpr = false_t;
    long exchanges = 0;
    int neighbor = 0;

    if(mink < global_min_kmove) mink = k = global_min_kmove;
    if(maxk > global_max_kmove) maxk = global_max_kmove;
    if(k > maxk) k = maxk;
    if(max_neighbors > 0) noNeighborsLimit = false_t;
    else if(max_neighbors == -1) noNeighborsLimit = true_t;

    int cycle = 0, auxk = k, dpos = 0, noMoreImprC = 0;

    int *cKopt = (int*)calloc(max_kmove-1, sizeof(int));

    double bestDist = -(DBL_MAX-10), dist = 0.f;

    tsp_node_t *bnd1, *bnd2;


    int ii = 0;
    for(ii = 0; ii < solver->hash_numbers_size; ii++)
    {
        solver->hash_numbers[ii] = 0;
    }
    solver->hash_numbers_last_index = 0;

    tsp_node_t **last_hash_nodes;
    int last_hash_k = 0, last_hash_pos = 0;


    clock_t start_time = clock();

    do
    {
        for(tsp_node_t *nd1 = node; noMoreImpr == false_t; nd1 = nd1->next)
        {
            //qDebug() << "for1";
            if(nd1->next == node) {/* qDebug() << "--cycle--"; */cycle++; }
            //if(cycle > 20) noMoreImpr = true_t;
            //else qDebug() << "Cycle : " << cycle;
            if(nd1->next->next != nd1)
            for(tsp_node_t *nd2 = nd1->next->next; nd2->next != nd1; nd2 = nd2->next)
            {
                //qDebug() << "for2";
                tsp_node_t **nodes = (tsp_node_t**)calloc(4, sizeof(tsp_node_t*));
                tsp_node_t **auxnodes;
                nodes[0] = nd1; nodes[1] = nd1->next;
                nodes[2] = nd2; nodes[3] = nd2->next;
                if(max_neighbors > 0)
                if(++neighbor > max_neighbors)
                    { neighbor = 0; pos = 0; gain = 0; auxk = k; bestDist = -(DBL_MAX-10); /*found = false_t;*/ break; }

                tsp_solver_lk_compute_first_best_exchange(solver, nodes, solver->optKlist[auxk-2]->mat,
                                                          solver->optKlist[auxk-2]->size,
                                                          solver->optKlist[auxk-2]->k, &gain, &pos, true_t);

                if(pos != 0 && nd1 != nd2 && nd1->next != nd2 && nd1 != nd2->next && nd1->next != nd2->next)
                {
                    exchanges++;
                    if(nd2->next->next != nd1 && nd2->next->next != NULL && nd2 != nd1 &&
                       nd1->next != nd2 && nd1 != nd2->next && nd1->next != nd2->next)
                    {
                        auxnodes = tsp_solver_lk_lk_search_upper_levels(solver, nd2->next->next, nd1,
                                                                        nodes, &auxk, max_neighbors, &dpos, max_kmove);
                    }
                }

                if(dpos != 0 || pos != 0)
                {
                    cKopt[auxk-2]++;
                    if(dpos != 0)
                    { tsp_solver_kopt_gen_swap22(auxnodes, solver->optKlist[auxk-2]->mat, solver->optKlist[auxk-2]->k, dpos); }
                    else if(pos != 0)
                    { tsp_solver_kopt_gen_swap22(nodes, solver->optKlist[auxk-2]->mat, solver->optKlist[auxk-2]->k, pos); }
                    pos = 0; dpos = 0; auxk = k; //break;
                }
            }

            neighbor = 0; pos = 0; gain = 0; auxk = k; bestDist = -(DBL_MAX-10);
            if(cycle > 3)
            {
                //qDebug() << "xchg : " << exchanges;
                if(exchanges > 0) { exchanges = 0; cycle = 0; }
                else { noMoreImpr = true_t; noMoreImprC++; }
            }
        }

        double path = tsp_solver_lk_get_path_len(solver);
        qDebug() << "Path length lk2 : " << path;
        if(path < solver->bestLen)
        {
            tsp_solver_lk_copy_best_list(solver, path);

//            if(last_hash_k > 0)
//            {
//                int i = 0;
//                long local_hash_code = 0;
//                local_hash_code += last_hash_pos * solver->prime_vect[0];

//                for(i = 0; i < last_hash_k; i++)
//                {
//                    local_hash_code += last_hash_nodes[i*2]->point_index   * solver->prime_vect[i*2+1] +
//                                       last_hash_nodes[i*2+1]->point_index * solver->prime_vect[i*2+2];
//                }
//                if(solver->hash_numbers_last_index < solver->hash_numbers_size)
//                {
//                    solver->hash_numbers[solver->hash_numbers_last_index] = local_hash_code;
//                    solver->hash_numbers_last_index++;
//                }
//                else
//                {
//                    solver->hash_numbers_last_index = 0;
//                    solver->hash_numbers[solver->hash_numbers_last_index] = local_hash_code;
//                    solver->hash_numbers_last_index++;
//                }
//                last_hash_k = 0;
//            }
        }
        else
        {
            if(last_hash_k > 0)
            {
                int i = 0;
                long local_hash_code = 0;

                local_hash_code += last_hash_pos * solver->prime_vect[0];

                for(i = 0; i < last_hash_k; i++)
                {
                    local_hash_code += last_hash_nodes[i*2]->point_index   * solver->prime_vect[i*2+1] +
                                       last_hash_nodes[i*2+1]->point_index * solver->prime_vect[i*2+2];
                }
                if(solver->hash_numbers_last_index < solver->hash_numbers_size)
                {
                    solver->hash_numbers[solver->hash_numbers_last_index] = local_hash_code;
                    solver->hash_numbers_last_index++;
                }
                else
                {
                    solver->hash_numbers_last_index = 0;
                    solver->hash_numbers[solver->hash_numbers_last_index] = local_hash_code;
                    solver->hash_numbers_last_index++;
                }
                last_hash_k = 0;
            }

            tsp_node_t *nd_good = solver->best;
            tsp_node_t *nd_bad = solver->first;

            for(tsp_node_t *nd = nd_good; nd != NULL; nd = nd->next)
            {
                nd_bad->partition_index = nd->partition_index;
                nd_bad->point_col.x = nd->point_col.x;
                nd_bad->point_col.y = nd->point_col.y;
                nd_bad->point_index = nd->point_index;
                nd_bad = nd_bad->next;
            }

            //qDebug() << "--|| AFTER COPY BEST CYCLE UNTIL NOW ||--\n";
        }




        int zzx = 1;

        if(zzx != 0)
        if(noMoreImpr == true_t && noMoreImprC < 50)
        {
            if(tsp_solver_lk_check_time_stop_criterion(start_time,clock(),3333) == false_t)
            {
                noMoreImpr = true_t;
            }
            else
            {
                int ck = 1, mk = 3, bk = 3;
                auxk = 2;
                int cpos = 0, bpos = 0;
                double cgain = 0.f, cbgain = -(DBL_MAX-10);

//                tsp_node_t **bnodes;
                int zzz = 0, for1 = 0, for2 = 0, for3 = 0;


                tsp_node_t **bnodes;
                bk = 4;
                bpos = 1;

               // qDebug() << "---before random perturbation---";
                bnodes = tsp_solver_lk_random_perturbation(solver, bk, solver->number_of_nodes);
               // qDebug() << "---after random perturbation---";

                //for(int i = 0; i < bk; i++)
                    //qDebug() << "Index : " << bnodes[i*2]->point_index << " --> " << bnodes[i*2+1]->point_index;

                //tsp_solver_lk_3opt_presearch_perturbation(solver, &bnodes);
                //tsp_solver_lk_perturbation_upper_level_search(solver, bnodes[mk*2-1]->next, bnodes[0], bnodes,
                //                                              &bnodes, &mk, &bk, &bpos, &cgain,
                //                                              &cbgain, max_kmove);

                //qDebug() << "bpos = " << bpos;
                //qDebug() << "bk   = " << bk;

                if(bpos != 0 && bk > 3)
                {
                    last_hash_nodes = bnodes;
                    last_hash_k = bk;
                    last_hash_pos = bpos;

                    tsp_solver_kopt_gen_swap22(bnodes, solver->optKlist[bk-2]->mat, solver->optKlist[bk-2]->k, bpos);
                    //qDebug() << "\nQQ ----------------------------------------- QQ\n";
                    //printPoints22(solver);
                    //qDebug() << "\nQQ ----------------------------------------- QQ\n";

                    noMoreImpr = false_t; bestDist = -(DBL_MAX-10);
                    cycle = 0; exchanges = 0; neighbor = 0;
                    pos = 0; dpos = 0; gain = 0.f; auxk = k;
                }
                else break;
            }
        }
    }
    while(noMoreImpr != true_t && tsp_solver_lk_check_time_stop_criterion(start_time, clock(), 5000) != false_t);

    for(int i = 2; i <= max_kmove; i++)
    { qDebug() << "c" << (i) << "opt : " << cKopt[i-2]; }
}


void tsp_solver_lk_lk3(tsp_solver_t *solver, int kmove, int max_kmove, int max_neighbors)
{
    solver->bestLen = DBL_MAX;

    int mink = kmove, k = kmove, pos = -1, bpos = 0, maxk = max_kmove, global_max_kmove = 6, global_min_kmove = 2;
    double gain = 0.f, bgain = 0.f;
    tsp_node_t *node = solver->first;
    bool_t noNeighborsLimit = true_t, noMoreImpr = false_t;
    long exchanges = 0;
    int neighbor = 0;

    if(mink < global_min_kmove) mink = k = global_min_kmove;
    if(maxk > global_max_kmove) maxk = global_max_kmove;
    if(k > maxk) k = maxk;
    if(max_neighbors > 0) noNeighborsLimit = false_t;
    else if(max_neighbors == -1) noNeighborsLimit = true_t;

    int cycle = 0, auxk = k, dpos = 0, noMoreImprC = 0;

    int *cKopt = (int*)calloc(max_kmove-1, sizeof(int));

    double bestDist = -(DBL_MAX-10), dist = 0.f;

    tsp_node_t *bnd1, *bnd2;


    int ii = 0;
    for(ii = 0; ii < solver->hash_numbers_size; ii++)
    {
        solver->hash_numbers[ii] = 0;
    }
    solver->hash_numbers_last_index = 0;

    tsp_node_t **last_hash_nodes;
    int last_hash_k = 0, last_hash_pos = 0;


    clock_t start_time = clock();

    do
    {
        for(tsp_node_t *nd1 = node; noMoreImpr == false_t; nd1 = nd1->next)
        {
            if(nd1->next == node) {/* qDebug() << "--cycle--"; */cycle++; }

            if(nd1->next->next != nd1)
            for(tsp_node_t *nd2 = nd1->next->next; nd2->next != nd1; nd2 = nd2->next)
            {
                tsp_node_t **nodes = (tsp_node_t**)calloc(4, sizeof(tsp_node_t*));
                tsp_node_t **auxnodes;
                nodes[0] = nd1; nodes[1] = nd1->next;
                nodes[2] = nd2; nodes[3] = nd2->next;
                if(max_neighbors > 0)
                if(++neighbor > max_neighbors)
                    { neighbor = 0; pos = 0; gain = 0; auxk = k; bestDist = -(DBL_MAX-10); /*found = false_t;*/ break; }

                tsp_solver_lk_compute_first_best_exchange(solver, nodes, solver->optKlist[auxk-2]->mat,
                                                          solver->optKlist[auxk-2]->size,
                                                          solver->optKlist[auxk-2]->k, &gain, &pos, true_t);

                if(pos != 0)
                {
                    cKopt[auxk-2]++;
                    exchanges++;
                    tsp_solver_kopt_gen_swap22(nodes, solver->optKlist[auxk-2]->mat, solver->optKlist[auxk-2]->k, pos);
                    pos = 0; dpos = 0; auxk = k;
                }
                else
                {
                    if(nd2->next->next != nd1 && nd2->next->next != NULL && nd2 != nd1 &&
                       nd1->next != nd2 && nd1 != nd2->next && nd1->next != nd2->next)
                    {
                        auxnodes = tsp_solver_lk_lk_search_upper_levels2(solver, nd2->next->next, nd1,
                                                                         nodes, &auxk, max_neighbors, &dpos, max_kmove);
                    }

                    if(dpos != 0)
                    {
                        cKopt[auxk-2]++;
                        exchanges++;
                        tsp_solver_kopt_gen_swap22(auxnodes, solver->optKlist[auxk-2]->mat, solver->optKlist[auxk-2]->k, dpos);
                    }
                    pos = 0; dpos = 0; auxk = k;
                }
            }

            neighbor = 0; pos = 0; gain = 0; auxk = k; bestDist = -(DBL_MAX-10);
            if(cycle > 3)
            {
                if(exchanges > 0) { exchanges = 0; cycle = 0; }
                else { noMoreImpr = true_t; noMoreImprC++; }
            }
        }

        long hash_code = 0;



        double path = tsp_solver_lk_get_path_len(solver);
        qDebug() << "Path length lk3 : " << path;
        if(path < solver->bestLen)
        {
            tsp_solver_lk_copy_best_list(solver, path);

//            if(last_hash_k > 0)
//            {
//                int i = 0;
//                long local_hash_code = 0;
//                local_hash_code += last_hash_pos * solver->prime_vect[0];

//                for(i = 0; i < last_hash_k; i++)
//                {
//                    local_hash_code += last_hash_nodes[i*2]->point_index   * solver->prime_vect[i*2+1] +
//                                       last_hash_nodes[i*2+1]->point_index * solver->prime_vect[i*2+2];
//                }
//                if(solver->hash_numbers_last_index < solver->hash_numbers_size)
//                {
//                    solver->hash_numbers[solver->hash_numbers_last_index] = local_hash_code;
//                    solver->hash_numbers_last_index++;
//                }
//                else
//                {
//                    solver->hash_numbers_last_index = 0;
//                    solver->hash_numbers[solver->hash_numbers_last_index] = local_hash_code;
//                    solver->hash_numbers_last_index++;
//                }
//                last_hash_k = 0;
//            }
        }
        else
        {
            if(last_hash_k > 0)
            {
                int i = 0;
                long local_hash_code = 0;

                local_hash_code += last_hash_pos * solver->prime_vect[0];

                for(i = 0; i < last_hash_k; i++)
                {
                    local_hash_code += last_hash_nodes[i*2]->point_index   * solver->prime_vect[i*2+1] +
                                       last_hash_nodes[i*2+1]->point_index * solver->prime_vect[i*2+2];
                }
                if(solver->hash_numbers_last_index < solver->hash_numbers_size)
                {
                    solver->hash_numbers[solver->hash_numbers_last_index] = local_hash_code;
                    solver->hash_numbers_last_index++;
                }
                else
                {
                    solver->hash_numbers_last_index = 0;
                    solver->hash_numbers[solver->hash_numbers_last_index] = local_hash_code;
                    solver->hash_numbers_last_index++;
                }
                last_hash_k = 0;
            }

            tsp_node_t *nd_good = solver->best;
            tsp_node_t *nd_bad = solver->first;

            for(tsp_node_t *nd = nd_good; nd != NULL; nd = nd->next)
            {
                nd_bad->partition_index = nd->partition_index;
                nd_bad->point_col.x = nd->point_col.x;
                nd_bad->point_col.y = nd->point_col.y;
                nd_bad->point_index = nd->point_index;
                nd_bad = nd_bad->next;
            }
        }

        int zzx = 1;

        if(zzx != 0)
        if(noMoreImpr == true_t && noMoreImprC < 6)
        {
            if(tsp_solver_lk_check_time_stop_criterion(start_time,clock(),4200) == false_t)
            {
                noMoreImpr = true_t;
            }
            else
            {
                int ck = 1, mk = 3, bk = 3;
                auxk = 2;
                int cpos = 0, bpos = 0;
                double cgain = 0.f, cbgain = -(DBL_MAX-10);

                tsp_node_t **bnodes;
                int zzz = 0, for1 = 0, for2 = 0, for3 = 0;


                bk = 4;
                bpos = 1;

                bnodes = tsp_solver_lk_random_perturbation(solver, bk, solver->number_of_nodes);


//                tsp_solver_lk_3opt_presearch_perturbation(solver, &bnodes);
//                tsp_solver_lk_perturbation_upper_level_search(solver, bnodes[mk*2-1]->next, bnodes[0], bnodes,
//                                                              &bnodes, &mk, &bk, &bpos, &cgain,
//                                                              &cbgain, max_kmove);

                //qDebug() << "--|| AFTER UPPER PERTURBATION SEARCH ||--\n";

                //qDebug() << "bpos = " << bpos;
                //qDebug() << "bk   = " << bk;

                if(bpos != 0 && bk > 3)
                {
                    //qDebug() << "\nQQ1 ----------------------------------------- QQ1\n";
                    //printPoints22(solver);
                    //qDebug() << "\nQQ1 ----------------------------------------- QQ1\n";

                    //qDebug() << "\nHHHH-------------------HHHH\n";
                    //for(int z = 0; z < bk; z++)
                    //{
                    //    qDebug() << "P" << bnodes[z*2]->point_index << " -> P" << bnodes[z*2+1]->point_index;
                    //}
                    //qDebug() << "\nHHHH-------------------HHHH\n";

                    //qDebug() << "--|| BEFORE INIT LAST HASH ||--\n";

                    last_hash_nodes = bnodes;
                    last_hash_k = bk;
                    last_hash_pos = bpos;

                    //qDebug() << "--|| AFTER INIT LAST HASH ||--\n";

                    tsp_solver_kopt_gen_swap22(bnodes, solver->optKlist[bk-2]->mat, solver->optKlist[bk-2]->k, bpos);

                    //qDebug() << "--|| AFTER PERTURBATION SET SWAP ||--\n";

                    //qDebug() << "\nQQ2 ----------------------------------------- QQ2\n";
                    //printPoints22(solver);
                    //qDebug() << "\nQQ2 ----------------------------------------- QQ2\n";

                    noMoreImpr = false_t; bestDist = -(DBL_MAX-10);
                    cycle = 0; exchanges = 0; neighbor = 0;
                    pos = 0; dpos = 0; gain = 0.f; auxk = k;
                }
                else break;
            }
        }
    }
    while(noMoreImpr != true_t && tsp_solver_lk_check_time_stop_criterion(start_time, clock(), 5000) != false_t);

    for(int i = 2; i <= max_kmove; i++)
    { qDebug() << "c" << (i) << "opt : " << cKopt[i-2]; }
}


tsp_node_t** tsp_solver_double_bridge_perturbation_search(tsp_solver_t *solver, int *poss)
{
    tsp_node_t **nodes = (tsp_node_t**)calloc(8, sizeof(tsp_node_t*));
    tsp_node_t **auxnodes = (tsp_node_t**)calloc(8, sizeof(tsp_node_t*));
    double gain = 0.f, bgain = 0.f;
    int pos = 0, bpos = 0;

    qDebug() << "\n-|_|_|_|_|_|_|-\n";

    for(tsp_node_t *nd1 = solver->first; nd1->next != solver->first; nd1 = nd1->next)
    {
        if(nd1->next->next != solver->first && nd1->next->next != NULL)
        for(tsp_node_t *nd2 = nd1->next->next; nd2->next != solver->first; nd2 = nd2->next)
        {
            if(nd2->next->next != solver->first && nd2->next->next != NULL)
            for(tsp_node_t *nd3 = nd2->next->next; nd3->next != solver->first; nd3 = nd3->next)
            {
                if(nd3->next->next != solver->first && nd3->next->next != NULL)
                for(tsp_node_t *nd4 = nd3->next->next; nd4->next != solver->first; nd4 = nd4->next)
                {
                    nodes[0] = nd1; nodes[1] = nd1->next;
                    nodes[2] = nd2; nodes[3] = nd2->next;
                    nodes[4] = nd3; nodes[5] = nd3->next;
                    nodes[6] = nd4; nodes[7] = nd4->next;

                    tsp_solver_lk_perturbation_kopt_gain_compute(solver, nodes, &gain, &pos, 4);

                    if(gain > bgain && pos != 0)
                    {
                        qDebug() << "++++++++++++++";
                        bgain = gain;
                        bpos = pos;
                        pos = 0;
                        gain = 0.f;
                        auxnodes[0] = nodes[0];
                        auxnodes[1] = nodes[1];
                        auxnodes[2] = nodes[2];
                        auxnodes[3] = nodes[3];
                        auxnodes[4] = nodes[4];
                        auxnodes[5] = nodes[5];
                        auxnodes[6] = nodes[6];
                        auxnodes[7] = nodes[7];
                        *poss = bpos;

                        return auxnodes;
                    }
                }
            }
        }
    }

    *poss = bpos;

    return auxnodes;
}


tsp_node_t** tsp_solver_5opt_moves_perturbation_search(tsp_solver_t *solver, int *poss)
{
    tsp_node_t **nodes = (tsp_node_t**)calloc(10, sizeof(tsp_node_t*));
    tsp_node_t **auxnodes = (tsp_node_t**)calloc(10, sizeof(tsp_node_t*));
    double gain = 0.f, bgain = 0.f;
    int pos = 0, bpos = 0;

    qDebug() << "\n-|_|_|_|_|_|_|-\n";

    for(tsp_node_t *nd1 = solver->first; nd1->next != solver->first; nd1 = nd1->next)
    {
        if(nd1->next->next != solver->first && nd1->next->next != NULL)
        for(tsp_node_t *nd2 = nd1->next->next; nd2->next != solver->first; nd2 = nd2->next)
        {
            if(nd2->next->next != solver->first && nd2->next->next != NULL)
            for(tsp_node_t *nd3 = nd2->next->next; nd3->next != solver->first; nd3 = nd3->next)
            {
                if(nd3->next->next != solver->first && nd3->next->next != NULL)
                    for(tsp_node_t *nd4 = nd3->next->next; nd4->next != solver->first; nd4 = nd4->next)
                    {
                        if(nd4->next->next != solver->first && nd4->next->next != NULL)
                            for(tsp_node_t *nd5 = nd4->next->next; nd5->next != solver->first; nd5 = nd5->next)
                            {
                                nodes[0] = nd1; nodes[1] = nd1->next;
                                nodes[2] = nd2; nodes[3] = nd2->next;
                                nodes[4] = nd3; nodes[5] = nd3->next;
                                nodes[6] = nd4; nodes[7] = nd4->next;
                                nodes[8] = nd5; nodes[9] = nd5->next;

                                tsp_solver_lk_perturbation_kopt_gain_compute(solver, nodes, &gain, &pos, 5);

                                if(gain > bgain && pos != 0)
                                {
                                    qDebug() << "++++++++++++++";
                                    bgain = gain;
                                    bpos = pos;
                                    pos = 0;
                                    gain = 0.f;
                                    auxnodes[0] = nodes[0];
                                    auxnodes[1] = nodes[1];
                                    auxnodes[2] = nodes[2];
                                    auxnodes[3] = nodes[3];
                                    auxnodes[4] = nodes[4];
                                    auxnodes[5] = nodes[5];
                                    auxnodes[6] = nodes[6];
                                    auxnodes[7] = nodes[7];
                                    *poss = bpos;

                                    return auxnodes;
                                }
                            }
                }
            }
        }
    }

    *poss = bpos;

    return auxnodes;
}


void tsp_solver_3opt_with_4opt_perturbation(tsp_solver_t* solver)
{
    bool_t noMoreImpr = false_t;
    tsp_node_t **nodes;
    //int cycle = 10;

    do
    {
        int bpos = 0;
        tsp_lk_3opt_solve_f(solver);
        nodes = tsp_solver_double_bridge_perturbation_search(solver, &bpos);

        qDebug() << "Path after 3opt algorithm : " << (tsp_solver_lk_get_path_len(solver));

        if(bpos != 0)
        {
            tsp_solver_kopt_gen_swap22(nodes, solver->optKlist[2]->mat, solver->optKlist[2]->k, bpos);
            qDebug() << "Path after 4opt perturbation : " << (tsp_solver_lk_get_path_len(solver));
        }
//        else
//        {
//            nodes = tsp_solver_5opt_moves_perturbation_search(solver, &bpos);
//            if(bpos != 0)
//            {
//                tsp_solver_kopt_gen_swap22(nodes, solver->optKlist[3]->mat, solver->optKlist[3]->k, bpos);
//                qDebug() << "Path after 5opt perturbation : " << (tsp_solver_lk_get_path_len(solver));
//            }
//            else noMoreImpr = true_t;
//        }
        else noMoreImpr = true_t;
        //cycle--;

    }
    while(noMoreImpr != true_t /*&& cycle > 0*/);
}




/*  END  - [- 'Incercare' Implementare Lin-Kernighan Pure -] - */





/* impl prop */
void tsp_solver_pieces_pick_best_points(tsp_solver_t *solver)
{
    tsp_piece_t *piece = solver->fpiece;
    //tsp_solver_compute_max_min_points(solver);
    qDebug() << "Make cycle";
    tsp_solver_piece_make_cycle(solver);

    qDebug() << "KNN";
    tsp_lk_knn_preprocess_pieces_f(solver);

    qDebug() << "2opt";
    //tsp_lk_2opt_solve_pieces_f(solver);
    tsp_lk_3opt_solve_piece_f(solver);

    qDebug() << "repo centr";
    tsp_solver_piece_reposition_centr(solver);

    qDebug() << "undo cycle";
    tsp_solver_piece_undo_cycle(solver);

    qDebug() << "Picking best spot";
    for(tsp_piece_t *pnd = piece; pnd != NULL; pnd = pnd->next)
    {
        float dist = tsp_solver_piece_compute_dist_between_two_points_nosqrt(pnd->gcenter, pnd->pnode->point_col);
        tsp_point_t pt;
        pt.x = pnd->pnode->point_col.x;
        pt.y = pnd->pnode->point_col.y;

        for(tsp_node_t *nd = pnd->pnode; nd != NULL; nd = nd->next)
        {
            int auxdist = tsp_solver_piece_compute_dist_between_two_points_nosqrt(pnd->gcenter, nd->point_col);
            if(dist > auxdist)
            {
                dist = auxdist;
                pt.x = nd->point_col.x;
                pt.y = nd->point_col.y;
            }
        }
        pnd->bestp.x = pt.x;
        pnd->bestp.y = pt.y;
        if(pnd->next == piece) break;
    }

    qDebug() << "FINISH";
}



////////////////////////////////////////////////////////////////////////////////////////
/* partitioning with k-means */
void tsp_lk_kmeans_fill_with_centroids_f(tsp_solver_t *solver, int centroids)
{
    solver->centr.centr_point = (tsp_point_t*)malloc(sizeof(tsp_point_t)*centroids);
    int max_x = tsp_lk_get_max_x_f(solver);
    int max_y = tsp_lk_get_max_y_f(solver);
    int min_x = tsp_lk_get_min_x_f(solver);
    int min_y = tsp_lk_get_min_y_f(solver);

    int count = 0;

    while(count < centroids)
    {
        int xr = rand() %(max_x-min_x) + min_x;
        int yr = rand() %(max_y-min_y) + min_y;

        solver->centr.centr_point[count].x = xr;
        solver->centr.centr_point[count].y = yr;

        count++;
    }
}

double tsp_lk_compute_slope_f(tsp_point_t p1, tsp_point_t p2)
{
    double slope = (double)(((p1.x - p2.x)*(-1)) / (p1.y - p2.y));
    return slope;
}

double tsp_lk_compute_eq_constant_f(double slope, double x3, double y3)
{
    double rez = 0;
    rez = y3 - (slope * x3);
    return rez;
}

double tsp_lk_compute_midpoint_between_centr_f(int v1, int v2)
{
    return (double)((v1 + v2)/2);
}

void tsp_lk_kmeans_compute_equation_f(tsp_solver_t *solver, double *eq)
{
    double midx = tsp_lk_compute_midpoint_between_centr_f(solver->centr.centr_point[0].x, solver->centr.centr_point[1].x);
    double midy = tsp_lk_compute_midpoint_between_centr_f(solver->centr.centr_point[0].y, solver->centr.centr_point[1].y);
    double slope = tsp_lk_compute_slope_f(solver->centr.centr_point[0], solver->centr.centr_point[1]);
    double constant = tsp_lk_compute_eq_constant_f(slope, midx, midy);

    eq[0] = slope;
    eq[1] = 1.f;
    eq[2] = constant;
}

double tsp_lk_compute_eq_result_f(tsp_point_t p, double *eq) /* 0 - x ; 1 - y; 2 - c */
{
    double rez = 0;
    rez = p.x * eq[0] - p.y * eq[1] + eq[2];
    return rez;
}

void tsp_lk_kmeans_append_node_f(tsp_node_t *node, int x, int y)
{
    tsp_node_t *nod = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    nod->next = NULL;
    nod->point_col.x = x;
    nod->point_col.y = y;
    node->next = nod;
    node = node->next;
}

void tsp_lk_fill_points_for_each_centr_f(tsp_solver_t *solver, int centroids, double *eq)
{
    double rez_eq_p1 = tsp_lk_compute_eq_result_f(solver->centr.centr_point[0], eq);

    tsp_node_t *nc1 = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    nc1->next = NULL;
    tsp_node_t *nc1_aux = nc1;
    bool_t first_nc1 = true_t;
    int count_nc1 = 0;

    tsp_node_t *nc2 = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    nc2->next = NULL;
    tsp_node_t *nc2_aux = nc2;
    bool_t first_nc2 = true_t;
    int count_nc2 = 0;

    if(rez_eq_p1 > 0)
    {
        for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        {
            if(tsp_lk_compute_eq_result_f(nd->point_col, eq) > 0)
            {
                if(first_nc1 == true_t)
                {
                    nc1->point_col.x = nd->point_col.x;
                    nc1->point_col.y = nd->point_col.y;
                    first_nc1 = false_t;
                }
                else tsp_lk_kmeans_append_node_f(nc1, nd->point_col.x, nd->point_col.y);
                count_nc1++;
            }
            else
            {
                if(first_nc2 == true_t)
                {
                    nc2->point_col.x = nd->point_col.x;
                    nc2->point_col.y = nd->point_col.y;
                    first_nc2 = false_t;
                }
                else tsp_lk_kmeans_append_node_f(nc2, nd->point_col.x, nd->point_col.y);
                count_nc2++;
            }
        }
    }
    else if(rez_eq_p1 < 0)
    {
        for(tsp_node_t *nd = solver->first; nd != NULL; nd = nd->next)
        {
            if(tsp_lk_compute_eq_result_f(nd->point_col, eq) < 0)
            {
                if(first_nc1 == true_t)
                {
                    nc1->point_col.x = nd->point_col.x;
                    nc1->point_col.y = nd->point_col.y;
                    first_nc1 = false_t;
                }
                else tsp_lk_kmeans_append_node_f(nc1, nd->point_col.x, nd->point_col.y);
                count_nc1++;
            }
            else
            {
                if(first_nc2 == true_t)
                {
                    nc2->point_col.x = nd->point_col.x;
                    nc2->point_col.y = nd->point_col.y;
                    first_nc2 = false_t;
                }
                else tsp_lk_kmeans_append_node_f(nc2, nd->point_col.x, nd->point_col.y);
                count_nc2++;
            }
        }
    }
    else { printf("SAVAGE\n"); }

    solver->centr.len = centroids;
    solver->centr.points_of_centroids = (tsp_nodes_list_t*)malloc(sizeof(tsp_nodes_list_t)*centroids);

    if(solver->centr.points_of_centroids[0].list != NULL) tsp_lk_free_nodes_f(solver->centr.points_of_centroids[0].list);
    solver->centr.points_of_centroids[0].len = count_nc1;
    solver->centr.points_of_centroids[0].list = nc1_aux;

    if(solver->centr.points_of_centroids[1].list != NULL) tsp_lk_free_nodes_f(solver->centr.points_of_centroids[1].list);
    solver->centr.points_of_centroids[1].len = count_nc2;
    solver->centr.points_of_centroids[1].list = nc2_aux;

}

double tsp_lk_compute_arithmetic_mean_f(tsp_node_t *node, int type)
{
    double rez = 0.f;
    int count = 0;
    switch(type)
    {
    case 1:
        for(tsp_node_t *nd = node; nd != NULL; nd = nd->next)
        {
            rez += (double)(nd->point_col.x);
            count++;
        }
        break;
    case 2:
        for(tsp_node_t *nd = node; nd != NULL; nd = nd->next)
        {
            rez += (double)(nd->point_col.y);
            count++;
        }
        break;
    default: break;
    }
    return (double)(rez/count);
}

void tsp_lk_compute_new_pos_of_centr_f(tsp_solver_t *solver)
{
    double c1x = tsp_lk_compute_arithmetic_mean_f(solver->centr.points_of_centroids[0].list, 1);
    double c1y = tsp_lk_compute_arithmetic_mean_f(solver->centr.points_of_centroids[0].list, 2);
    double c2x = tsp_lk_compute_arithmetic_mean_f(solver->centr.points_of_centroids[1].list, 1);
    double c2y = tsp_lk_compute_arithmetic_mean_f(solver->centr.points_of_centroids[1].list, 2);

    solver->centr.centr_point[0].x = c1x;
    solver->centr.centr_point[0].y = c1y;
    solver->centr.centr_point[1].x = c2x;
    solver->centr.centr_point[1].y = c2y;
}

void tsp_lk_kmeans_clustering_alg_f(tsp_solver_t *solver, double *eq, int last_count)
{
    if(last_count != solver->centr.points_of_centroids[0].len)
    {
        tsp_lk_compute_new_pos_of_centr_f(solver);
        tsp_lk_kmeans_compute_equation_f(solver, eq);
        tsp_lk_fill_points_for_each_centr_f(solver, 2, eq);
        tsp_lk_kmeans_clustering_alg_f(solver, eq, solver->centr.points_of_centroids[0].len);
    }
}

void tsp_lk_kmeans_partitioning_f(tsp_solver_t *solver, int centroids)
{
    if(centroids != 2) return;
    tsp_lk_kmeans_fill_with_centroids_f(solver, centroids);
    double *eq = (double*)malloc(sizeof(double)*3);
    tsp_lk_kmeans_compute_equation_f(solver, eq);
    tsp_lk_fill_points_for_each_centr_f(solver, centroids, eq);

    tsp_lk_kmeans_clustering_alg_f(solver, eq, 0);
}

#endif // TSP_LIN_KERNIGHAN_ALG_AUX_H
