#ifndef TSP_GENERATE_KOPT_PERM_H
#define TSP_GENERATE_KOPT_PERM_H

#include "tsp_bool.h"
#include <stdlib.h>
#include <stdio.h>
#include <QDebug>

typedef struct tsp_kopt_perm_nod_s
{
    int k;
    int *perm;
    tsp_kopt_perm_nod_s *next;
} tsp_kopt_perm_nod_t;

typedef struct
{
    int k;
    int size;
    int **mat;
    tsp_kopt_perm_nod_t *start;
    tsp_kopt_perm_nod_t *end;
} tsp_kopt_list_t;

void kopt_gen_nod_init(tsp_kopt_list_t **klist)
{
    *klist = (tsp_kopt_list_t*)malloc(sizeof(tsp_kopt_list_t));
    (*klist)->k = 0;
    (*klist)->start = NULL;
    (*klist)->end = (*klist)->start;
    (*klist)->size = 0;
}

void kopt_gen_nod_free(tsp_kopt_perm_nod_t *knod)
{
    while(knod != NULL)
    {
        tsp_kopt_perm_nod_t *nd = knod->next;
        free(knod);
        knod = nd;
    }
}

void kopt_gen_list_free(tsp_kopt_list_t *klist)
{
    if(klist == NULL) return;
    if(klist->start != NULL) kopt_gen_nod_free(klist->start);
    //if(klist->end != NULL) free(klist->end);
    free(klist);
}

void kopt_gen_nod_append(tsp_kopt_list_t *klist, tsp_kopt_perm_nod_t *knod)
{
    if(klist == NULL) { return; }
    if(knod == NULL) { return; }
    if(klist->start == NULL)
    {
        klist->start = knod;
        klist->end = klist->start;
        klist->end->next = NULL;
        klist->size++;
    }
    else
    {
        klist->end->next = knod;
        klist->end = klist->end->next;
        klist->end->next = NULL;
        klist->size++;
    }
}

void kopt_gen_nod_push_front(tsp_kopt_list_t *klist, tsp_kopt_perm_nod_t *knod)
{
    if(knod == NULL || klist == NULL || klist->start == NULL) return;
    knod->next = klist->start;
    klist->start = knod;
    klist->size++;
}

int kopt_get_opt_type(int *vect, int size)
{
    int c = 0, i = 0;
    for(i = 0; i < size; i++)
    {
//        if(vect[i] == i+1)
//        {
//            if(i+1 == 1 || i+1 == size) c++;
//            else
//            {
//                if(vect[i-1]+1 == vect[i]) c++;
//            }


//        }

        if(vect[i] > 0)
        {
            if(vect[i] == i+1)
            {
                if(i+1 == 1 || i+1 == size) c++;
                else
                {
                    if(i > 0)
                    if(vect[i-1]+1 == vect[i]) c++;
                }
            }
            else
            {
                if(i > 0)
                if(vect[i-1]+1 == vect[i]) c++;
            }
        }
        else if(vect[i] < 0)
        {
            if(i < size)
            {
                if(vect[i] == vect[i+1]-1) c++;
            }
        }
    }

    if(/*c == size || */c == 0) return 1;
    else return 0;
}

void kopt_generate_positive_perm(tsp_kopt_list_t *klist, int pos, int k, int *vect)
{
    if(pos < k)
    {
        for(int i = 1; i <= k; i++)
        {
            bool_t canPut = true_t;

            if(pos > 0)
            {
                for(int j = 0; j < pos; j++)
                {
                    if(vect[j] == i)
                    {
                        canPut = false_t;
                        break;
                    }
                }
            }

            if(canPut == true_t)
            {
                int *auxv = (int*)calloc(k, sizeof(int));
                for(int j = 0; j < k; j++)
                {
                    auxv[j] = vect[j];
                }
                auxv[pos] = i;
                kopt_generate_positive_perm(klist, 1+pos, k, auxv);
            }
        }
    }

    int czero = 0;
    for(int i = 0; i < k; i++)
    {
        if(vect[i] == 0) { czero++; break; }
    }
    if(czero == 0)
    {
        tsp_kopt_perm_nod_t *nod = (tsp_kopt_perm_nod_t*)malloc(sizeof(tsp_kopt_perm_nod_t));
        nod->k = k;
        nod->next = NULL;
        nod->perm = vect;
        kopt_gen_nod_append(klist, nod);
    }
}

bool_t kopt_compare_two_vect(int *v1, int *v2, int size)
{
    for(int i = 0; i < size; i++)
    {
        if(v1[i] != v2[i]) return false_t;
    }
    return true_t;
}

bool_t kopt_have_zero_elem(int *v1, int size)
{
    for(int i = 0; i < size; i++)
    {
        if(v1[i] == 0) return true_t;
    }
    return false_t;
}

void kopt_remove_zero_elem_vect(tsp_kopt_list_t *klist)
{
    int cc = 0;
    tsp_kopt_perm_nod_t *prev;
    for(tsp_kopt_perm_nod_t *nd1 = klist->start; nd1 != NULL; nd1 = nd1->next)
    {

        if(nd1 != NULL)
        {

            if(kopt_have_zero_elem(nd1->perm, nd1->k) != true_t)
            {
                qDebug() << "ElZero " << ++cc;
                if(nd1 == klist->start)
                {
                    qDebug() << "RemZero St";
                    tsp_kopt_perm_nod_t *aux = nd1;
                    nd1 = nd1->next;
                    klist->start = klist->start->next;
                    free(aux);
                    klist->size--;
                }
                else if(nd1->next == NULL)
                {
                    qDebug() << "RemZero End";
                    tsp_kopt_perm_nod_t *aux = nd1;
                    nd1 = nd1->next;
                    prev->next = NULL;
                    free(aux);
                    klist->size--;
                    break;
                }
                else
                {
                    qDebug() << "RemZero Mid";
                    prev->next = nd1->next;
                    tsp_kopt_perm_nod_t *aux = nd1;
                    nd1 = nd1->next;
                    free(aux);
                    klist->size--;
                }
            }
        }

        prev = nd1;
    }

    qDebug() << "FinishZero";
}

void kopt_remove_duplicates(tsp_kopt_list_t *klist)
{
    for(tsp_kopt_perm_nod_t *nd1 = klist->start; nd1->next != NULL; nd1 = nd1->next)
    {
        for(tsp_kopt_perm_nod_t *nd2 = nd1->next; nd2 != NULL; nd2 = nd2->next)
        {
            if(kopt_compare_two_vect(nd1->perm, nd2->perm, nd1->k) == true_t)
            {
                if(nd2->next != NULL)
                {
                    nd1->next = nd2->next;
                    tsp_kopt_perm_nod_t *aux = nd2;
                    nd2 = nd1;
                    free(aux);
                    klist->size--;
                }
                else
                {
                    free(nd2);
                    klist->size--;
                }
            }
        }
    }
}

tsp_kopt_perm_nod_t* getEnd(tsp_kopt_list_t *klist)
{
    for(tsp_kopt_perm_nod_t *nd = klist->start; nd != NULL; nd = nd->next)
    {
        if(nd->next == NULL) return nd;
    }
}

void kopt_generate_negative_perm(tsp_kopt_list_t *klist, int k)
{
    for(int i = 1; i <= k; i++)
    {
        int ii = (-1) * i;
        tsp_kopt_perm_nod_t *end = getEnd(klist);
        if(end != NULL)
        {
            for(tsp_kopt_perm_nod_t *nd = klist->start; nd != end->next; nd = nd->next)
            {
                int *auxv = (int*)calloc(k, sizeof(int));
                for(int j = 0; j < k; j++)
                {
                    auxv[j] = nd->perm[j];
                }

                for(int j = 0; j < k; j++)
                {
                    if(auxv[j] == i) auxv[j] *= (-1);
                }

                tsp_kopt_perm_nod_t *nod = (tsp_kopt_perm_nod_t*)malloc(sizeof(tsp_kopt_perm_nod_t));
                nod->k = k;
                nod->perm = auxv;
                kopt_gen_nod_append(klist, nod);
            }
        }
    }
}

void kopt_fill_matrix(tsp_kopt_list_t *klist)
{
    klist->mat = (int**)calloc(klist->size, sizeof(int*));
    int i = 0;
    for(tsp_kopt_perm_nod_t *nd = klist->start; nd != NULL && i < klist->size; nd = nd->next, i++)
    {
        klist->mat[i] = nd->perm;
    }
}

void kopt_print_perm(tsp_kopt_list_t *klist)
{
    int cc = 0;
    qDebug() << "Size = " << klist->size;
    for(tsp_kopt_perm_nod_t *nd = klist->start; nd != NULL; nd = nd->next)
    {
        qDebug() << ++cc << " ";
        for(int i = 0; i < nd->k; i++)
        {
            qDebug() << " " << nd->perm[i] << "";
        }
        qDebug() << "";
    }
}

void kopt_remove_useless_kmoves(tsp_kopt_list_t *klist, int size)
{
    int cc = 0;
    for(tsp_kopt_perm_nod_t *nd = klist->start; nd != NULL; )
    {
        //qDebug() << "cc = " << (++cc);
        if(nd->next != NULL)
        {
            //qDebug() << "not null";
            if(kopt_get_opt_type(nd->next->perm, size) == 0)
            {
                //qDebug() << "hhhh";
                klist->size--;
                tsp_kopt_perm_nod_t * aux = nd->next;
                nd->next = aux->next;
                free(aux);
            }
            else
            {
                //qDebug() << "next";
                nd = nd->next;
            }
        }
        else
        {
//            if(kopt_get_opt_type(nd->perm, size) == 0)
//            {
//                qDebug() << "NULL";
//                klist->size--;
//                free(nd);
//                nd = NULL;
//                break;
//            }

            break;
        }
    }
}


void kopt_generate_all_permutations(tsp_kopt_list_t *klist, int k)
{
    int *vect = (int*)calloc(k, sizeof(int));
    kopt_generate_positive_perm(klist, 0, k-1, vect);
    kopt_generate_negative_perm(klist, k-1);

    if(k != 2)
        kopt_remove_useless_kmoves(klist, k-1);

    kopt_print_perm(klist);

    kopt_fill_matrix(klist);
    klist->k = k-1;
}

#endif // TSP_GENERATE_KOPT_PERM_H
