#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    btnLoadFile = new QPushButton("Load", this);
    btnLoadFile->setGeometry(QRect(QPoint(10,10), QSize(200,35)));

    btnPreprocessKNN = new QPushButton("KNN", this);
    btnPreprocessKNN->setGeometry(QRect(QPoint(10 + 210,10), QSize(200,35)));

    btnOptimize2OPT = new QPushButton("2-OPT", this);
    btnOptimize2OPT->setGeometry(QRect(QPoint(10 + 420,10), QSize(200,35)));

    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::handleBtnLoadFileAndShow()
{

}

void MainWindow::handleBtnPreprocessKNNAndShow()
{

}

void MainWindow::handleBtnOptimizeWith2OPT()
{

}

void MainWindow::setFirstNode(cutting_order_t *node)
{
    this->fnode = node;
}
