#ifndef TSP_HELPER_FUNC_H
#define TSP_HELPER_FUNC_H

#include "structures.h"
#include <stdio.h>
#include <stdlib.h>

void tsp_fill_from_file_f(cutting_order_t *node, const char *file_name)
{
    FILE *fd = fopen(file_name, "r");
    char buff[12];
    memset(&buff, 0, sizeof(buff));

    while(fgets(buff, sizeof(buff),fd))
    {
        int nr = 0;
        cutting_order_t *nod = (cutting_order_t*)malloc(sizeof(cutting_order_t));

        for(int i = 0; i < 6; i++)
        {
            if(buff[i] != '\n' && buff[i] != EOF)
            {
                if(buff[i] != ' ') nr = nr * 10 + (buff[i] - '0');
                else
                {
                    nod->point_col.x = nr;
                    nr = 0;
                }
            }
            else
            {
                nod->point_col.y = nr;

                node->next = nod;
                node = node->next;
                node->next = NULL;
                break;
            }
        }
        memset(&buff, 0, sizeof(buff));
    }
    printf("\n");
    fclose(fd);
}

int tsp_get_max_y_f(cutting_order_t *node)
{
    int rez = node->point_col.y;
    for(cutting_order_t *nd = node; nd != NULL; nd = nd->next)
    { if(rez < nd->point_col.y) rez = nd->point_col.y; }
    return rez;
}

int tsp_get_max_x_f(cutting_order_t *node)
{
    int rez = node->point_col.x;
    for(cutting_order_t *nd = node; nd != NULL; nd = nd->next)
    { if(rez < nd->point_col.x) rez = nd->point_col.x; }
    return rez;
}

int tsp_get_min_y_f(cutting_order_t *node)
{
    int rez = node->point_col.y;
    for(cutting_order_t *nd = node; nd != NULL; nd = nd->next)
    { if(rez > nd->point_col.y) rez = nd->point_col.y; }
    return rez;
}

int tsp_get_min_x_f(cutting_order_t *node)
{
    int rez = node->point_col.x;
    for(cutting_order_t *nd = node; nd != NULL; nd = nd->next)
    { if(rez > nd->point_col.x) rez = nd->point_col.x; }
    return rez;
}


int tsp_dist_2_nodes_f(cutting_order_t *first_nd, cutting_order_t *second_nd)
{
    int x_dist = (int)(first_nd->point_col.x - second_nd->point_col.x);
    x_dist = (x_dist * x_dist);
    int y_dist = (int)(first_nd->point_col.y - second_nd->point_col.y);
    y_dist = (y_dist * y_dist);
    int rez = (int)(round(sqrt(x_dist + y_dist)));
    return rez;
    /*
    return (int)(round(sqrt((double)((first_nd->point_col.x - second_nd->point_col.x) *
                                     (first_nd->point_col.x - second_nd->point_col.x) +
                                     (first_nd->point_col.y - second_nd->point_col.y) *
                                     (first_nd->point_col.y - second_nd->point_col.y)))));
                                     */
}

int tsp_compute_path_cost_f(cutting_order_t *node)
{
    int cost = 0;
    if(node == NULL) return -1;
    cutting_order_t *aux_nd = node;
    for(cutting_order_t *nd = node; nd->next != NULL && nd->next != aux_nd; nd = nd->next)
    { cost += tsp_dist_2_nodes_f(nd, nd->next); }
    return cost;
}


void tsp_make_cycle_f(cutting_order_t *node)
{
    cutting_order_t *nd = node;
    while(node->next != NULL)
    { node = node->next; }
    node->next = nd;
}

void tsp_undo_cycle_f(cutting_order_t *node)
{
    cutting_order_t *nod = node;
    for(cutting_order_t *nd = node->next; nd != NULL; nd = nd->next)
    {
        if(nd->next == nod)
        {
            printf("Found\n");
            nd->next = NULL;
            break;
        }
    }
}


void tsp_scale_graph_f(cutting_order_t *node, int scale)
{
    for(cutting_order_t *nd = node; nd != NULL; nd = nd->next)
    {
        nd->point_col.x *= scale;
        nd->point_col.y *= scale;
    }
}

void tsp_undo_scale_graph_f(cutting_order_t *node, int scale)
{
    for(cutting_order_t *nd = node; nd != NULL; nd = nd->next)
    {
        nd->point_col.x /= scale;
        nd->point_col.y /= scale;
    }
}

void tsp_append_node_f(cutting_order_t *node, cutting_order_t *last_node)
{
    for(cutting_order_t *nd = node; nd != NULL; nd = nd->next)
    {
        if(nd->next == NULL)
        {
            nd->next = last_node;
            break;
        }
    }
}

void tsp_fill_first_node_when_gen_f(cutting_order_t *node)
{
    int max_y = tsp_get_max_y_f(node->next);
    int min_x = tsp_get_min_x_f(node->next);
    node->point_col.x = min_x;
    node->point_col.y = max_y;
}

void tsp_fill_last_node_when_gen_f(cutting_order_t *node)
{
    int max_x = tsp_get_max_x_f(node->next);
    int min_y = tsp_get_min_y_f(node->next);

    cutting_order_t *last_node = (cutting_order_t*)malloc(sizeof(cutting_order_t));
    last_node->next = NULL;

    last_node->point_col.x = max_x;
    last_node->point_col.y = min_y;
    tsp_append_node_f(node->next, last_node);
}

void tsp_generate_sample_f(cutting_order_t *node, int nrOfNodes, int minDist, int maxDist)
{
    int count = 0;
    int ok_first = 0;
    cutting_order_t *old_node;
    cutting_order_t *first_node;

    while(count < nrOfNodes)
    {
        int xr = rand() %6000;
        int yr = rand() %500;
        if(!ok_first)
        {
            cutting_order_t *nod = (cutting_order_t*)malloc(sizeof(cutting_order_t));
            nod->next = NULL;
            nod->point_col.x = xr;
            nod->point_col.y = yr;
            old_node = nod;
            node->next = nod;
            node = node->next;
            first_node = node;
            ok_first = 1;
            count++;
        }
        else
        {
            cutting_order_t *nod = (cutting_order_t*)malloc(sizeof(cutting_order_t));
            nod->next = NULL;
            nod->point_col.x = xr;
            nod->point_col.y = yr;

            int dist = (int)tsp_dist_2_nodes_f(nod, old_node);

            if(dist >= minDist && dist <= maxDist)
            {
                int ok = 0;
                for(cutting_order_t *nd = first_node; nd != NULL; nd = nd->next)
                {
                    int dist2 = (int)tsp_dist_2_nodes_f(nod, nd);
                    if(dist2 < minDist/3 || dist2 > 600)
                    { ok = 1; break; }
                }

                if(ok == 0)
                {
                    old_node = nod;
                    node->next = nod;
                    node = node->next;
                    count++;
                }
            }
        }
    }
}

void tsp_print_cutting_order_f(cutting_order_t* node)
{
    for(cutting_order_t *nd = node; nd != NULL; nd = nd->next)
    {
        printf("Point(%i, %i) \n", nd->point_col.x, nd->point_col.y);
    }
}

void tsp_free_node_f(cutting_order_t *node)
{
    while(node != NULL)
    {
        cutting_order_t *nd = node->next;
        free(node);
        node = nd;
    }
}

#endif // TSP_HELPER_FUNC_H
