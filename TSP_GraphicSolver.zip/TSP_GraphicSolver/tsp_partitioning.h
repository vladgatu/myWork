#ifndef TSP_PARTITIONING_H
#define TSP_PARTITIONING_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <random>
#include <math.h>
#include <QDebug>

#include "tsp_point_struct.h"
#include "tsp_node_struct.h"
#include "tsp_bool.h"
#include "tsp_lin_kernighan_alg_aux.h"

typedef struct tsp_partition_s
{
    tsp_node_t *first;
    int nr_of_nodes;
    int nr_of_partitions;
}tsp_partition_t;

void tsp_part_allocate_space(tsp_partition_t **part)
{
    srand(time(0));
    *part = (tsp_partition_t*)malloc(sizeof(tsp_partition_t));
    (*part)->first = NULL;
    (*part)->nr_of_nodes = 0;
    (*part)->nr_of_partitions = 0;
}

void tsp_part_init_with_random(tsp_partition_t *solver, const int nr_of_gen_nodes, const int minDist, const int maxDist)
{
    int count = 0;
    int ok_first = 0;
    tsp_node_t *old_node;
    tsp_node_t *first_node;

    solver->first = (tsp_node_t*)malloc(sizeof(tsp_node_t));
    solver->first->next = NULL;
    tsp_node_t *node = solver->first;

    while(count < nr_of_gen_nodes)
    {
        int xr = rand() %6000;
        int yr = rand() %500;
        if(!ok_first)
        {
            node->point_col.x = xr;
            node->point_col.y = yr;
            old_node = node;
            first_node = node;
            ok_first = 1;
            count++;
        }
        else
        {
            tsp_node_t *nod = (tsp_node_t*)malloc(sizeof(tsp_node_t));
            nod->next = NULL;
            nod->point_col.x = xr;
            nod->point_col.y = yr;

            int dist = (int)tsp_lk_compute_dist_between_two_nodes_f(nod, old_node);

            if(dist >= minDist && dist <= maxDist)
            {
                int ok = 0;
                for(tsp_node_t *nd = first_node; nd != NULL; nd = nd->next)
                {
                    int dist2 = (int)tsp_lk_compute_dist_between_two_nodes_f(nod, nd);
                    if(dist2 < minDist/3 || dist2 > 600)
                    { ok = 1; break; }
                }

                if(ok == 0)
                {
                    old_node = nod;
                    node->next = nod;
                    node = node->next;
                    count++;
                }
            }
        }
    }
}

void tsp_part_nearestneighbor(tsp_partition_t *solver, int nrOfElem)
{
    if(solver == NULL || solver->first == NULL) return;
    tsp_node_t *node = solver->first;
    if(node == NULL || node->next == NULL) return;

    for(tsp_node_t *nd1 = node; nd1->next != NULL && nd1->next != node; nd1 = nd1->next)
    {
        unsigned int min_dist = 65000;
        tsp_node_t *aux_nd2_1, *aux_nd2_2;
        for(tsp_node_t *nd2 = nd1; nd2->next != NULL && nd2->next != node; nd2 = nd2->next)
        {
            unsigned int dist = (unsigned int)tsp_lk_compute_dist_between_two_nodes_f(nd1, nd2->next);
            if(dist < min_dist)
            {
                min_dist = dist;
                aux_nd2_1 = nd2->next;
                aux_nd2_2 = nd2;
            }
        }
        tsp_lk_knn_swap_nodes_f(nd1, aux_nd2_1, aux_nd2_2);
    }

    int count = 0;
    int partt = 1;

    while(node != NULL)
    {
        count++;
        if(count <= nrOfElem)
        {
            node->partition_index = partt;
        }
        else { count = 0; partt++; node->partition_index = partt; }
        node = node->next;
    }
}

void tsp_part_free(tsp_partition_t *part)
{
    tsp_lk_free_nodes_f(part->first);
    free(part);
}

void tsp_part_sectioning(tsp_partition_t *part, int nrOfElem)
{

}

void tsp_part_kmeans_pure(tsp_partition_t *part, int centroids)
{

}

void tsp_part_kmeans_atom(tsp_partition_t *part, int centroids, int nrOfElem)
{

}

#endif // TSP_PARTITIONING_H
